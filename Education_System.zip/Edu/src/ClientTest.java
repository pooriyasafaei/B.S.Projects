import client.controller.Controller;
import com.google.gson.Gson;

public class ClientTest {
    public static void main(String[] args) {
        (Controller.getInstance()).run();
    }
}
