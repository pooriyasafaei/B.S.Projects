package client.controller.support;

import client.controller.Controller;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class MessagesToSend {

    private LinkedList<Message> messages = new LinkedList<>();



    private static final String path = Controller.getProperties().getProperty("support_path") + "support.json";

    private static MessagesToSend messagesToSend;

    public static MessagesToSend getInstance(){
        if(messagesToSend == null){
            messagesToSend = readData();
        }

        return messagesToSend;
    }

    private static MessagesToSend readData() {
        Gson gson = new Gson();
        File file = new File(path);
        try {
            Scanner scan = new Scanner(file);
            String json = scan.nextLine();
            messagesToSend = (gson.fromJson(json, MessagesToSend.class));

            return messagesToSend;

        } catch (IOException e){
            e.printStackTrace();
            return null;
        }
    }

    private static void saveData(MessagesToSend messagesToSend){
        Gson gson = new Gson();
        try {
            FileWriter supports = new FileWriter(path);
            gson.toJson(messagesToSend, supports);
            supports.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addMessage(long senderId, long receiverId, String message){
        this.messages.add(new Message(senderId, receiverId, message));
        saveData(this);

        tryToSendMessage();
    }

    public void tryToSendMessage(){
        if(!Controller.getInstance().isOnline()) return;
        messages.removeIf(message -> Controller.getInstance().getLibrary().sendMessageViaMessenger(message).isFlag());

        saveData(this);
    }

    public LinkedList<Message> getMessages() {
        return messages;
    }

    public void setMessages(LinkedList<Message> messages) {
        this.messages = messages;
    }

    public static MessagesToSend getMessagesToSend() {
        return messagesToSend;
    }

    public static void setMessagesToSend(MessagesToSend messagesToSend) {
        MessagesToSend.messagesToSend = messagesToSend;
    }
}
