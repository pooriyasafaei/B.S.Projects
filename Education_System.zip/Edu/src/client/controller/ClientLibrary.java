package client.controller;

import client.controller.support.Message;
import com.google.gson.Gson;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import communication.public_info.EduPublicInfo;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.users.User;
import server.time.DateTime;
import server.time.TimeInWeek;

import javax.swing.*;
import java.io.File;
import java.util.HashSet;
import java.util.LinkedList;


public class ClientLibrary {

    private Controller controller;

    public ServerResponse login(Long id, String password){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.LOGIN);

        request.addData("id", id);
        request.addData("password", password);

        ServerResponse response = controller.sendMessage(request);

        if(response.isFlag()){
            controller.setOfflineData((new Gson()).fromJson((String) response.readData("offline_data"), EduPublicInfo.class));
            controller.setLoggedIn(controller.getOfflineData().getUserById((Long) response.readData("user")));
        }

        return response;
    }

    public ServerResponse logout(){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.LOGOUT);

        DataAccess.saveAllData();
        controller.setLoggedIn(null);

        ServerResponse response = controller.sendMessage(request);

        return response;
    }

    public ServerResponse reconnect(Long id){

        final ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.Reconnect);

        request.addData("id", id);
        ServerResponse response = controller.sendMessage(request);

        System.out.println((new Gson()).toJson(response));
        controller.setOfflineData((new Gson()).fromJson((String) response.readData("offline_data"), EduPublicInfo.class));
        controller.setLoggedIn(controller.getOfflineDataNoUpdate().getUserById((Long) response.readData("user")));

        return response;
    }

    public ImageIcon getPicture(Long id){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.GetPicture);
        request.addData("id", id);

        ServerResponse response = controller.sendMessage(request);
        FileEncode picture = (FileEncode) response.readData("picture");
        savePicture(picture);

        return new ImageIcon(Controller.getProperties().getProperty("pictures_path") + picture.getFileName());
    }

    public ServerResponse sendMessageViaMessenger(Message message){
        if(message.getMessage().split(" ")[0].equals("@upload")) return sendMedia(message);
        if(message.getMessage().split(" ")[0].equals("@download")) return getMedia(message);

        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.SendMessage);
        request.addData("message", message);

        return controller.sendMessage(request);
    }

    private ServerResponse getMedia(Message message) {
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.GetMedia);
        request.addData("message", message);

        ServerResponse response = controller.sendMessage(request);

        if(!response.isFlag()) return response;

        FileEncode media = (FileEncode) response.readData("media");
        (new File(Controller.getProperties().getProperty("media_path") +
                message.getSenderId() + "to" + message.getReceiverId())).mkdirs();

        FileEncode.decodeStringToFile(media.getEncoded(), Controller.getProperties().getProperty("media_path") +
                message.getSenderId() + "to" + message.getReceiverId() + "\\" + media.getFileName());

        return response;
    }

    private ServerResponse sendMedia(Message message) {
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.SendMedia);

        System.out.println(message.getMessage().split(" ", 2)[1]);
        File f = new File(message.getMessage().split(" ", 2)[1]);

        if(!f.isFile()){
            ServerResponse response = new ServerResponse();
            response.setFlag(false);
            response.setServerMessage("file doesn't exist");
            return response;
        }

        FileEncode media = new FileEncode(message.getMessage().split(" ", 2)[1]);

        request.addData("media", media);
        request.addData("senderId", message.getSenderId());
        request.addData("receiverId", message.getReceiverId());

        return controller.sendMessage(request);
    }

    public ServerResponse changePassword(String password){
        final ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.ChangePassword);

        request.addData("password", password);


        return controller.sendMessage(request);
    }

    public ServerResponse changeEmailAndPhone(String email, String phone){
        final ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.ChangeEmailAndPhone);

        request.addData("email", email);
        request.addData("phone", phone);

        return controller.sendMessage(request);
    }

    public ServerResponse mainMenu(){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.MainMenu);

        ServerResponse response = controller.sendMessage(request);

        controller.setOfflineData((new Gson()).fromJson((String) response.readData("offline_data"), EduPublicInfo.class));
        controller.setLoggedIn(controller.getOfflineDataNoUpdate().getUserById((Long) response.readData("user")));

        return response;
    }

    public User refreshPublicInfo(){
        User user;
        if(Controller.getInstance().isOnline()){
            ServerResponse response = Controller.getInstance().getLibrary().mainMenu();
            Controller.getInstance().getLibrary().savePicture((FileEncode) response.readData("picture"));

            controller.setOfflineData((new Gson()).fromJson((String) response.readData("offline_data"), EduPublicInfo.class));
            controller.setLoggedIn(controller.getOfflineDataNoUpdate().getUserById((Long) response.readData("user")));

            user = controller.getOfflineDataNoUpdate().getUserById((Long) response.readData("user"));

        } else user = Controller.getInstance().getLoggedIn();

        return user;
    }

    public ServerResponse markOrUnmarkCourse(Long studentId, Long courseId, Boolean mark){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.MarkOrUnmarkCourse);

        request.addData("studentId", studentId);
        request.addData("courseId", courseId);
        request.addData("mark", mark);

        return controller.sendMessage(request);

    }

    public ServerResponse enrollCourse(Long studentId, Long courseId, Boolean withCondition){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EnrollCourse);

        request.addData("studentId", studentId);
        request.addData("courseId", courseId);
        request.addData("withCondition", withCondition);

        return controller.sendMessage(request);
    }

    public ServerResponse changeEnrollTime(HashSet<Long> studentIds, DateTime enrollTime){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.ChangeEnrollTime);

        request.addData("studentIds", studentIds);
        request.addData("enrollTime", enrollTime);

        return controller.sendMessage(request);
    }

    public ServerResponse courseChangeGroup(Long studentId, Long courseId, Long newGroupId){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.ChangeCourseGroup);

        request.addData("studentId", studentId);
        request.addData("courseId", courseId);
        request.addData("newGroupId", newGroupId);

        return controller.sendMessage(request);
    }

    public ServerResponse deleteMaster(Long masterId){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.DeleteMaster);
        request.addData("masterId", masterId);
        return controller.sendMessage(request);
    }

    public ServerResponse editMaster(Long masterId, String phoneNo, String roomNo, String email,
                                     String masterDegree, boolean chancellor, boolean active){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EditMaster);
        request.addData("masterId", masterId);
        request.addData("phoneNo", phoneNo);
        request.addData("roomNo", roomNo);
        request.addData("email", email);
        request.addData("masterDegree", masterDegree);
        request.addData("chancellor", (Boolean)chancellor);
        request.addData("active", (Boolean)active);

        return controller.sendMessage(request);
    }

    public ServerResponse addMaster(String name, String password, String nationalId, int collegeId, long idNumber,
                                    DateTime birthDay, String masterDegree, boolean chancellor, boolean dean, int room){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddMaster);

        request.addData("name", name);
        request.addData("password", password);
        request.addData("nationalId", nationalId);
        request.addData("collegeId", (Integer)collegeId);
        request.addData("idNumber",(Long) idNumber);
        request.addData("birthDay", (DateTime)birthDay);
        request.addData("masterDegree", masterDegree);
        request.addData("chancellor", (Boolean)chancellor);
        request.addData("dean", (Boolean)dean);
        request.addData("room", (Integer)room);

        return controller.sendMessage(request);
    }

    public ServerResponse deleteCourse(Long courseId){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.DeleteCourse);
        request.addData("courseId", courseId);
        return controller.sendMessage(request);
    }

    public ServerResponse editCourse(Long courseId,String courseName, String timeInWeek, String examTime
            , String masterId, String units){

        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EditCourse);

        request.addData("courseId", courseId);
        request.addData("courseName", courseName);
        request.addData("timeInWeek", timeInWeek);
        request.addData("examTime", examTime);
        request.addData("masterId", masterId);
        request.addData("units", units);

        return controller.sendMessage(request);
    }

    public ServerResponse addCourse(String name, long masterId, int units, long id, int collegeId,
                                    TimeInWeek timeInWeek, DateTime examTime, LinkedList<Long> assistants,
                                    LinkedList<Long> prerequisites, LinkedList<Long> necessities,
                                    String section, int semester, int capacity, int group){

        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddCourse);

        request.addData("name", name);
        request.addData("masterId", masterId);
        request.addData("units", units);
        request.addData("id", id);
        request.addData("collegeId", collegeId);
        request.addData("timeInWeek", timeInWeek);
        request.addData("examTime", (DateTime)examTime);
        request.addData("assistants", assistants);
        request.addData("prerequisites", prerequisites);
        request.addData("necessities", necessities);
        request.addData("section", section);
        request.addData("semester", semester);
        request.addData("capacity", capacity);
        request.addData("group", group);


        return controller.sendMessage(request);

    }

    public ServerResponse addStudent(String name, String password, String nationalId, int collegeId, long idNumber,
                                     DateTime birthDay, long supervisorId, boolean registerAllowed, String eduStatus,
                                     boolean masters, boolean phd, int enteringYear, DateTime registerTime){

        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddStudent);

        request.addData("name", name);
        request.addData("password", password);
        request.addData("nationalId", nationalId);
        request.addData("collegeId", (Integer)collegeId);
        request.addData("idNumber",(Long) idNumber);
        request.addData("birthDay", (DateTime)birthDay);
        request.addData("supervisorId", supervisorId);
        request.addData("registerAllowed", (Boolean)registerAllowed);
        request.addData("eduStatus", eduStatus);
        request.addData("masters", masters);
        request.addData("phd", phd);
        request.addData("enteringYear", enteringYear);
        request.addData("registerTime", registerTime);

        return controller.sendMessage(request);

    }

    public ServerResponse addStudentToCourseware(Long courseId, Long studentId, Boolean isAssistant){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddStudentToCourseware);

        request.addData("courseId", courseId);
        request.addData("studentId", studentId);
        request.addData("isAssistant", isAssistant);

        return controller.sendMessage(request);
    }

    public ServerResponse purge(){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.Purge);

        return controller.sendMessage(request);
    }

    public ServerResponse editStudent(Long studentId, String phoneNo, String entryYear, String email,
                                      String eduLevelDegree, String supervisorId, String registerTime,
                                      boolean active, boolean registerAllowed){

        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EditStudent);
        request.addData("studentId", studentId);
        request.addData("phoneNo", phoneNo);
        request.addData("entryYear", entryYear);
        request.addData("email", email);
        request.addData("eduLevelDegree", eduLevelDegree);
        request.addData("supervisorId", supervisorId);
        request.addData("registerTime", registerTime);
        request.addData("active", active);
        request.addData("registerAllowed", registerAllowed);

        return controller.sendMessage(request);

    }

    public ServerResponse newContent(Long courseId, String contentName){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.NewContent);

        request.addData("courseId", courseId);
        request.addData("contentName", contentName);

        return controller.sendMessage(request);
    }

    public ServerResponse addItem(long courseId, String contentName,  String itemName, boolean isText, DateTime lastChange,
                                  String text, FileEncode file){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddItem);

        request.addData("courseId", courseId);
        request.addData("contentName", contentName);
        request.addData("itemName", itemName);
        request.addData("isText", isText);
        request.addData("lastChange", lastChange);

        if(!isText) {
            request.addData("text", file.getFileName());
            request.addData("file", file);
        }
        else request.addData("text", text);

        return controller.sendMessage(request);
    }

    public ServerResponse editItem(long courseId, String contentName,  String itemName, boolean isText, DateTime lastChange,
                                   String text, FileEncode file, int removal){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EditItem);

        request.addData("courseId", courseId);
        request.addData("contentName", contentName);
        request.addData("itemName", itemName);
        request.addData("isText", isText);
        request.addData("lastChange", lastChange);
        request.addData("removal", removal);

        if(!isText) {
            request.addData("text", file.getFileName());
            request.addData("file", file);
        }
        else request.addData("text", text);
        return controller.sendMessage(request);
    }

    public ServerResponse addSubmission(Boolean isText, Long courseId, Long studentId, String homeworkName, String submission){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddSubmission);

        request.addData("isText", isText);
        request.addData("courseId", courseId);
        request.addData("homeworkName", homeworkName);
        request.addData("studentId", studentId);

        if(isText){
            request.addData("submission", submission);
            return controller.sendMessage(request);
        }

        File file = new File(submission);
        if(!file.isFile()){
            ServerResponse response = new ServerResponse();
            response.setFlag(false);
            response.setServerMessage("file not found");
            return response;
        }

        FileEncode fileEncode = new FileEncode(submission);
        request.addData("submission", fileEncode);
        return controller.sendMessage(request);
    }

    public ServerResponse getSubmissionFile(Long courseId, Integer submissionNumber, String homeworkName){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.GetSubmissionFile);

        request.addData("courseId", courseId);
        request.addData("homeworkName", homeworkName);
        request.addData("submissionNumber", submissionNumber);

        ServerResponse response = controller.sendMessage(request);

        if(response.isFlag()){
            FileEncode file = (FileEncode) response.readData("file");
            FileEncode.decodeStringToFile(file.getEncoded(), Controller.getProperties().getProperty("cw_path") +
                    courseId + "\\" + "homework\\" + homeworkName + "\\" + submissionNumber + "\\" + file.getFileName());
        }

        return response;

    }

    public ServerResponse markSubmission(long courseId, String homeworkName, int submissionNumber, int mark){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.MarkSubmission);

        request.addData("courseId", courseId);
        request.addData("homeworkName", homeworkName);
        request.addData("submissionNumber", submissionNumber);
        request.addData("mark", mark);

        return controller.sendMessage(request);
    }

    public ServerResponse addHomework(long courseId, String name, boolean isText, DateTime lastChange,
                             String info, DateTime deadline, DateTime closeTime, boolean answerText, FileEncode file){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.AddHomework);

        request.addData("courseId", courseId);
        request.addData("name", name);
        request.addData("isText", isText);
        request.addData("text", file.getFileName());
        request.addData("lastChange", lastChange);
        request.addData("info", info);
        request.addData("deadline", deadline);
        request.addData("closeTime", closeTime);
        request.addData("answerText", answerText);
        request.addData("file", file);

        return controller.sendMessage(request);
    }

    public ServerResponse downloadHomework(long courseId, String homeworkName){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.DownloadHomework);

        request.addData("courseId", courseId);
        request.addData("homeworkName", homeworkName);

        ServerResponse response = controller.sendMessage(request);

        if(response.isFlag()){
            FileEncode file = (FileEncode) response.readData("file");
            FileEncode.decodeStringToFile(file.getEncoded(), Controller.getProperties().getProperty("cw_path") +
                    courseId + "\\" + "homework\\" + homeworkName + "\\" + file.getFileName());
        }

        return response;
    }

    public ServerResponse downloadItem(long courseId, String contentName, String itemName){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.DownloadItem);

        request.addData("courseId", courseId);
        request.addData("contentName", contentName);
        request.addData("itemName", itemName);

        ServerResponse response = controller.sendMessage(request);

        if(response.isFlag()){
            FileEncode file = (FileEncode) response.readData("file");
            FileEncode.decodeStringToFile(file.getEncoded(), Controller.getProperties().getProperty("cw_path") +
                    courseId + "\\" + "edu_content\\" + contentName + "\\" + itemName + "\\" + file.getFileName());
        }

        return response;
    }

    public ServerResponse editMark(Long courseId, Long studentId, Double mark){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.EditMark);

        request.addData("courseId", courseId);
        request.addData("studentId", studentId);
        request.addData("mark", mark);

        return controller.sendMessage(request);
    }

    public ServerResponse registerCourse(Long courseId){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.RegisterCourse);

        request.addData("courseId", courseId);

        return controller.sendMessage(request);
    }

    public ServerResponse responseProtest(Long courseId, String studentId, String newMark, String response){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.ResponseProtest);

        request.addData("courseId", courseId);
        request.addData("studentId", studentId);
        request.addData("newMark", newMark);
        request.addData("response", response);


        return controller.sendMessage(request);
    }

    public ServerResponse makeProtest(Long studentId, long courseId, String text){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.MakeProtest);

        request.addData("studentId", studentId);
        request.addData("courseId", courseId);
        request.addData("text", text);

        return controller.sendMessage(request);
    }

    public ServerResponse determineRequestResult(long requestId,long acceptorId, boolean isAccepted, String message){
        ClientRequest request = new ClientRequest();
        request.setType(ClientRequestType.DetermineRequestResult);

        request.addData("requestId", requestId);
        request.addData("acceptorId", acceptorId);
        request.addData("isAccepted", isAccepted);
        request.addData("message", message);

        return controller.sendMessage(request);
    }

    public ServerResponse registerNewRequest(ClientRequest request){
        return controller.sendMessage(request);
    }

    public void savePicture(FileEncode picture){
        FileEncode.decodeStringToFile(picture.getEncoded(),
                Controller.getProperties().getProperty("pictures_path") + picture.getFileName());
    }

    public Controller getController() {
        return controller;
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }

}
