package client.controller;

public class Loop {

    private static final Loop mainLoop = new Loop();

    private Thread looper;
    private Runnable task;

    public static Loop getInstance(){
        return mainLoop;
    }

    private synchronized  void pingLoop(){
        try {
            while (true) {
                Thread.sleep(Long.parseLong(Controller.getProperties().getProperty("ping_time")));
                if (!Controller.getInstance().isOnline()) return;
                task.run();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public synchronized  void makePingLoop(Runnable runnable){
        killLoop();
        task = runnable;

        looper = new Thread(this::pingLoop);
        looper.start();
    }

    public void killLoop(){
        if(looper != null) looper.stop();
    }
}
