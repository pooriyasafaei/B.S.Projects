package client.controller;

import client.controller.support.MessagesToSend;
import client.gui.MainPanel;
import client.gui.menus.LoginPanel;
import communication.client.ClientRequest;
import communication.encoders.Jackson;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import org.codehaus.jackson.map.ObjectMapper;
import properties.Props;
import communication.public_info.EduPublicInfo;
import server.logic.users.User;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Paths;
import java.util.*;

public class Controller implements Runnable{

    private InetAddress serverIp;
    private int serverPort;
    private Socket socket;
    private final List<Thread> threads = new ArrayList<>();
    private String auth = "0";

    private boolean online = true;

    private InputStream in;
    private PrintWriter sender;
    private Scanner scanner;

    private final static Properties properties = new Properties();
    private static Controller instance;

    private ObjectMapper objectMapper;

    private EduPublicInfo offlineData;
    private User loggedIn;

    private ServerResponse lastServerData;
    private ClientLibrary library = new ClientLibrary();

    public synchronized static Controller getInstance(){
        if(instance == null) instance = new Controller();
        return instance;
    }

    private void initialize(){
        this.library.setController(this);
        this.objectMapper = Jackson.getNetworkObjectMapper();

        try {
            InputStream inputStream = new FileInputStream(Paths.get(Props.CLIENT_PROPRERTIES_PATH).toFile());
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

        serverPort = Integer.parseInt(properties.getProperty("server_port"));

        try {
            serverIp = InetAddress.getByName(properties.getProperty("server_ip"));
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return;
        }

        try {
            socket = new Socket(serverIp, serverPort);
            sender = new PrintWriter(socket.getOutputStream());
            in = socket.getInputStream();
            scanner = new Scanner(in);
            online = true;
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        library.setController(this);

        listen();
        MessagesToSend.getInstance().tryToSendMessage();
        //TODO
    }

    private synchronized ServerResponse listen(){

        try {
            String message = scanner.nextLine();
           // System.out.println("Server: " + message);
            lastServerData = objectMapper.readValue(message, ServerResponse.class);
            if(lastServerData.getType().equals(ServerResponseType.AUTH)){
                auth = lastServerData.getServerMessage();

                if(loggedIn == null){
                    MainPanel.getInstance().addComponent(new LoginPanel());
                    return new ServerResponse();

                } else {
                    ServerResponse response = library.reconnect(loggedIn.getIdNumber());

                    if(!response.isFlag()){
                        MainPanel.getInstance().add(new LoginPanel());
                        return response;
                    }

                    MainPanel.getInstance().addMainMenu();
                }

                return (new ServerResponse());
            }

        } catch (NoSuchElementException e){
            e.printStackTrace();
            offlineMode();
        } catch (Exception e) {
            e.printStackTrace();
            offlineMode();
        }

        return lastServerData;
    }

    public synchronized ServerResponse sendMessage(ClientRequest request){
        request.setAuth(auth);
        try {

            String message = objectMapper.writeValueAsString(request);
            System.out.println(message);
            sender.println(message);
            sender.flush();

            ServerResponse response = listen();
            if(response == null) {
                //TODO
                offlineMode();
                return null;
            }
            return response;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void reconnect(){
        try {
            socket = new Socket(serverIp, serverPort);
            sender = new PrintWriter(socket.getOutputStream());
            in = socket.getInputStream();
            scanner = new Scanner(in);
            online = true;
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        ServerResponse response = listen();
        MessagesToSend.getInstance().tryToSendMessage();

    }

    private void offlineMode(){

        online = false;
        System.out.println("disconnected");
        MainPanel.getInstance().disconnect();

        MainPanel.getInstance().addMainMenu();
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        initialize();
    }


    public InputStream getIn() {
        return in;
    }

    public void setIn(InputStream in) {
        this.in = in;
    }

    public static void setInstance(Controller instance) {
        Controller.instance = instance;
    }

    public User getLoggedIn() {
        return loggedIn;
    }

    public void setLoggedIn(User loggedIn) {
        this.loggedIn = loggedIn;
    }

    public static Properties getProperties(){
        return properties;
    }

    public ClientLibrary getLibrary() {
        return library;
    }

    public boolean isOnline() {
        return online;
    }

    public EduPublicInfo getOfflineData() {
        if(isOnline()) library.refreshPublicInfo();
        return offlineData;
    }

    public EduPublicInfo getOfflineDataNoUpdate() {
        return offlineData;
    }

    public void setOfflineData(EduPublicInfo offlineData) {
        this.offlineData = offlineData;
    }
}
