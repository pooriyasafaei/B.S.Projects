package client.gui.profile;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import server.logic.users.Student;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;

public class StudentProfile extends JPanel implements ActionListener {
    private JMenuBar mainMenuBar;
    private JLabel picture;
    private JLabel nameLabel;
    private JLabel nationalIdLabel;
    private JLabel studentNumberLabel;
    private JLabel phoneNoLabel;
    private JLabel emailLabel;
    private JLabel collegeLabel;
    private JLabel gradingLabel;
    private JLabel supervisorLabel;
    private JLabel entryYearLabel;
    private JLabel eduLevelLabel;
    private JTextField emailChangeField;
    private JTextField changePhoneNoField;

    private Student student;
    public StudentProfile(Student student) {

        Loop.getInstance().killLoop();

        this.student = student;

        //construct preComponents
        JMenu themeMenu = new JMenu ("Theme");
        JMenuItem option_1Item = new JMenuItem ("Theme 1");
        option_1Item.addActionListener(this);
        option_1Item.setActionCommand("theme 1");

        JMenuItem option_2Item = new JMenuItem ("Theme 2");
        option_2Item.addActionListener(this);
        option_2Item.setActionCommand("theme 2");


        JMenu edit_profileMenu = new JMenu ("Edit profile");
        JMenuItem edit_both = new JMenuItem("Edit email and phone no.");
        edit_both.addActionListener(this);
        edit_both.setActionCommand("edit profile");


        if(Controller.getInstance().isOnline() && Controller.getInstance().getLoggedIn().getIdNumber() != 12345678){
            ServerResponse response = Controller.getInstance().getLibrary().mainMenu();

            FileEncode picture = (FileEncode)response.readData("picture");
            FileEncode.decodeStringToFile(picture.getEncoded(),
                    Controller.getProperties().getProperty("pictures_path") + picture.getFileName());

            themeMenu.add (option_1Item);
            themeMenu.add (option_2Item);
            edit_profileMenu.add(edit_both);

        }

        //construct components
        mainMenuBar = new JMenuBar();
        mainMenuBar.add (themeMenu);
        mainMenuBar.add (edit_profileMenu);
        picture = new JLabel ("picture here");

        File f = new File(Controller.getProperties().getProperty("pictures_path") +
                student.getIdNumber() + ".jpg");
        if(f.isFile())
            picture.setIcon(new ImageIcon(f.getAbsolutePath()));
        else picture.setIcon(new ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));

        nameLabel = new JLabel ("Full Name: " + student.getName());
        nationalIdLabel = new JLabel ("National ID: " + student.getNationalId());
        studentNumberLabel = new JLabel ("Student Number: " + student.getIdNumber());
        phoneNoLabel = new JLabel ("Phone No. : " + student.getPhoneNumber());
        emailLabel = new JLabel ("Email: " + student.getEmail());
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData()
                .getCollegeById(student.getCollegeId()).getName());
        gradingLabel = new JLabel ("Grading: " + student.getAverageGrade(false));
        supervisorLabel = new JLabel ("Supervisor: " + Controller.getInstance().getOfflineData()
                .getUserById(student.getSupervisorId()).getName());
        entryYearLabel = new JLabel ("Entry Year: " + student.getEnteringYear());

        String level = "Educational Level: ";
        if(student.isMasters()) level += "Masters";
        if(student.isPhd()) level += "PHD";
        if(!student.isPhd() && !student.isMasters()) level += "Bachelor";
        eduLevelLabel = new JLabel (level);

        emailChangeField = new JTextField (5);
        changePhoneNoField = new JTextField (5);

        //set components properties
        emailChangeField.setToolTipText ("Enter new email then press 'Edit profile'");
        changePhoneNoField.setToolTipText ("Enter new phone number then press 'Edit profile'");

        //adjust size and set layout
        setPreferredSize (new Dimension (602, 430));
        setLayout (null);

        //add components
        if(Controller.getInstance().getLoggedIn().getIdNumber() != 12345678){
            add(mainMenuBar);
        }

        add (picture);
        add (nameLabel);
        add (nationalIdLabel);
        add (studentNumberLabel);
        add (phoneNoLabel);
        add (emailLabel);
        add (collegeLabel);
        add (gradingLabel);
        add (supervisorLabel);
        add (entryYearLabel);
        add (eduLevelLabel);

        if(Controller.getInstance().getLoggedIn().getIdNumber() != 12345678){
            add(emailChangeField);
            add(changePhoneNoField);
        }

        //set component bounds (only needed by Absolute Positioning)
        mainMenuBar.setBounds (0, 0, 480, 30);
        picture.setBounds (10, 40, 90, 120);
        nameLabel.setBounds (140, 55, 400, 25);
        nationalIdLabel.setBounds (140, 80, 200, 25);
        studentNumberLabel.setBounds (140, 105, 200, 25);
        phoneNoLabel.setBounds (140, 130, 200, 25);
        emailLabel.setBounds (140, 185, 400, 25);
        collegeLabel.setBounds (140, 235, 290, 25);
        gradingLabel.setBounds (140, 260, 100, 25);
        supervisorLabel.setBounds (140, 285, 400, 25);
        entryYearLabel.setBounds (140, 310, 100, 25);
        eduLevelLabel.setBounds (140, 335, 280, 25);
        emailChangeField.setBounds (165, 210, 250, 25);
        changePhoneNoField.setBounds (165, 155, 250, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    private void reInitialize(){

        student = (Student) Controller.getInstance().getOfflineData().getUserById(student.getIdNumber());

        File f = new File(Controller.getProperties().getProperty("pictures_path") +
                student.getIdNumber() + ".jpg");
        if(f.isFile())
            picture.setIcon(new ImageIcon(f.getAbsolutePath()));
        else picture.setIcon(new ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));

        nameLabel.setText("Full Name: " + student.getName());
        nationalIdLabel.setText("National ID: " + student.getNationalId());
        studentNumberLabel.setText("Student Number: " + student.getIdNumber());
        phoneNoLabel.setText("Phone No. : " + student.getPhoneNumber());
        emailLabel.setText("Email: " + student.getEmail());
        collegeLabel.setText("College: " + Controller.getInstance().getOfflineData()
                .getCollegeById(student.getCollegeId()).getName());
        gradingLabel.setText("Grading: " + student.getAverageGrade(false));
        supervisorLabel.setText("Supervisor: " + Controller.getInstance().getOfflineData()
                .getUserById(student.getSupervisorId()).getName());
        entryYearLabel.setText("Entry Year: " + student.getEnteringYear());

        String level = "Educational Level: ";
        if(student.isMasters()) level += "Masters";
        if(student.isPhd()) level += "PHD";
        if(!student.isPhd() && !student.isMasters()) level += "Bachelor";
        eduLevelLabel.setText(level);

        revalidate();
        repaint();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        //User user = Edu.getInstance().getUserLoggedIn();
        String command = e.getActionCommand();
        //Edu edu = Edu.getInstance();
        ServerResponse response;

        if(command.equals("edit profile")) {
            response = Controller.getInstance().getLibrary().
                    changeEmailAndPhone(emailChangeField.getText(), changePhoneNoField.getText()) ;
            if(response.isFlag()) {
                frame.addComponent(new StudentProfile(student));
            }
            frame.setSysMessageText(response.getServerMessage());

        }

//        if (command.equals("theme 1")){
//            frame.setTheme(1);
//            user.setTheme(1);
//            edu.setMessage("Theme changed");
//        }
//
//        if (command.equals("theme 2")){
//            frame.setTheme(2);
//            user.setTheme(2);
//            edu.setMessage("Theme changed");
//        }
//
//        frame.addComponent(new StudentProfile());
//        frame.setSysMessageText();
    }
}
