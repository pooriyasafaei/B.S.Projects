package client.gui.profile;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.menus.MasterMainMenu;
import client.gui.menus.StudentMainMenu;
import communication.server.ServerResponse;
import server.logic.users.Student;
import server.logic.users.User;
import server.logic.users.security.PasswordHashing;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ResetPasswordMenu extends JPanel implements ActionListener {
    private JLabel currentLabel;
    private JLabel infoLabel;
    private JPasswordField currentField;
    private JLabel newLabel;
    private JPasswordField newField;
    private JButton changeButton;
    private JLabel confirmButton;
    private JPasswordField repeatField;

    public ResetPasswordMenu() {
        Loop.getInstance().killLoop();

        //construct components
        currentLabel = new JLabel ("Current Password:");
        infoLabel = new JLabel ("Change your password");
        currentField = new JPasswordField (5);
        newLabel = new JLabel ("New Password:");
        newField = new JPasswordField (5);
        changeButton = new JButton ("Change Pass");
        changeButton.addActionListener(this);
        changeButton.setActionCommand("change pass");

        confirmButton = new JLabel ("Confirm Password:");
        repeatField = new JPasswordField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension (697, 430));
        setLayout (null);

        //add components
        add (currentLabel);
        add (infoLabel);
        add (currentField);
        add (newLabel);
        add (newField);
        add (changeButton);
        add (confirmButton);
        add (repeatField);

        //set component bounds (only needed by Absolute Positioning)
        currentLabel.setBounds (200, 145, 120, 25);
        infoLabel.setBounds (125, 70, 145, 25);
        currentField.setBounds (320, 150, 145, 25);
        newLabel.setBounds (200, 185, 100, 25);
        newField.setBounds (320, 190, 145, 25);
        changeButton.setBounds (435, 280, 115, 30);
        confirmButton.setBounds (200, 225, 115, 25);
        repeatField.setBounds (320, 230, 145, 25);
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new ResetPasswordMenu());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        if(e.getActionCommand().equals("change pass")){
            String newPass =  String.valueOf(newField.getPassword());
            if(!PasswordHashing.generateHash(String.valueOf(currentField.getPassword())).
                    equals(user.getPassword())){
                frame.setSysMessageText("incorrect password");
                return;
            }

            if(!newPass.equals(String.valueOf(repeatField.getPassword()))){
                frame.setSysMessageText("new password and repeat are not same");
                return;
            }

            if(String.valueOf(currentField.getPassword()).equals(newPass)){
                frame.setSysMessageText("new password should be different");
                return;
            }

            ServerResponse response = Controller.getInstance().getLibrary().changePassword(newPass);

            if(response.isFlag()) {
                frame.setSysMessageText("password changed");
                user.setPassword(String.valueOf(newField.getPassword()));

                if (user instanceof Student) frame.addComponent(new StudentMainMenu());
                else frame.addComponent(new MasterMainMenu());

            }

            frame.setSysMessageText(response.getServerMessage());
        }
    }
}