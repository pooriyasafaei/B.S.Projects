package client.gui.messanger;

import client.controller.Controller;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.request.Request;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PopUpText extends JPanel implements ActionListener{
    private JLabel fromLabel;
    private JLabel textLabel;
    private JTextArea messageArea;
    private JButton acceptButton;
    private JButton rejectButton;

    private JScrollPane pane;

    private Request request;
    private static JFrame frame;

    public PopUpText(String from, String text, Request request) {

        this.request = request;
        //construct components
        fromLabel = new JLabel ("From: " + from);
        textLabel = new JLabel ("Text: ");

        messageArea = new JTextArea ("text");
        messageArea.setText(text);
        messageArea.setFont(new Font("Serif", Font.ITALIC, 15));
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setOpaque(false);
        messageArea.setEditable(false);

        pane = new JScrollPane(messageArea);

        acceptButton = new JButton ("accept");
        acceptButton.addActionListener(this);
        acceptButton.setActionCommand("accept");

        rejectButton = new JButton ("reject");
        rejectButton.addActionListener(this);
        rejectButton.setActionCommand("reject");

        //adjust size and set layout
        setPreferredSize (new Dimension (500, 408));
        setLayout (null);

        //add components
        add (fromLabel);
        add (textLabel);
        add (pane);
        long id = Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber();
        if(request != null && !request.isAnswered() && (request.getReceiverId() == id || request.getSecondReceiverId() == id)){
            add(acceptButton);
            add(rejectButton);
        }

        //set component bounds (only needed by Absolute Positioning)
        fromLabel.setBounds (10, 0, 490, 25);
        textLabel.setBounds (5, 25, 45, 25);
        pane.setBounds (5, 50, 490, 305);
        acceptButton.setBounds (335, 375, 75, 25);
        rejectButton.setBounds (415, 375, 70, 25);
    }



    public static void popUp(String from, String text, Request request){
        frame = new JFrame ("Message");
        frame.setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add (new PopUpText(from, text, request));
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        ServerResponse response = Controller.getInstance().getLibrary().determineRequestResult(request.getRequestId(),
                user.getIdNumber(), e.getActionCommand().equals("accept"), "");
        frame.setSysMessageText(response.getServerMessage());

        PopUpText.frame.dispose();
    }
}
