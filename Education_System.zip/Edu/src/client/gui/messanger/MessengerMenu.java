package client.gui.messanger;

import client.controller.Controller;
import client.controller.Loop;
import client.controller.support.Message;
import client.gui.MainPanel;
import client.gui.edu_services.request.RequestType;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ChatPublicInfo;
import client.gui.table.objects_table_module.UserPublicInfo;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import communication.server.ServerResponse;
import server.logic.messenger.TextBox;
import server.logic.users.User;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class MessengerMenu extends JPanel implements ActionListener {
    private JTable chatsPanel;
    private JLabel chatsLabel;
    private JLabel peopleLabel;
    private JTable peoplePanel;
    private JLabel idsLabel;
    private JTextField idsField;
    private JButton chatRequestButton;
    private JLabel messageLabel;
    private JTextField sendRequestIdField;
    private JButton sendButton;
    private JLabel idRequestLabel;
    private JTextField messageField;
    private JButton openChatButton;
    private JTextField chatIdField;


    private LinkedList<User> related;

    private AbstractTableModel tableModel1;
    private JScrollPane pane1;

    private AbstractTableModel tableModel2;
    private JScrollPane pane2;

    public MessengerMenu() {

        Loop.getInstance().killLoop();

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        related = Controller.getInstance().getOfflineData().getRelatedUsers(user.getIdNumber());

        //construct components
        tableModel1 = TableModel.createTableModel(ChatPublicInfo.class,
                ChatPublicInfo.tableList(DateTime.sortChatsByTime(user.getChats())));
        chatsPanel = new JTable(tableModel1);
        pane1 = new JScrollPane(chatsPanel);


        tableModel2 = TableModel.createTableModel(UserPublicInfo.class, UserPublicInfo.tableList(related));
        peoplePanel = new JTable(tableModel2);
        pane2 = new JScrollPane(peoplePanel);

        chatsLabel = new JLabel ("Chats:");
        peopleLabel = new JLabel ("People:");
        idsLabel = new JLabel ("Enter ids with ','");
        idsField = new JTextField (5);
        chatRequestButton = new JButton ("send chat request");
        chatRequestButton.addActionListener(this);
        chatRequestButton.setActionCommand("chat request");

        messageLabel = new JLabel ("Message:");
        sendRequestIdField = new JTextField (5);

        sendButton = new JButton ("send");
        sendButton.addActionListener(this);
        sendButton.setActionCommand("send");

        idRequestLabel = new JLabel ("ID:");
        messageField = new JTextField (5);

        openChatButton = new JButton ("open chat");
        openChatButton.addActionListener(this);
        openChatButton.setActionCommand("open chat");

        chatIdField = new JTextField (5);

        //set components properties
        idsField.setToolTipText ("Enter id's you want to text or empty this place to send all");
        sendRequestIdField.setToolTipText ("Enter contact id to send a chat request");
        sendButton.setToolTipText ("Press to send message for contacts");
        messageField.setToolTipText ("Enter message here");

        //adjust size and set layout
        setPreferredSize (new Dimension (866, 576));
        setLayout (null);

        //add components
        add (pane1);
        add (chatsLabel);
        add (peopleLabel);
        add (pane2);
        add (openChatButton);
        add (chatIdField);

        if(Controller.getInstance().isOnline()){
            add(idsLabel);
            add(idsField);
            add(chatRequestButton);
            add(messageLabel);
            add(sendRequestIdField);
            add(sendButton);
            add(idRequestLabel);
            add(messageField);
        }

        //set component bounds (only needed by Absolute Positioning)
        pane1.setBounds (0, 30, 865, 255);
        chatsLabel.setBounds (5, 0, 125, 25);
        peopleLabel.setBounds (5, 285, 100, 25);
        pane2.setBounds (0, 310, 410, 160);
        idsLabel.setBounds (460, 340, 95, 25);
        idsField.setBounds (580, 340, 180, 30);
        chatRequestButton.setBounds (255, 475, 140, 25);
        messageLabel.setBounds (460, 390, 60, 25);
        messageField.setBounds (580, 375, 180, 125);
        sendRequestIdField.setBounds (40, 475, 180, 25);
        sendButton.setBounds (480, 475, 65, 25);
        idRequestLabel.setBounds (0, 475, 40, 25);
        openChatButton.setBounds (650, 290, 100, 25);
        chatIdField.setBounds (765, 290, 100, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);
        
        revalidate();
        repaint();
    }


    public void reInitialize(){
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        related = Controller.getInstance().getOfflineData().getRelatedUsers(user.getIdNumber());

        remove(pane1);
        remove(pane2);

        tableModel1 = TableModel.createTableModel(ChatPublicInfo.class,
                ChatPublicInfo.tableList(DateTime.sortChatsByTime(user.getChats())));
        chatsPanel = new JTable(tableModel1);
        pane1 = new JScrollPane(chatsPanel);


        tableModel2 = TableModel.createTableModel(UserPublicInfo.class, UserPublicInfo.tableList(related));
        peoplePanel = new JTable(tableModel2);
        pane2 = new JScrollPane(peoplePanel);

        add(pane1);
        add(pane2);

        pane1.setBounds (0, 30, 865, 255);
        pane2.setBounds (0, 310, 410, 160);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new MessengerMenu());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getActionCommand().equals("send")){
            String[] usersId = idsField.getText().split(",");
            try{
                Controller.getInstance().getLibrary().refreshPublicInfo();

                LinkedList<User> users = new LinkedList<>();
                for (String userId: usersId) {
                    User user = Controller.getInstance().getOfflineDataNoUpdate().getUserById(Long.parseLong(userId));
                    if(!Controller.getInstance().getOfflineDataNoUpdate().containsId(related, user.getIdNumber())){
                        MainPanel.getInstance().setSysMessageText("you can't text some of users");
                        return;
                    }

                    users.add(user);
                }

                for (User user: users) {
                    Controller.getInstance().getLibrary().sendMessageViaMessenger(
                            new Message(Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber(),
                                    user.getIdNumber(), messageField.getText()));
                }

                MainPanel.getInstance().setSysMessageText("message sent for selected users");

            }catch (Exception exception){
                exception.printStackTrace();
                MainPanel.getInstance().setSysMessageText("invalid input or id number");
            }
        }

        if(e.getActionCommand().equals("open chat")){
            try {
                User user = Controller.getInstance().getLibrary().refreshPublicInfo();
                TextBox textBox = user.getChat(Long.parseLong(chatIdField.getText()));

                if(textBox == null){
                    MainPanel.getInstance().setSysMessageText("chat doesn't exist");
                    return;
                }

                MainPanel.getInstance().addComponent(new ChatPage(user.getIdNumber(), textBox.getContactId()));
                return;

            }catch (Exception exception){
                MainPanel.getInstance().setSysMessageText("invalid input");
            }

        }

        if(e.getActionCommand().equals("chat request")){
            try {
                User user = Controller.getInstance().getOfflineData().getUserById(Long.parseLong(sendRequestIdField.getText()));
                if(user == null){
                    MainPanel.getInstance().setSysMessageText("user doesnt exist");
                    return;
                }

                ClientRequest request = new ClientRequest();
                request.setType(ClientRequestType.RegisterNewRequest);
                request.addData("senderId", Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber());
                request.addData("receiverId", user.getIdNumber());
                request.addData("requestType", RequestType.ChatRequest);

                ServerResponse response = Controller.getInstance().getLibrary().registerNewRequest(request);
                MainPanel.getInstance().setSysMessageText(response.getServerMessage());


            }catch (Exception exception){
                MainPanel.getInstance().setSysMessageText("invalid input");
            }
        }

    }
}
