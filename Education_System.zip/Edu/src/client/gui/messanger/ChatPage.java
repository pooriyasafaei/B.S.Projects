package client.gui.messanger;

import client.controller.Controller;
import client.controller.Loop;
import client.controller.support.Message;
import client.controller.support.MessagesToSend;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.messenger.TextBox;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.text.DefaultCaret;

public class ChatPage extends JPanel implements ActionListener {
    private JLabel pictureIcon;
    private JLabel nameLabel;
    private JLabel idLabel;
    private JLabel lastSeenLabel;
    private TextBoxArea conversationPlot;
    private JTextField messageField;
    private JButton sendButton;
    private JLabel help1Label;
    private JLabel help2Label;

    private JScrollPane pane;
    private long contact;
    private long sender;

    public ChatPage(long sender, long contact) {
        Loop.getInstance().killLoop();

        this.sender = sender;
        this.contact = contact;

        User user = Controller.getInstance().getOfflineData().getUserById(contact);
        //construct components
        pictureIcon = new JLabel ("picture here");

        if(Controller.getInstance().isOnline()){
            pictureIcon.setIcon(Controller.getInstance().getLibrary().getPicture(contact));

        } else{
            File file = new File(Controller.getProperties().getProperty("pictures_path") + contact + ".jpg");
            if(file.isFile()) pictureIcon.setIcon(new
                    ImageIcon(Controller.getProperties().getProperty("pictures_path") + contact + ".jpg"));

            else pictureIcon.setIcon(new
                    ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));
        }
        nameLabel = new JLabel ("Name: " + user.getName());
        idLabel = new JLabel ("ID: " + user.getIdNumber());
        lastSeenLabel = new JLabel ("Last Seen: " );

        conversationPlot = new TextBoxArea(Controller.getInstance().getLibrary().refreshPublicInfo().getChat(contact));
        pane = new JScrollPane(conversationPlot);

        pane.setBorder(BorderFactory.createMatteBorder(
                1, 1, 2, 3, Color.darkGray));

        messageField = new JTextField (5);

        sendButton = new JButton ("send");
        sendButton.addActionListener(this);
        sendButton.setActionCommand("send");

        help1Label = new JLabel ("help: @download + (File Name)");
        help2Label = new JLabel ("@upload + (File Path)");

        //adjust size and set layout
        setPreferredSize (new Dimension (640, 438));
        setLayout (null);

        //add components
        add (pictureIcon);
        add (nameLabel);
        add (idLabel);
        add (lastSeenLabel);
        add (pane);
        add (messageField);

        if(Controller.getInstance().isOnline() || contact == 1){
            add(sendButton);
            add(help1Label);
            add(help2Label);
        }

        //set component bounds (only needed by Absolute Positioning)
        pictureIcon.setBounds (15, 10, 90, 120);
        nameLabel.setBounds (5, 145, 240, 25);
        idLabel.setBounds (5, 175, 100, 25);
        lastSeenLabel.setBounds (5, 200, 195, 25);
        pane.setBounds (245, 30, 395, 345);
        messageField.setBounds (245, 375, 330, 25);
        sendButton.setBounds (575, 375, 65, 25);
        help1Label.setBounds (5, 295, 200, 25);
        help2Label.setBounds (5, 325, 200, 25);

        pane.setBackground(new Color(60, 190, 246));

        Loop.getInstance().makePingLoop(this::reInitialize);

        JScrollBar vertical = pane.getVerticalScrollBar();
        vertical.setValue( vertical.getMaximum() );

        revalidate();
        repaint();
    }

    public void reInitialize(){

        User user = Controller.getInstance().getOfflineData().getUserById(contact);
        //construct components

        if(Controller.getInstance().isOnline()){

            pictureIcon.setIcon(Controller.getInstance().getLibrary().getPicture(contact));
        } else{
            File file = new File(Controller.getProperties().getProperty("pictures_path") + contact + ".jpg");
            if(file.isFile()) pictureIcon.setIcon(new
                    ImageIcon(Controller.getProperties().getProperty("pictures_path") + contact + ".jpg"));

            else pictureIcon.setIcon(new
                    ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));
        }
        nameLabel.setText("Name: " + user.getName());
        idLabel.setText("ID: " + user.getIdNumber());
        lastSeenLabel.setText("Last Seen: ");

        TextBox newBox = Controller.getInstance().getLibrary().refreshPublicInfo().getChat(contact);

        if(!newBox.equals(conversationPlot.getTextBox())){
            remove(pane);

            conversationPlot = new TextBoxArea(newBox);
            pane = new JScrollPane(conversationPlot);

            pane.setBorder(BorderFactory.createMatteBorder(
                    1, 1, 2, 3, Color.darkGray));

            conversationPlot.setFont(new Font("Serif", Font.ITALIC, 15));
            conversationPlot.setLineWrap(true);
            conversationPlot.setWrapStyleWord(true);
            conversationPlot.setOpaque(false);
            conversationPlot.setEditable(false);
            DefaultCaret caret = (DefaultCaret) conversationPlot.getCaret();
            caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

            add(pane);
            pane.setBounds (245, 30, 395, 345);
            JScrollBar vertical = pane.getVerticalScrollBar();
            vertical.setValue( vertical.getMaximum() );

        }

        revalidate();
        repaint();
    }

    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
   //     frame.getContentPane().add (new ChatPage(0));
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("send")){
            if(messageField.getText().equals("")) return;

            if(contact == 1){
                MessagesToSend.getInstance().addMessage(sender, contact, messageField.getText());
                messageField.setText("");
                return;
            }

            ServerResponse response = Controller.getInstance().getLibrary().
                    sendMessageViaMessenger(new Message(sender, contact, messageField.getText()));

            messageField.setText("");
            MainPanel.getInstance().setSysMessageText(response.getServerMessage());
        }
    }
}
