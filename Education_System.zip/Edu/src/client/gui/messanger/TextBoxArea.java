package client.gui.messanger;

import client.controller.Controller;
import server.logic.messenger.TextBox;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;

public class TextBoxArea extends JTextArea {

    private TextBox textBox;

    public TextBoxArea(TextBox textBox) {
        this.textBox = textBox;
        this.setText("");

        setBody();

        this.setFont(new Font("Serif", Font.ITALIC, 15));
        this.setLineWrap(true);
        this.setWrapStyleWord(true);
        this.setOpaque(false);
        this.setEditable(false);
        DefaultCaret caret = (DefaultCaret) this.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
    }

    public void setBody(){
        if(!Controller.getInstance().isOnline()){
            for(int i = Math.max(0, textBox.getAllChat().size() -  15); i < textBox.getAllChat().size(); i++){
                this.setText(this.getText() + "\n" + textBox.getAllChat().get(i));

            }
        }
        else for (String message: textBox.getAllChat()){
            this.setText(this.getText() + "\n\n" + message);
        }
    }

    public TextBox getTextBox() {
        return textBox;
    }

    public void setTextBox(TextBox textBox) {
        this.textBox = textBox;
        setBody();
    }
}
