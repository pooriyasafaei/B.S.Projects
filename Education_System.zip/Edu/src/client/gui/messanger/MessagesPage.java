package client.gui.messanger;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.NotifInfo;
import server.logic.request.Request;
import server.logic.request.RequestTypes;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class MessagesPage extends JPanel implements ActionListener {
    private JLabel messagesLabel;
    private JTable messagesTable;
    private JTextField messageIdField;
    private JButton openButton;
    private JLabel messageIdLabel;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    private LinkedList<Request> messages;

    public MessagesPage() {
        Loop.getInstance().killLoop();
        //construct components
        messagesLabel = new JLabel ("Messages:");

        messages = Controller.getInstance().getOfflineDataNoUpdate().
                getMessagesSorted(Controller.getInstance().getLibrary().refreshPublicInfo());

        tableModel = TableModel.createTableModel(NotifInfo.class, NotifInfo.tableList(messages));

        messagesTable = new JTable (tableModel);
        pane = new JScrollPane(messagesTable);


        messageIdField = new JTextField (5);

        openButton = new JButton ("Open");
        openButton.addActionListener(this);
        openButton.setActionCommand("open");

        messageIdLabel = new JLabel ("Message ID:");

        //adjust size and set layout
        setPreferredSize (new Dimension (619, 468));
        setLayout (null);

        //add components
        add (messagesLabel);
        add (pane);
        add (messageIdField);
        add (openButton);
        add (messageIdLabel);

        //set component bounds (only needed by Absolute Positioning)
        messagesLabel.setBounds (10, 0, 100, 25);
        pane.setBounds (0, 30, 620, 325);
        messageIdField.setBounds (420, 385, 100, 25);
        openButton.setBounds (535, 385, 75, 25);
        messageIdLabel.setBounds (340, 385, 80, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        messages = Controller.getInstance().getOfflineDataNoUpdate().
                getMessagesSorted(Controller.getInstance().getLibrary().refreshPublicInfo());

        remove(pane);

        tableModel = TableModel.createTableModel(NotifInfo.class, NotifInfo.tableList(messages));

        messagesTable = new JTable (tableModel);
        pane = new JScrollPane(messagesTable);

        add (pane);
        pane.setBounds (0, 30, 620, 325);

        revalidate();
        repaint();
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        Request request = null;

        try {
            for (Request r : messages) {
                if (r.getRequestId() == Long.parseLong(messageIdField.getText())) {
                    request = r;
                    break;
                }
            }

            if(request == null){
                MainPanel.getInstance().setSysMessageText("message doesn't exist");
                return;
            }

            PopUpText.popUp(request.getType().equals(RequestTypes.SystemMessage) ? "System" :
                    String.valueOf(request.getApplicantId()), request.getText(), request);

        }catch (Exception exception){
            MainPanel.getInstance().setSysMessageText("invalid input");
        }

    }
}
