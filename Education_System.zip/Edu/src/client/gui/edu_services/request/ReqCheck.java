package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import server.logic.request.Request;
import server.logic.users.Master;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ReqCheck extends JPanel implements ActionListener {
    private JLabel requestsListLabel;
    private JLabel idLabel;
    private JLabel typeLabel;
    private JLabel applicantIdLabel;
    private JLabel dateLabel;
    private JTextArea infoLabel;
    private JTextArea answerText;
    private JLabel answerLabel;
    private JButton acceptButton;
    private JButton rejectButton;
    protected Request request;

    public ReqCheck(Request request) {
        Loop.getInstance().killLoop();
        this.request = request;
        //construct components
        requestsListLabel = new JLabel ("Requests:");
        idLabel = new JLabel ("Req ID: " + request.getRequestId());
        typeLabel = new JLabel ("Req Type: " + request.getType().name());
        applicantIdLabel = new JLabel ("Applicant Name: " + Controller.getInstance().getOfflineData().getUserById
                (request.getApplicantId()).getName());
        dateLabel = new JLabel ("Req date: " + request.getRegisteredTime().toString());
        infoLabel = new JTextArea ("Request full information: " + request.getText());
        infoLabel.setFont(new Font("Serif", Font.ITALIC, 15));
        infoLabel.setLineWrap(true);
        infoLabel.setWrapStyleWord(true);
        infoLabel.setOpaque(false);
        infoLabel.setEditable(false);

        answerText = new JTextArea (5, 5);
        answerLabel = new JLabel ("Answer:");
        acceptButton = new JButton ("Accept");
        acceptButton.addActionListener(this);
        acceptButton.setActionCommand("accept");

        rejectButton = new JButton ("Reject");
        rejectButton.addActionListener(this);
        rejectButton.setActionCommand("reject");

        //adjust size and set layout
        setPreferredSize (new Dimension (690, 430));
        setLayout (null);

        //add components
        add (requestsListLabel);
        add (idLabel);
        add (typeLabel);
        add (applicantIdLabel);
        add (dateLabel);
        add (infoLabel);
        add (answerText);
        add (answerLabel);
        add (acceptButton);
        add (rejectButton);

        //set component bounds (only needed by Absolute Positioning)
        requestsListLabel.setBounds (5, 0, 95, 30);
        idLabel.setBounds (145, 25, 200, 25);
        typeLabel.setBounds (145, 50, 200, 25);
        applicantIdLabel.setBounds (145, 75, 400, 25);
        dateLabel.setBounds (145, 100, 200, 25);
        infoLabel.setBounds (155, 145, 400, 100);
        answerText.setBounds (225, 260, 350, 110);
        answerLabel.setBounds (145, 240, 80, 25);
        acceptButton.setBounds (130, 310, 75, 25);
        rejectButton.setBounds (130, 345, 75, 25);
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
       // frame.addComponent(new ReqCheck());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Master user = (Master) (Controller.getInstance().getLibrary().refreshPublicInfo());
        String command = e.getActionCommand();

        if(command.equals("accept")){
            Controller.getInstance().getLibrary().determineRequestResult
                    (request.getRequestId(), user.getIdNumber(), true, answerText.getText());
        }

        if (command.equals("reject")){
            Controller.getInstance().getLibrary().determineRequestResult
                    (request.getRequestId(), user.getIdNumber(), false, answerText.getText());
        }

        frame.addComponent(new ReqAcceptorTable());
    }
}
