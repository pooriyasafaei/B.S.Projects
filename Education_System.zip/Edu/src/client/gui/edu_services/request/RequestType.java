package client.gui.edu_services.request;

public enum RequestType {
    Recommendation, StudyCertificate, Minor, QuitStudy,
    Dorm, ThesisDefenceTime, ChatRequest, EnrollCourse
}
