package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ReqInfo;
import server.logger.Logger;
import server.logic.request.Request;
import server.logic.users.Master;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class ReqAcceptorTable extends JPanel implements ActionListener {
    private JTable reqTable;
    private JLabel reqLabel;
    private JLabel reqIdLabel;
    private JTextField reqIdField;
    private JButton detailButton;

    protected AbstractTableModel tableModel;
    protected JScrollPane pane;

    public ReqAcceptorTable() {
        Loop.getInstance().killLoop();
        //construct components
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        tableModel = TableModel.createTableModel(ReqInfo.class, ReqInfo.tableList(user.getRequests()));
        reqTable = new JTable (tableModel);
        pane = new JScrollPane(reqTable);

        reqLabel = new JLabel ("Requests:");
        reqIdLabel = new JLabel ("Request ID:");
        reqIdField = new JTextField (5);
        detailButton = new JButton ("see details");
        detailButton.addActionListener(this);
        detailButton.setActionCommand("details");

        //adjust size and set layout
        setPreferredSize (new Dimension (881, 430));
        setLayout (null);

        //add components
        add (pane);
        add (reqLabel);
        add (reqIdLabel);
        add (reqIdField);
        add (detailButton);

        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (15, 30, 865, 325);
        reqLabel.setBounds (5, 0, 100, 25);
        reqIdLabel.setBounds (5, 360, 80, 25);
        reqIdField.setBounds (75, 360, 100, 25);
        detailButton.setBounds (190, 360, 100, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        remove(pane);
        tableModel = TableModel.createTableModel(ReqInfo.class, ReqInfo.tableList(user.getRequests()));
        reqTable = new JTable (tableModel);
        pane = new JScrollPane(reqTable);

        add(pane);
        pane.setBounds (15, 30, 865, 325);

        revalidate();
        repaint();
    }




    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new ReqAcceptorTable());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Master user = (Master) (Controller.getInstance().getLibrary().refreshPublicInfo());
        String command = e.getActionCommand();

        if (command.equals("details")){
            try {
                Request request = user.getReq(Long.parseLong(reqIdField.getText()));
                if (request == null){
                    frame.setSysMessageText("request with that id doesn't exist");
                    return;
                }

                if(request.finalResult().equals("pending")){
                    frame.addComponent(new ReqCheck(request));
                    return;
                }

                frame.addComponent(new ReqDetails(request));

            }catch (Exception ex){

                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
                return;
            }
        }
    }
}
