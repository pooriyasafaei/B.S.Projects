package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ReqInfo;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import server.logger.Logger;
import server.logic.request.Request;
import server.logic.users.Student;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class ReqTable extends JPanel implements ActionListener {
    protected JComboBox reqTypeBox;
    protected JTable requestsTable;
    protected JLabel requestsListLabel;
    protected JTextArea detailText;
    protected JLabel infoLabel;
    protected JLabel detailLabel;
    protected JTextField reqIdField;
    protected JButton registerButton;
    protected JButton detailButton;
    protected JLabel masterIdLabel;
    protected JTextField IdField;

    protected AbstractTableModel tableModel;
    protected JScrollPane pane;

    public ReqTable() {
        Loop.getInstance().killLoop();
        //construct preComponents
        Student user = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();

        tableModel = TableModel.createTableModel(ReqInfo.class, ReqInfo.tableList(user.getRequests()));

        //construct components
        requestsTable = new JTable (tableModel);
        pane = new JScrollPane(requestsTable);

        requestsListLabel = new JLabel ("Requests:");
        detailText = new JTextArea (5, 5);
        infoLabel = new JLabel ("Select request type then enter request text and register it");
        detailLabel = new JLabel ("Show Req Details: (req ID)");
        reqIdField = new JTextField (5);
        registerButton = new JButton ("Register");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("register");

        detailButton = new JButton("Details");
        detailButton.addActionListener(this);
        detailButton.setActionCommand("details");

        masterIdLabel = new JLabel("ID(for recom or minor):");
        IdField = new JTextField(5);

        //set components properties
        detailText.setToolTipText ("Enter details of your req");
        reqIdField.setToolTipText ("Enter request id to show more details about it");

        //adjust size and set layout
        setPreferredSize (new Dimension (880, 500));
        setLayout (null);

        //add components
        if(Controller.getInstance().isOnline()){
            add (detailText);
            add (registerButton);
            add (masterIdLabel);
            add (IdField);
        }

        add(pane);
        add (requestsListLabel);
        add (infoLabel);
        add (detailLabel);
        add (reqIdField);
        add (detailButton);


        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (10, 30, 870, 245);
        requestsListLabel.setBounds (5, 0, 100, 25);
        detailText.setBounds (360, 280, 500, 90);
        infoLabel.setBounds (5, 275, 330, 30);
        detailLabel.setBounds (5, 430, 155, 25);
        reqIdField.setBounds (165, 430, 110, 25);
        detailButton.setBounds(285, 430, 100, 25);
        registerButton.setBounds (760, 375, 85, 25);
        masterIdLabel.setBounds(5, 350, 150, 25);
        IdField.setBounds(165, 350, 110, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        Student user = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();

        remove(pane);
        tableModel = TableModel.createTableModel(ReqInfo.class, ReqInfo.tableList(user.getRequests()));

        //construct components
        requestsTable = new JTable (tableModel);
        pane = new JScrollPane(requestsTable);

        add(pane);

        pane.setBounds (10, 30, 870, 245);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new PhdReqTable());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Student user = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();
      //  Edu edu = Edu.getInstance();

        if (command.equals("details")){
            try {
                long id = Long.parseLong(reqIdField.getText());
                Request request = user.getReq(id);

                if (request == null){
                    frame.setSysMessageText("request with that id doesn't exist");
                    return;
                }
                Loop.getInstance().killLoop();
                frame.addComponent(new ReqDetails(request));


            }catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
                return;
            }
        }

        if(command.equals("register")){

            ClientRequest request = new ClientRequest();
            request.setType(ClientRequestType.RegisterNewRequest);

            try {
                String type = String.valueOf(reqTypeBox.getSelectedItem());

                if(type.equals("QuitStudy")){

                    request.addData("requestType", RequestType.QuitStudy);
                    request.addData("studentId", user.getIdNumber());

                    Controller.getInstance().getLibrary().registerNewRequest(request);
                }

                if (type.equals("StudyCertificate")){

                    request.addData("requestType", RequestType.StudyCertificate);
                    request.addData("studentId", user.getIdNumber());

                    Controller.getInstance().getLibrary().registerNewRequest(request);
                }

                Loop.getInstance().killLoop();
                frame.addComponent(new BachelorReqTable());

            }catch (Exception ex){

                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
                return;
            }
        }

    }
}
