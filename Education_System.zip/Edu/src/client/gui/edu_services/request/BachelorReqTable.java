package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class BachelorReqTable extends ReqTable{

    public BachelorReqTable(){
        super();

        String[] reqTypeBoxItems = {"Req type", "Recommendation", "StudyCertificate", "Minor", "QuitStudy"};

        reqTypeBox = new JComboBox (reqTypeBoxItems);

        if(Controller.getInstance().isOnline()) add (reqTypeBox);

        reqTypeBox.setBounds (230, 305, 100, 25);

       // System.out.println(reqTypeBox.getSelectedItem());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        super.actionPerformed(e);
        MainPanel frame = MainPanel.getInstance();
        Student user = (Student)Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("register")){

            ClientRequest request = new ClientRequest();
            request.setType(ClientRequestType.RegisterNewRequest);

            try {
                String type = String.valueOf(reqTypeBox.getSelectedItem());

                if(type.equals("Recommendation")){

                    User master = Controller.getInstance().getOfflineData().getUserById(Long.parseLong(IdField.getText()));
                    if(!(master instanceof Master)){
                        frame.setSysMessageText("Master with that id doesn't exist");
                        return;
                    }

                    request.addData("requestType", RequestType.Recommendation);
                    request.addData("studentId", user.getIdNumber());
                    request.addData("masterId", master.getIdNumber());
                    request.addData("text", detailText.getText());


                    Controller.getInstance().getLibrary().registerNewRequest(request);
                }

                if(type.equals("Minor")){
                    College college = Controller.getInstance().getOfflineData()
                            .getCollegeById(Integer.parseInt(IdField.getText()));

                    if(college == null){
                        frame.setSysMessageText("College with that id doesn't exist");
                        return;
                    }

                    request.addData("requestType", RequestType.Minor);
                    request.addData("studentId", user.getIdNumber());
                    request.addData("chancellorId", college.getChancellorId());
                    request.addData("text", detailText.getText());

                    Controller.getInstance().getLibrary().registerNewRequest(request);
                }

                frame.addComponent(new BachelorReqTable());

            }catch (Exception ex){
                Logger.logException(this, "actionPerformed", "inputException");

                frame.setSysMessageText("invalid inputs");
                return;
            }
        }
    }
}
