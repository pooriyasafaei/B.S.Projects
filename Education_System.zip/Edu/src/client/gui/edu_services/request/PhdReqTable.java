package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import server.logger.Logger;
import server.logic.users.Student;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class PhdReqTable extends ReqTable{

    public PhdReqTable(){
        super();

        String[] reqTypeBoxItems = {"Req type", "StudyCertificate", "ThesisDefenceTime", "QuitStudy"};

        reqTypeBox = new JComboBox(reqTypeBoxItems);

        add (reqTypeBox);

        reqTypeBox.setBounds (230, 305, 100, 25);

        System.out.println(reqTypeBox.getSelectedItem().equals("Req type"));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        super.actionPerformed(e);
        MainPanel frame = MainPanel.getInstance();
        Student user = (Student)Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("register")){
            ClientRequest request = new ClientRequest();
            request.setType(ClientRequestType.RegisterNewRequest);

            try {
                String type = String.valueOf(reqTypeBox.getSelectedItem());

                if(type.equals("ThesisDefenceTime")){

                    request.addData("requestType", RequestType.ThesisDefenceTime);
                    request.addData("studentId", user.getIdNumber());
                    request.addData("text", detailText.getText());

                    Controller.getInstance().getLibrary().registerNewRequest(request);
                }

                frame.addComponent(new PhdReqTable());

            }catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
                return;
            }
        }
    }
}
