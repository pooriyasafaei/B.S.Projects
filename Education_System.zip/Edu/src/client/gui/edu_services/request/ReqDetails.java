package client.gui.edu_services.request;

import client.controller.Controller;
import client.controller.Loop;
import server.logic.request.Request;

import java.awt.*;
import javax.swing.*;

public class ReqDetails extends JPanel {
    private JLabel requestLabel;
    private JLabel idLabel;
    private JLabel typeLabel;
    private JLabel applicantNameLabel;
    private JLabel dateLabel;
    private JLabel applicantTexLabel;
    private JTextArea infoLabel;
    private JLabel answerLabel;
    private JTextArea answerTextArea;
    private JLabel statusLabel;

    protected Request request;

    public ReqDetails(Request request) {
        Loop.getInstance().killLoop();

        initialize(request);

        Loop.getInstance().makePingLoop(this::reInitialize);
    }

    public void initialize(Request request){
        this.request = request;
        //construct components
        requestLabel = new JLabel ("Request:");
        idLabel = new JLabel ("Req ID: " + request.getRequestId());
        typeLabel = new JLabel ("Req Type: " + request.getType().name());
        applicantNameLabel = new JLabel ("Applicant Name: " + Controller.getInstance().getOfflineData().getUserById
                (request.getApplicantId()).getName());
        dateLabel = new JLabel ("Req date: " + request.getRegisteredTime().toString());
        applicantTexLabel = new JLabel ("Req text and info:");
        infoLabel = new JTextArea (request.getText());
        answerLabel = new JLabel ("Answer:");
        answerTextArea = new JTextArea (request.getResponseText());
        statusLabel = new JLabel ("Answer status: " + request.finalResult());

        infoLabel.setFont(new Font("Serif", Font.ITALIC, 15));
        infoLabel.setLineWrap(true);
        infoLabel.setWrapStyleWord(true);
        infoLabel.setOpaque(false);
        infoLabel.setEditable(false);

        answerTextArea.setFont(new Font("Serif", Font.ITALIC, 15));
        answerTextArea.setLineWrap(true);
        answerTextArea.setWrapStyleWord(true);
        answerTextArea.setOpaque(false);
        answerTextArea.setEditable(false);

        //adjust size and set layout
        setPreferredSize (new Dimension (690, 430));
        setLayout (null);

        //add components
        add (requestLabel);
        add (idLabel);
        add (typeLabel);
        add (applicantNameLabel);
        add (dateLabel);
        add (applicantTexLabel);
        add (infoLabel);
        add (answerLabel);
        add (answerTextArea);
        add (statusLabel);

        //set component bounds (only needed by Absolute Positioning)
        requestLabel.setBounds (5, 0, 95, 30);
        idLabel.setBounds (145, 25, 200, 25);
        typeLabel.setBounds (145, 50, 200, 25);
        applicantNameLabel.setBounds (145, 75, 400, 25);
        dateLabel.setBounds (145, 100, 200, 25);
        applicantTexLabel.setBounds (145, 125, 190, 25);
        infoLabel.setBounds (155, 145, 300, 100);
        answerLabel.setBounds (145, 245, 80, 25);
        answerTextArea.setBounds (155, 270, 300, 100);
        statusLabel.setBounds (380, 245, 215, 25);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        initialize(Controller.getInstance()
                .getLibrary().refreshPublicInfo().getReq(request.getRequestId()));
    }

}
