package client.gui.edu_services;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ExamTimeInfo;
import server.logic.courses.Course;
import server.logic.users.User;
import server.time.DateTime;

import java.awt.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class ExamsList extends JPanel {

    private JTable examsTable;
    private JLabel examsLabel;

    AbstractTableModel tableModel;
    JScrollPane pane;

    public ExamsList() {
        Loop.getInstance().killLoop();

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        LinkedList<Course> courses;

        courses = DateTime.sortCoursesByExamTime
                (Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber()));

        tableModel = TableModel.
                createTableModel(ExamTimeInfo.class, ExamTimeInfo.tableList(courses));

        //construct components
        examsTable = new JTable (tableModel);
        pane = new JScrollPane(examsTable);

        examsLabel = new JLabel ("List of exams:");

        //adjust size and set layout
        setPreferredSize (new Dimension (880, 430));
        setLayout (null);

        //add components
        add(pane);
        add (examsLabel);

        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (10, 30, 865, 335);
        examsLabel.setBounds (5, 0, 100, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        LinkedList<Course> courses;
        courses = DateTime.sortCoursesByExamTime
                (Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber()));

        this.remove(pane);

        tableModel = TableModel.
                createTableModel(ExamTimeInfo.class, ExamTimeInfo.tableList(courses));

        //construct components
        pane = new JScrollPane(examsTable);
        add(pane);

        pane.setBounds (10, 30, 865, 335);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new ExamsList());
    }
}
