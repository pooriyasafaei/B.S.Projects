package client.gui.edu_services;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.WeeklyScheduleInfo;
import server.logic.courses.Course;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class WeeklySchedule extends JPanel {

    private JTable scheduleTable;
    private JLabel scheduleLabel;

    AbstractTableModel tableModel;
    JScrollPane pane;

    public WeeklySchedule() {
        Loop.getInstance().killLoop();

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        LinkedList<Course> courses;

        courses = Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber());
        tableModel = TableModel.
                createTableModel(WeeklyScheduleInfo.class, WeeklyScheduleInfo.tableList(courses));

        //construct components
        scheduleTable = new JTable (tableModel);
        pane = new JScrollPane(scheduleTable);

        scheduleLabel = new JLabel ("Weekly Schedule:");

        //adjust size and set layout
        setPreferredSize (new Dimension (880, 430));
        setLayout (null);

        //add components
        add(pane);
        add (scheduleLabel);

        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (10, 30, 865, 335);
        scheduleLabel.setBounds (5, 0, 100, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        LinkedList<Course> courses;

        if(user instanceof Student) courses = Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber());
        else courses = Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber());
        tableModel = TableModel.
                createTableModel(WeeklyScheduleInfo.class, WeeklyScheduleInfo.tableList(courses));

        this.remove(pane);

        //construct components
        scheduleTable = new JTable (tableModel);
        pane = new JScrollPane(scheduleTable);

        add(pane);

        pane.setBounds (10, 30, 865, 335);

        revalidate();
        repaint();
    }

    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
       // frame.addComponent(new WeeklySchedule());
    }
}
