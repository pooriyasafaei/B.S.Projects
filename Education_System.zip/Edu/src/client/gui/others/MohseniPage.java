package client.gui.others;

import client.controller.Controller;
import client.controller.Loop;
import client.controller.support.Message;
import client.gui.MainPanel;
import client.gui.profile.StudentProfile;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.UserPublicInfo;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.AbstractTableModel;

public class MohseniPage extends JPanel implements ActionListener {
    private JTextField collegeIdField;
    private JLabel collegeIdLabel;
    private JTextField sectionField;
    private JLabel sectionLael;
    private JTextField entryYearField;
    private JLabel entryFieldLabel;
    private JTextField studentIdSearchField;
    private JTextArea messageArea;
    private JButton sendButton;
    private JTextField studentIdProfileField;
    private JButton openButton;
    private JTable studentsTable;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    public MohseniPage() {
        Loop.getInstance().killLoop();
        //construct components
        collegeIdField = new JTextField(5);
        collegeIdLabel = new JLabel("College ID:");
        sectionField = new JTextField(5);
        sectionLael = new JLabel("Section:");
        entryYearField = new JTextField(5);
        entryFieldLabel = new JLabel("Entry Year:");
        studentIdSearchField = new JTextField(5);
        messageArea = new JTextArea(5, 5);
        sendButton = new JButton("send");
        sendButton.addActionListener(this);
        sendButton.setActionCommand("send");

        studentIdProfileField = new JTextField(5);
        openButton = new JButton("open");
        openButton.addActionListener(this);
        openButton.setActionCommand("open");


        LinkedList<User> students = new LinkedList<>(Controller.getInstance().getOfflineData().
                getStudentsList(studentIdSearchField.getText(), "", "", ""));

        tableModel = TableModel.createTableModel(UserPublicInfo.class, UserPublicInfo.tableList(students));
        studentsTable = new JTable(tableModel);
        pane = new JScrollPane(studentsTable);

        //adjust size and set layout
        setPreferredSize(new Dimension(770, 524));
        setLayout(null);

        //add components
        add(collegeIdField);
        add(collegeIdLabel);
        add(sectionField);
        add(sectionLael);
        add(entryYearField);
        add(entryFieldLabel);
        add(studentIdSearchField);
        add(messageArea);
        add(sendButton);
        add(studentIdProfileField);
        add(openButton);
        add(pane);

        //set component bounds (only needed by Absolute Positioning)
        collegeIdField.setBounds(105, 55, 100, 25);
        collegeIdLabel.setBounds(30, 50, 85, 25);
        sectionField.setBounds(105, 85, 100, 25);
        sectionLael.setBounds(30, 80, 85, 25);
        entryYearField.setBounds(105, 115, 100, 25);
        entryFieldLabel.setBounds(30, 110, 70, 25);
        studentIdSearchField.setBounds(620, 120, 100, 25);
        messageArea.setBounds(225, 55, 190, 85);
        sendButton.setBounds(420, 115, 65, 25);
        studentIdProfileField.setBounds(620, 60, 100, 25);
        openButton.setBounds(510, 60, 100, 25);
        pane.setBounds(0, 155, 770, 310);

        Loop.getInstance().makePingLoop(this::reinitialize);

        revalidate();
        repaint();
    }

    public void reinitialize(){

        LinkedList<User> students = new LinkedList<>(Controller.getInstance().getOfflineData().
                getStudentsList(studentIdSearchField.getText(), "", "", ""));

        remove(pane);

        tableModel = TableModel.createTableModel(UserPublicInfo.class, UserPublicInfo.tableList(students));
        studentsTable = new JTable(tableModel);
        pane = new JScrollPane(studentsTable);

        add(pane);
        pane.setBounds(0, 155, 770, 310);

        revalidate();
        repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if (e.getActionCommand().equals("open")) {
            try {
                Student student = (Student) Controller.getInstance().getOfflineData().getUserById(
                        Long.parseLong(studentIdProfileField.getText()));

                frame.addComponent(new StudentProfile(student));
                return;
            } catch (Exception exception) {
                frame.setSysMessageText("invalid input");
                return;
            }
        }

        if (e.getActionCommand().equals("send")) {
            LinkedList<Student> students = Controller.getInstance().getOfflineData().getStudentsList("",
                    entryYearField.getText(), collegeIdField.getText(), sectionField.getText());

            for (Student student : students) {
                Controller.getInstance().getLibrary().sendMessageViaMessenger(new Message(12345678, student.getIdNumber(),
                        messageArea.getText()));
            }

            frame.setSysMessageText("message sent for filtered students");
        }
    }
}
