package client.gui.table.objects_table_module;


import server.logic.courses.Course;

import java.util.LinkedList;

public class ExamTimeInfo {
    private String a_Name;
    private String b_IDNumber;
    private String d_ExamTime;

    public ExamTimeInfo(Course course){
        this.a_Name = course.getName();
        this.b_IDNumber = String.valueOf(course.getId());
        this.d_ExamTime = String.valueOf(course.getExamTime());
    }

    public static LinkedList<ExamTimeInfo> tableList(LinkedList<Course> courses){
        LinkedList<ExamTimeInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new ExamTimeInfo(course));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_IDNumber() {
        return b_IDNumber;
    }

    public void setB_IDNumber(String b_IDNumber) {
        this.b_IDNumber = b_IDNumber;
    }

    public String getD_ExamTime() {
        return d_ExamTime;
    }

    public void setD_ExamTime(String d_ExamTime) {
        this.d_ExamTime = d_ExamTime;
    }
}