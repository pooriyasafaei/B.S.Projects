package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.courses.Course;

import java.util.LinkedList;

public class CoursePublicInfo {
    private String a_Name;
    private String b_CourseID;
    private String c_Units;
    private String d_Master;
    private String e_TimeInWeek;

    public CoursePublicInfo(Course course){
        this.a_Name = course.getName();
        this.b_CourseID = String.valueOf(course.getId());
        this.c_Units = String.valueOf(course.getUnits());
        this.d_Master = Controller.getInstance().getOfflineDataNoUpdate().getUserById(course.getMasterId()).getName();
        this.e_TimeInWeek = course.getTimeInWeek().toString();
    }

    public static LinkedList<CoursePublicInfo> tableList(LinkedList<Course> courses){
        LinkedList<CoursePublicInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new CoursePublicInfo(course));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_CourseID() {
        return b_CourseID;
    }

    public void setB_CourseID(String b_CourseID) {
        this.b_CourseID = b_CourseID;
    }

    public String getC_Units() {
        return c_Units;
    }

    public void setC_Units(String c_Units) {
        this.c_Units = c_Units;
    }

    public String getD_Master() {
        return d_Master;
    }

    public void setD_Master(String d_Master) {
        this.d_Master = d_Master;
    }

    public String getE_TimeInWeek() {
        return e_TimeInWeek;
    }

    public void setE_TimeInWeek(String e_TimeInWeek) {
        this.e_TimeInWeek = e_TimeInWeek;
    }
}
