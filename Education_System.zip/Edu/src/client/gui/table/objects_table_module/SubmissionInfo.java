package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.courses.cw.Submission;
import server.logic.users.Student;

import java.util.LinkedList;

public class SubmissionInfo {

    private String a_Number;
    private String b_StudentName;
    private String c_StudentId;
    private String d_Mark;
    private String e_Type;

    public SubmissionInfo(Submission submission){
        this.a_Number = String.valueOf(submission.getNumber());

        if(Controller.getInstance().getLoggedIn() instanceof Student){
            this. b_StudentName = "****";
            this. c_StudentId = "****";
        }
        else {
            this. b_StudentName = Controller.getInstance().getOfflineDataNoUpdate().getUserById(submission.getStudentId()).getName();
            this. c_StudentId = String.valueOf(submission.getStudentId());
        }

        this.d_Mark = submission.getMark() >= 0 ? String.valueOf(submission.getMark()) : "No mark";
        this.e_Type = submission.isText() ? "Text" : "File";
    }

    public static LinkedList<SubmissionInfo> tableList(LinkedList<Submission> submissions){
        LinkedList<SubmissionInfo> result = new LinkedList<>();
        for(Submission submission: submissions) result.add(new SubmissionInfo(submission));
        return result;
    }

    public String getA_Number() {
        return a_Number;
    }

    public void setA_Number(String a_Number) {
        this.a_Number = a_Number;
    }

    public String getB_StudentName() {
        return b_StudentName;
    }

    public void setB_StudentName(String b_StudentName) {
        this.b_StudentName = b_StudentName;
    }

    public String getC_StudentId() {
        return c_StudentId;
    }

    public void setC_StudentId(String c_StudentId) {
        this.c_StudentId = c_StudentId;
    }

    public String getD_Mark() {
        return d_Mark;
    }

    public void setD_Mark(String d_Mark) {
        this.d_Mark = d_Mark;
    }

    public String getE_Type() {
        return e_Type;
    }

    public void setE_Type(String e_Type) {
        this.e_Type = e_Type;
    }
}
