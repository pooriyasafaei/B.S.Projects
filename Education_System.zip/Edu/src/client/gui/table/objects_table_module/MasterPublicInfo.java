package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.users.Master;

import java.util.LinkedList;

public class MasterPublicInfo {
    private String a_Name;
    private String b_MasterID;
    private String c_College;
    private String d_MasterDegree;

    public MasterPublicInfo(Master master){
        if(master == null) return;
        this.a_Name = master.getName();
        this.b_MasterID = String.valueOf(master.getIdNumber());
        this.c_College = Controller.getInstance().getOfflineDataNoUpdate().getCollegeById(master.getCollegeId()).getName();
        this.d_MasterDegree = master.getMasterDegree();
    }

    public static LinkedList<MasterPublicInfo> tableList(LinkedList<Master> masters){
        LinkedList<MasterPublicInfo> result = new LinkedList<>();
        for(Master master: masters) result.add(new MasterPublicInfo(master));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_MasterID() {
        return b_MasterID;
    }

    public void setB_MasterID(String b_MasterID) {
        this.b_MasterID = b_MasterID;
    }

    public String getC_College() {
        return c_College;
    }

    public void setC_College(String c_College) {
        this.c_College = c_College;
    }

    public String getD_MasterDegree() {
        return d_MasterDegree;
    }

    public void setD_MasterDegree(String d_MasterDegree) {
        this.d_MasterDegree = d_MasterDegree;
    }
}
