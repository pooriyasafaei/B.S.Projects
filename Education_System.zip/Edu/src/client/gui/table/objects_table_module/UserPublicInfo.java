package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;

import java.util.LinkedList;

public class UserPublicInfo {

    private String a_Name;
    private String b_ID;
    private String c_College;
    private String d_Grade;

    public UserPublicInfo(User user){
        if(user == null) return;
        this.a_Name = user.getName();
        this.b_ID = String.valueOf(user.getIdNumber());
        this.c_College = Controller.getInstance().getOfflineData().getCollegeById(user.getCollegeId()).getName();
        this.d_Grade = user instanceof Master master ? master.getMasterDegree() : user instanceof Student student ?
                student.isMasters() ? "Masters" : student.isPhd() ? "PHD" : "Bachelor" : "-";
    }

    public static LinkedList<UserPublicInfo> tableList(LinkedList<User> users){
        LinkedList<UserPublicInfo> result = new LinkedList<>();
        for(User user: users) result.add(new UserPublicInfo(user));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_ID() {
        return b_ID;
    }

    public void setB_ID(String b_ID) {
        this.b_ID = b_ID;
    }

    public String getC_College() {
        return c_College;
    }

    public void setC_College(String c_College) {
        this.c_College = c_College;
    }

    public String getD_Grade() {
        return d_Grade;
    }

    public void setD_Grade(String d_Grade) {
        this.d_Grade = d_Grade;
    }
}
