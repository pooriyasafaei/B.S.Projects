package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.messenger.TextBox;
import server.time.DateTime;

import java.util.LinkedList;

public class ChatPublicInfo {

    private String ID;
    private String a_Name;
    private String b_LastMessage;
    private String c_Time;

    public ChatPublicInfo(TextBox textBox){
        if(textBox == null) return;
        this.ID = String.valueOf(textBox.getContactId());
        this.a_Name = Controller.getInstance().getOfflineDataNoUpdate().getUserById(textBox.getContactId()).getName();
        this.b_LastMessage = textBox.getLastMessage();
        this.c_Time = DateTime.getDateTimeNoSec(textBox.getLastMessageTime());
    }

    public static LinkedList<ChatPublicInfo> tableList(LinkedList<TextBox> textBoxes){
        LinkedList<ChatPublicInfo> result = new LinkedList<>();
        for(TextBox textBox: textBoxes) result.add(new ChatPublicInfo(textBox));
        return result;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_LastMessage() {
        return b_LastMessage;
    }

    public void setB_LastMessage(String b_LastMessage) {
        this.b_LastMessage = b_LastMessage;
    }

    public String getC_Time() {
        return c_Time;
    }

    public void setC_Time(String c_Time) {
        this.c_Time = c_Time;
    }
}
