package client.gui.table.objects_table_module;

import server.logic.courses.Course;
import server.logic.courses.cw.Homework;
import server.time.DateTime;

import java.util.LinkedList;

public class CalenderPublicInfo {

    private String a_Name;
    private String b_Type;
    private String c_Time;

    public CalenderPublicInfo(Object object){
        if(object instanceof Course course){
            this.a_Name = course.getName() + " exam";
            this.b_Type = "Exam";
            this.c_Time = DateTime.getDateTimeNoSec(course.getExamTime());
            return;
        }

        this.a_Name = ((Homework)object).getName();
        this.b_Type = "HomeWork";
        this.c_Time = DateTime.getDateTimeNoSec(((Homework)object).getDeadline());
    }

    public static LinkedList<CalenderPublicInfo> tableList(LinkedList<Object> objects){
        LinkedList<CalenderPublicInfo> result = new LinkedList<>();
        for(Object object: objects) result.add(new CalenderPublicInfo(object));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_Type() {
        return b_Type;
    }

    public void setB_Type(String b_Type) {
        this.b_Type = b_Type;
    }

    public String getC_Time() {
        return c_Time;
    }

    public void setC_Time(String c_Time) {
        this.c_Time = c_Time;
    }
}
