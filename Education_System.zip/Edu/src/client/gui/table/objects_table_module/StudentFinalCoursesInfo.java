package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.courses.Course;
import server.logic.users.Student;

import java.util.LinkedList;

public class StudentFinalCoursesInfo {
    private String a_Name;
    private String b_CourseID;
    private String c_MasterName;
    private String d_Units;
    private String e_Mark;
    private String f_IsPassed;

    public StudentFinalCoursesInfo(Course course, Student student){
        this.a_Name = course.getName();
        this.b_CourseID = String.valueOf(course.getId());
        this.c_MasterName = Controller.getInstance().getOfflineDataNoUpdate().getUserById(course.getMasterId()).getName();
        this.d_Units = String.valueOf(course.getUnits());
        this.e_Mark =course.getMark(student.getIdNumber()) > 0 ? String.valueOf(course.getMark(student.getIdNumber())) : "N/A";
        this.f_IsPassed = course.getMark(student.getIdNumber()) < 10 ? "failed" : "passed";
        if (course.getMark(student.getIdNumber()) < 0) this.f_IsPassed = "pending";
    }

    public static LinkedList<StudentFinalCoursesInfo> tableList(LinkedList<Course> courses, Student student){
        LinkedList<StudentFinalCoursesInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new StudentFinalCoursesInfo(course, student));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_CourseID() {
        return b_CourseID;
    }

    public void setB_CourseID(String b_CourseID) {
        this.b_CourseID = b_CourseID;
    }

    public String getC_MasterName() {
        return c_MasterName;
    }

    public void setC_MasterName(String c_MasterName) {
        this.c_MasterName = c_MasterName;
    }

    public String getD_Units() {
        return d_Units;
    }

    public void setD_Units(String d_Units) {
        this.d_Units = d_Units;
    }

    public String getE_Mark() {
        return e_Mark;
    }

    public void setE_Mark(String e_Mark) {
        this.e_Mark = e_Mark;
    }

    public String getF_IsPassed() {
        return f_IsPassed;
    }

    public void setF_IsPassed(String f_IsPassed) {
        this.f_IsPassed = f_IsPassed;
    }
}
