package client.gui.table.objects_table_module;

import server.logic.courses.cw.Content;
import server.logic.courses.cw.Homework;
import server.time.DateTime;

import java.util.LinkedList;

public class ContentInfo {
    private String a_Name;
    private String b_ReleaseTime;
    private String c_EndTime;
    private String d_Type;

    public ContentInfo(Content content){
        this.a_Name = content.getName();
        this.b_ReleaseTime = DateTime.getDateTimeNoSec(content.getTime());
        this.c_EndTime = content instanceof Homework homework ? DateTime.getDateTimeNoSec(homework.getDeadline()) : "***";
        this.d_Type = content.isText() ? "Text" : "File";

    }

    public static LinkedList<ContentInfo> tableList(LinkedList<Content> contents){
        LinkedList<ContentInfo> result = new LinkedList<>();
        for(Content content: contents) result.add(new ContentInfo(content));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_ReleaseTime() {
        return b_ReleaseTime;
    }

    public void setB_ReleaseTime(String b_ReleaseTime) {
        this.b_ReleaseTime = b_ReleaseTime;
    }

    public String getC_EndTime() {
        return c_EndTime;
    }

    public void setC_EndTime(String c_EndTime) {
        this.c_EndTime = c_EndTime;
    }

    public String getD_Type() {
        return d_Type;
    }

    public void setD_Type(String d_Type) {
        this.d_Type = d_Type;
    }
}
