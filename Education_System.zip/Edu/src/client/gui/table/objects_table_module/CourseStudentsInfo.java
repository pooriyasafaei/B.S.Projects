package client.gui.table.objects_table_module;

import server.logic.courses.Course;
import server.logic.users.Student;

import java.util.LinkedList;

public class CourseStudentsInfo {
    private String a_StudentName;
    private String b_StudentID;
    private String c_Mark;
    private String d_IsPassedYet;

    public CourseStudentsInfo(Student student, Course course){
        this.a_StudentName = student.getName();
        this.b_StudentID = String.valueOf(student.getIdNumber());
        this.c_Mark = String.valueOf(course.getMark(student.getIdNumber()));
        this.d_IsPassedYet = course.getMark(student.getIdNumber()) < 10 ? "not passed" : "passed";
    }

    public static LinkedList<CourseStudentsInfo> tableList(LinkedList<Student> students, Course course){
        LinkedList<CourseStudentsInfo> result = new LinkedList<>();
        for(Student student: students) result.add(new CourseStudentsInfo(student, course));
        return result;
    }

    public String getA_StudentName() {
        return a_StudentName;
    }

    public void setA_StudentName(String a_StudentName) {
        this.a_StudentName = a_StudentName;
    }

    public String getB_StudentID() {
        return b_StudentID;
    }

    public void setB_StudentID(String b_StudentID) {
        this.b_StudentID = b_StudentID;
    }

    public String getC_Mark() {
        return c_Mark;
    }

    public void setC_Mark(String c_Mark) {
        this.c_Mark = c_Mark;
    }

    public String getD_IsPassedYet() {
        return d_IsPassedYet;
    }

    public void setD_IsPassedYet(String d_IsPassedYet) {
        this.d_IsPassedYet = d_IsPassedYet;
    }
}
