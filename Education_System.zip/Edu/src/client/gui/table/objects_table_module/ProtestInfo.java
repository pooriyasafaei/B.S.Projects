package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.courses.Protest;

import java.util.LinkedList;

public class ProtestInfo {
    private String a_StudentID;
    private String b_ProtestText;
    private String c_Mark;
    private String d_Response;

    public  ProtestInfo(Protest protest){
        this.a_StudentID = String.valueOf(protest.getStudentId());
        this.b_ProtestText = protest.getRequestText();
        this.c_Mark = String.valueOf(Controller.getInstance().getOfflineDataNoUpdate().getCourseById
                (protest.getCourseId()).getMark(protest.getStudentId()));
        this.d_Response = protest.getResponseText();
    }

    public static LinkedList<ProtestInfo> tableList(LinkedList<Protest> protests){
        LinkedList<ProtestInfo> result = new LinkedList<>();
        for(Protest protest: protests) result.add(new ProtestInfo(protest));
        return result;
    }

    public String getA_StudentID() {
        return a_StudentID;
    }

    public void setA_StudentID(String a_StudentID) {
        this.a_StudentID = a_StudentID;
    }

    public String getB_ProtestText() {
        return b_ProtestText;
    }

    public void setB_ProtestText(String b_ProtestText) {
        this.b_ProtestText = b_ProtestText;
    }

    public String getC_Mark() {
        return c_Mark;
    }

    public void setC_Mark(String c_Mark) {
        this.c_Mark = c_Mark;
    }

    public String getD_Response() {
        return d_Response;
    }

    public void setD_Response(String d_Response) {
        this.d_Response = d_Response;
    }
}
