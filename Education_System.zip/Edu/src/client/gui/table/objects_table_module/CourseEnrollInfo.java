package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.courses.Course;

import java.util.LinkedList;

public class CourseEnrollInfo {
    private String a_Name;
    private String b_Master;
    private String c_TimeInWeek;
    private String d_ExamTime;
    private String e_Capacity;
    private String f_FullId;
    private String G_College;

    public CourseEnrollInfo(Course course){
        this.a_Name = course.getName();
        this.b_Master = Controller.getInstance().getOfflineDataNoUpdate().getUserById(course.getMasterId()).getName();
        this.c_TimeInWeek = course.getTimeInWeek().toString();
        this.d_ExamTime = course.getExamTime().toString();
        this.e_Capacity = String.valueOf(course.getCapacity());
        this.f_FullId = String.valueOf(course.getId());
        this.G_College = Controller.getInstance().getOfflineDataNoUpdate().getCollegeById(course.getCollegeId()).getName();
    }

    public static LinkedList<CourseEnrollInfo> tableList(LinkedList<Course> courses){
        LinkedList<CourseEnrollInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new CourseEnrollInfo(course));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_Master() {
        return b_Master;
    }

    public void setB_Master(String b_Master) {
        this.b_Master = b_Master;
    }

    public String getC_TimeInWeek() {
        return c_TimeInWeek;
    }

    public void setC_TimeInWeek(String c_TimeInWeek) {
        this.c_TimeInWeek = c_TimeInWeek;
    }

    public String getD_ExamTime() {
        return d_ExamTime;
    }

    public void setD_ExamTime(String d_ExamTime) {
        this.d_ExamTime = d_ExamTime;
    }

    public String getE_Capacity() {
        return e_Capacity;
    }

    public void setE_Capacity(String e_Capacity) {
        this.e_Capacity = e_Capacity;
    }

    public String getF_FullId() {
        return f_FullId;
    }

    public void setF_FullId(String f_FullId) {
        this.f_FullId = f_FullId;
    }

    public String getG_College() {
        return G_College;
    }

    public void setG_College(String g_College) {
        G_College = g_College;
    }
}
