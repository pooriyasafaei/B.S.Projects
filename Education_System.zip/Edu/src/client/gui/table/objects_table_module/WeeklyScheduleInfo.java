package client.gui.table.objects_table_module;

import server.logic.courses.Course;

import java.util.LinkedList;

public class WeeklyScheduleInfo {
    private String a_Name;
    private String b_IDNumber;
    private String c_TimeInWeek;
    private String d_ExamTime;

    public WeeklyScheduleInfo(Course course){
        this.a_Name = course.getName();
        this.b_IDNumber = String.valueOf(course.getId());
        this.c_TimeInWeek = course.getTimeInWeek().toString();
        this.d_ExamTime = course.getExamTime().toString();
    }

    public static LinkedList<WeeklyScheduleInfo> tableList(LinkedList<Course> courses){
        LinkedList<WeeklyScheduleInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new WeeklyScheduleInfo(course));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_IDNumber() {
        return b_IDNumber;
    }

    public void setB_IDNumber(String b_IDNumber) {
        this.b_IDNumber = b_IDNumber;
    }

    public String getC_TimeInWeek() {
        return c_TimeInWeek;
    }

    public void setC_TimeInWeek(String c_TimeInWeek) {
        this.c_TimeInWeek = c_TimeInWeek;
    }

    public String getD_ExamTime() {
        return d_ExamTime;
    }

    public void setD_ExamTime(String d_ExamTime) {
        this.d_ExamTime = d_ExamTime;
    }
}
