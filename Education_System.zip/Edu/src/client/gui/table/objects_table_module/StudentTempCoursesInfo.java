package client.gui.table.objects_table_module;

import server.logic.courses.Course;
import server.logic.users.Student;

import java.util.LinkedList;

public class StudentTempCoursesInfo {
    private String a_Name;
    private String b_CourseID;
    private String c_Units;
    private String d_Mark;
    private String e_IsPassed;

    public StudentTempCoursesInfo(Course course, Student student){
        this.a_Name = course.getName();
        this.b_CourseID = String.valueOf(course.getId());
        this.c_Units = String.valueOf(course.getUnits());
        this.d_Mark =course.getMark(student.getIdNumber()) > 0 ? String.valueOf(course.getMark(student.getIdNumber())) : "N/A";
        this.e_IsPassed = course.getMark(student.getIdNumber()) < 10 ? "failed" : "passed";
        if (course.getMark(student.getIdNumber()) < 0) this.e_IsPassed = "pending";
    }

    public static LinkedList<StudentTempCoursesInfo> tableList(LinkedList<Course> courses, Student student){
        LinkedList<StudentTempCoursesInfo> result = new LinkedList<>();
        for(Course course: courses) result.add(new StudentTempCoursesInfo(course, student));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_CourseID() {
        return b_CourseID;
    }

    public void setB_CourseID(String b_CourseID) {
        this.b_CourseID = b_CourseID;
    }

    public String getC_Units() {
        return c_Units;
    }

    public void setC_Units(String c_Units) {
        this.c_Units = c_Units;
    }

    public String getD_Mark() {
        return d_Mark;
    }

    public void setD_Mark(String d_Mark) {
        this.d_Mark = d_Mark;
    }

    public String getE_IsPassed() {
        return e_IsPassed;
    }

    public void setE_IsPassed(String e_IsPassed) {
        this.e_IsPassed = e_IsPassed;
    }
}
