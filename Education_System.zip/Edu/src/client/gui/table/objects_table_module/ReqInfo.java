package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.request.Request;

import java.util.LinkedList;

public class ReqInfo {
    private String a_RequestID;
    private String b_ApplicantName;
    private String c_RequestType;
    private String d_RequestResponse;
    private String e_FinalResult;

    public ReqInfo(Request request){
        this.a_RequestID = String.valueOf(request.getRequestId());
        this.b_ApplicantName = Controller.getInstance().getOfflineDataNoUpdate().getUserById(request.getApplicantId()).getName();
        this.c_RequestType = request.getType().name();
        this.d_RequestResponse = request.getResponseText();
        this.e_FinalResult = request.finalResult();
    }

    public static LinkedList<ReqInfo> tableList(LinkedList<Request> requests){
        LinkedList<ReqInfo> result = new LinkedList<>();
        for(Request request: requests) result.add(new ReqInfo(request));
        return result;
    }

    public String getA_RequestID() {
        return a_RequestID;
    }

    public void setA_RequestID(String a_RequestID) {
        this.a_RequestID = a_RequestID;
    }

    public String getB_ApplicantName() {
        return b_ApplicantName;
    }

    public void setB_ApplicantName(String b_ApplicantName) {
        this.b_ApplicantName = b_ApplicantName;
    }

    public String getC_RequestType() {
        return c_RequestType;
    }

    public void setC_RequestType(String c_RequestType) {
        this.c_RequestType = c_RequestType;
    }

    public String getD_RequestResponse() {
        return d_RequestResponse;
    }

    public void setD_RequestResponse(String d_RequestResponse) {
        this.d_RequestResponse = d_RequestResponse;
    }

    public String getE_FinalResult() {
        return e_FinalResult;
    }

    public void setE_FinalResult(String e_FinalResult) {
        this.e_FinalResult = e_FinalResult;
    }
}
