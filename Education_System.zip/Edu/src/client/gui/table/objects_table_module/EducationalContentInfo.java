package client.gui.table.objects_table_module;

import server.logic.courses.cw.EducationalContent;
import server.time.DateTime;

import java.util.LinkedList;

public class EducationalContentInfo {

    private String a_Name;
    private String b_Date;
    private String c_NumberOfContents;

    public EducationalContentInfo(EducationalContent content){
        this.a_Name = content.getName();
        this.b_Date = DateTime.getDateTimeNoSec(content.getLastChange());
        this.c_NumberOfContents = String.valueOf(content.getContents().size());
    }

    public static LinkedList<EducationalContentInfo> tableList(LinkedList<EducationalContent> contents){
        LinkedList<EducationalContentInfo> result = new LinkedList<>();
        for(EducationalContent content: contents) result.add(new EducationalContentInfo(content));
        return result;
    }

    public String getA_Name() {
        return a_Name;
    }

    public void setA_Name(String a_Name) {
        this.a_Name = a_Name;
    }

    public String getB_Date() {
        return b_Date;
    }

    public void setB_Date(String b_Date) {
        this.b_Date = b_Date;
    }

    public String getC_NumberOfContents() {
        return c_NumberOfContents;
    }

    public void setC_NumberOfContents(String c_NumberOfContents) {
        this.c_NumberOfContents = c_NumberOfContents;
    }
}
