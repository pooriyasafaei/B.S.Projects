package client.gui.table.objects_table_module;

import client.controller.Controller;
import server.logic.request.Request;
import server.logic.request.RequestTypes;
import server.time.DateTime;

import java.util.LinkedList;

public class NotifInfo {
    private String a_Number;
    private String b_SenderName;
    private String c_MessageType;
    private String d_Time;

    public NotifInfo(Request request){
        this.a_Number = String.valueOf(request.getRequestId());
        this.b_SenderName =request.getType().equals(RequestTypes.SystemMessage) ? "System":
                Controller.getInstance().getOfflineDataNoUpdate().getUserById(request.getApplicantId()).getName();
        this.c_MessageType = request.getType().name();
        this.d_Time = DateTime.getDateTimeNoSec(request.getRegisteredTime());
    }

    public static LinkedList<NotifInfo> tableList(LinkedList<Request> requests){
        LinkedList<NotifInfo> result = new LinkedList<>();
        for(Request request: requests) result.add(new NotifInfo(request));
        return result;
    }

    public String getA_Number() {
        return a_Number;
    }

    public void setA_Number(String a_Number) {
        this.a_Number = a_Number;
    }

    public String getB_SenderName() {
        return b_SenderName;
    }

    public void setB_SenderName(String b_SenderName) {
        this.b_SenderName = b_SenderName;
    }

    public String getC_MessageType() {
        return c_MessageType;
    }

    public void setC_MessageType(String c_MessageType) {
        this.c_MessageType = c_MessageType;
    }

    public String getD_Time() {
        return d_Time;
    }

    public void setD_Time(String d_Time) {
        this.d_Time = d_Time;
    }
}
