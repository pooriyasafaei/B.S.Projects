package client.gui.reportcard_affairs;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import server.logger.Logger;
import server.logic.users.Student;
import server.logic.users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class C_ReportCard extends ReportCard implements ActionListener {

    private JLabel studentIdLabel;
    private JTextField studentIdTextField;
    private JButton searchButton;

    public C_ReportCard(Student student) {
        super(student);

        studentIdLabel = new JLabel("StudentID:");
        studentIdTextField = new JTextField(5);
        searchButton = new JButton("Search");
        searchButton.addActionListener(this);
        searchButton.setActionCommand("search");

        studentIdTextField.setToolTipText("Enter student id to show report card");

        add(studentIdLabel);
        add(studentIdTextField);
        add(searchButton);

        studentIdLabel.setBounds (280, 380, 100, 25);
        studentIdTextField.setBounds (350, 380, 100, 25);
        searchButton.setBounds (480, 380, 80, 25);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        String command = e.getActionCommand();
//        Edu edu = Edu.getInstance();

        if(command.equals("search")) {
            try {

                User student = Controller.getInstance().getOfflineData()
                        .getUserById(Long.parseLong(studentIdTextField.getText()));
                if(!(student instanceof Student)){

                    frame.setSysMessageText("Student with this studentID doesn't exist");
                    return;
                }

                frame.addComponent(new C_ReportCard((Student) student));

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
            }
        }
    }
}
