package client.gui.reportcard_affairs;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.StudentFinalCoursesInfo;
import server.logic.users.Student;

import java.awt.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class ReportCard extends JPanel {
    private JTable reportCardTable;
    private JLabel reportCardLabel;
    private JLabel passedLabel;
    private JLabel gradingLabel;
    private AbstractTableModel tableModel;

    protected Student student;
    private JScrollPane pane;

    public ReportCard(Student student) {
        Loop.getInstance().killLoop();

        this.student = student;

        if (student == null){

            tableModel= TableModel.createTableModel(StudentFinalCoursesInfo.class, new LinkedList<>());

            //construct components
            passedLabel = new JLabel ("Number of units passed: ");
            gradingLabel = new JLabel ("Grading Average:");
        } else {
            tableModel= TableModel.createTableModel(StudentFinalCoursesInfo.class,
                    StudentFinalCoursesInfo.tableList(student.getAllCoursesList(false), student));
            passedLabel = new JLabel ("Number of units passed: " + student.getUnitsPassed(false));
            gradingLabel = new JLabel ("Grading Average: " + student.getAverageGrade(false));
        }

        reportCardLabel = new JLabel ("Courses:");
        reportCardTable = new JTable (tableModel);

        pane = new JScrollPane(reportCardTable);

        //adjust size and set layout
        setPreferredSize (new Dimension (880, 490));
        setLayout (null);

        //add components
        add(pane);
        add (reportCardLabel);
        add (passedLabel);
        add (gradingLabel);

        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (10, 30, 865, 335);
        reportCardLabel.setBounds (5, 0, 100, 25);
        passedLabel.setBounds (15, 380, 215, 25);
        gradingLabel.setBounds (15, 410, 215, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        this.student = (Student) Controller.getInstance().getOfflineData().getUserById(this.student.getIdNumber());

        remove(pane);

        if (student == null){

            tableModel= TableModel.createTableModel(StudentFinalCoursesInfo.class, new LinkedList<>());

            //construct components
            passedLabel = new JLabel ("Number of units passed: ");
            gradingLabel = new JLabel ("Grading Average:");
        } else {
            tableModel= TableModel.createTableModel(StudentFinalCoursesInfo.class,
                    StudentFinalCoursesInfo.tableList(student.getAllCoursesList(false), student));
            passedLabel = new JLabel ("Number of units passed: " + student.getUnitsPassed(false));
            gradingLabel = new JLabel ("Grading Average: " + student.getAverageGrade(false));
        }

        reportCardTable = new JTable (tableModel);
        pane = new JScrollPane(reportCardTable);

        add(pane);
        pane.setBounds (10, 30, 865, 335);

        revalidate();
        repaint();
    }
}
