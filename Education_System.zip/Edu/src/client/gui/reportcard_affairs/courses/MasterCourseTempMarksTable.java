package client.gui.reportcard_affairs.courses;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CourseStudentsInfo;
import client.gui.table.objects_table_module.ProtestInfo;
import communication.server.ServerResponse;
import server.logic.courses.Course;
import server.logic.main_data.Edu;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class MasterCourseTempMarksTable extends JPanel implements ActionListener {
    private JTable tempMarksTable;
    private JLabel tempMarksLabel;
    private JLabel protestsLabel;
    private JTable protestsTable;
    private JButton addAnswerButton;
    private JTextArea answerText;
    private JTextField studentIdField;
    private JLabel studentIdLabel;
    private JLabel answerTextLabel;
    private JLabel newMarkLabel;
    private JTextField newMarkField;

    private JLabel gradingLabel;
    private JLabel passedLabel;
    private JLabel failedLabel;


    private Course course;

    private AbstractTableModel tableModel1;
    private JScrollPane pane1;
    private AbstractTableModel tableModel2;
    private JScrollPane pane2;

    public MasterCourseTempMarksTable(Course course) {
        Loop.getInstance().killLoop();

        this.course = course;
        //construct components
        tableModel1 =
                TableModel.createTableModel(CourseStudentsInfo.class,
                        CourseStudentsInfo.tableList(course.getStudentsList(false), course));
        tempMarksTable = new JTable (tableModel1);
         pane1 = new JScrollPane(tempMarksTable);

        tableModel2 =
                TableModel.createTableModel(ProtestInfo.class, ProtestInfo.tableList(course.getProtests()));
        protestsTable = new JTable(tableModel2);
        pane2 = new JScrollPane(protestsTable);

        tempMarksLabel = new JLabel ("Course temp marks:");
        protestsLabel = new JLabel ("Protests:");
        addAnswerButton = new JButton ("Answer");
        addAnswerButton.addActionListener(this);
        addAnswerButton.setActionCommand("answer");

        answerText = new JTextArea (5, 5);
        studentIdField = new JTextField (5);
        studentIdLabel = new JLabel ("StudentID:");
        answerTextLabel = new JLabel ("Answer text:");
        newMarkLabel = new JLabel("New mark:");
        newMarkField = new JTextField(5);

        gradingLabel = new JLabel ("Course grading: " + course.getGradingAverage());
        passedLabel = new JLabel ("Passed number: " + course.getPassedFailed()[0]);
        failedLabel = new JLabel ("Failed number: " + course.getPassedFailed()[1]);

        //set components properties
        answerText.setToolTipText ("Enter answer of student protest selected");
        studentIdField.setToolTipText ("Enter student Id");
        newMarkField.setToolTipText("Enter student new mark(between 0 and 20)");

        //adjust size and set layout
        setPreferredSize (new Dimension (867, 430));
        setLayout (null);

        //add components
        add (pane1);
        add (tempMarksLabel);
        add (protestsLabel);
        add (pane2);
        if(Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber() == course.getMasterId()
                && Controller.getInstance().isOnline()){
            add(addAnswerButton);
            add(answerText);
            add(studentIdField);
            add(studentIdLabel);
            add(answerTextLabel);
            add(newMarkLabel);
            add(newMarkField);
        }

        add (gradingLabel);
        add (passedLabel);
        add (failedLabel);

        //set component bounds (only needed by Absolute Positioning)
        pane1.setBounds (15, 30, 850, 105);
        tempMarksLabel.setBounds (0, 0, 125, 25);
        protestsLabel.setBounds (0, 135, 100, 25);
        pane2.setBounds (15, 160, 850, 105);
        addAnswerButton.setBounds (215, 380, 100, 25);
        answerText.setBounds (295, 275, 220, 75);
        studentIdField.setBounds (90, 275, 100, 25);
        studentIdLabel.setBounds (25, 275, 100, 25);
        newMarkField.setBounds (90, 300, 100, 25);
        newMarkLabel.setBounds (25, 300, 100, 25);
        answerTextLabel.setBounds (220, 275, 75, 25);

        gradingLabel.setBounds (565, 275, 200, 25);
        passedLabel.setBounds (565, 300, 200, 25);
        failedLabel.setBounds (565, 325, 200, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        Controller.getInstance().getLibrary().refreshPublicInfo();

        this.course = Controller.getInstance().getOfflineData().getCourseById(course.getId());
        this.remove(pane1);
        this.remove(pane2);

        //construct components
        tableModel1 =
                TableModel.createTableModel(CourseStudentsInfo.class,
                        CourseStudentsInfo.tableList(course.getStudentsList(false), course));
        tempMarksTable = new JTable (tableModel1);
        pane1 = new JScrollPane(tempMarksTable);

        tableModel2 =
                TableModel.createTableModel(ProtestInfo.class, ProtestInfo.tableList(course.getProtests()));
        protestsTable = new JTable(tableModel2);
        pane2 = new JScrollPane(protestsTable);

        this.add(pane1);
        this.add(pane2);

        pane1.setBounds (15, 30, 850, 105);
        pane2.setBounds (15, 160, 850, 105);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
    //   MainPanel.getInstance().addComponent(new CourseTempMarksTable());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
     //   Edu edu = Edu.getInstance();
       // User user = edu.getUserLoggedIn();
        String command = e.getActionCommand();

        if(command.equals("answer")){
           ServerResponse response =  Controller.getInstance().getLibrary().responseProtest(course.getId(),
                    studentIdField.getText(), newMarkField.getText(), answerText.getText());

            frame.addComponent(new MasterCourseTempMarksTable(course));

            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
