package client.gui.reportcard_affairs.courses;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CourseStudentsInfo;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.courses.Course;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CourseNotRegisteredTable extends JPanel implements ActionListener {
    private JTable studentsTable;
    private JLabel studentsLabel;
    private JLabel studentIdLabel;
    private JTextField studentIdField;
    private JButton registerButton;
    private JLabel markLabel;
    private JTextField markField;
    private JButton addButton;

    private Course course;
    private JScrollPane pane;
    private AbstractTableModel tableModel;

    public CourseNotRegisteredTable(Course course) {
        Loop.getInstance().killLoop();

        Controller.getInstance().getLibrary().refreshPublicInfo();

        this.course = course;

        tableModel =
                TableModel.createTableModel(CourseStudentsInfo.class,
                        CourseStudentsInfo.tableList(course.getStudentsList(false), course));
        studentsTable = new JTable (tableModel);
        pane = new JScrollPane(studentsTable);

        //construct components
        studentIdLabel = new JLabel ("Student ID:");
        studentIdField = new JTextField (5);
        registerButton = new JButton ("Register all marks");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("register");

        markLabel = new JLabel ("Mark:");
        markField = new JTextField (5);
        addButton = new JButton ("Add");
        addButton.addActionListener(this);
        addButton.setActionCommand("add");

        studentsLabel = new JLabel ("Students: (-1 means no mark registered for that student)");


        //set components properties
        studentIdField.setToolTipText ("Enter student ID to add or change mark");
        markField.setToolTipText ("Enter mark between 0 and 20");
        addButton.setToolTipText ("Press to add temporary mark for this student");

        //adjust size and set layout
        setPreferredSize (new Dimension(880, 490));
        setLayout (null);

        //add components
        add(pane);
        add (studentsLabel);
        if(Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber() == course.getMasterId() && Controller.getInstance().isOnline()){
            add(studentIdLabel);
            add(studentIdField);
            add(registerButton);
            add(markLabel);
            add(markField);
            add(addButton);
        }

        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (10, 30, 865, 335);
        studentsLabel.setBounds (5, 0, 320, 25);
        studentIdLabel.setBounds (15, 380, 215, 25);
        studentIdLabel.setBounds (30, 370, 80, 25);
        studentIdField.setBounds (105, 370, 100, 25);
        registerButton.setBounds (725, 365, 140, 30);
        markLabel.setBounds (30, 395, 60, 25);
        markField.setBounds (105, 395, 100, 25);
        addButton.setBounds (225, 395, 60, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        Controller.getInstance().getLibrary().refreshPublicInfo();
        course = Controller.getInstance().getOfflineData().getCourseById(course.getId());

        this.remove(pane);

        tableModel =
                TableModel.createTableModel(CourseStudentsInfo.class,
                        CourseStudentsInfo.tableList(course.getStudentsList(false), course));
        studentsTable = new JTable (tableModel);
        pane = new JScrollPane(studentsTable);

        add(pane);
        pane.setBounds (10, 30, 865, 335);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
       // frame.addComponent(new CourseNotRegisteredTable());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        //Edu edu = Edu.getInstance();
       // User user = edu.getUserLoggedIn();
        String command = e.getActionCommand();
        ServerResponse response = new ServerResponse();

        if(command.equals("add")){
            try {
                response = Controller.getInstance().getLibrary().editMark(course.getId(),
                        Long.parseLong(studentIdField.getText()), Double.parseDouble(markField.getText()));

                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                response.setServerMessage("invalid inputs");
            }
        }

        if(command.equals("register")){
            response = Controller.getInstance().getLibrary().registerCourse(course.getId());

            if(response.isFlag()){
                frame.addComponent(new MasterCourseTempMarksTable(course));
                frame.setSysMessageText(response.getServerMessage());
                return;
            }
            frame.setSysMessageText(response.getServerMessage());
        }

        frame.addComponent(new CourseNotRegisteredTable(course));
        frame.setSysMessageText(response.getServerMessage());

    }
}
