package client.gui.reportcard_affairs.courses;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ProtestInfo;
import client.gui.table.objects_table_module.StudentTempCoursesInfo;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.main_data.Edu;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class StudentCourseTempMarksTable extends JPanel implements ActionListener {
    private JTable tempMarksTable;
    private JLabel tempMarksLabel;
    private JLabel protestsLabel;
    private JTable protestsTable;
    private JButton addProtestButton;
    private JTextArea protestText;
    private JTextField courseIdField;
    private JLabel courseIdLabel;
    private JLabel protestTextLabel;

    private Student student;

    private AbstractTableModel tableModel1;
    private JScrollPane pane1;
    private AbstractTableModel tableModel2;
    private JScrollPane pane2;

    public StudentCourseTempMarksTable(Student student) {
        Loop.getInstance().killLoop();

        Controller.getInstance().getLibrary().refreshPublicInfo();

        this.student = student;
        //construct components
        tableModel1 = TableModel.createTableModel(StudentTempCoursesInfo.class,
                        StudentTempCoursesInfo.tableList(student.getTempCourses(false), student));

        tempMarksTable = new JTable (tableModel1);
        pane1 = new JScrollPane(tempMarksTable);

        tableModel2 = TableModel.createTableModel(ProtestInfo.class,
                ProtestInfo.tableList(student.getProtests(false)));

        protestsTable = new JTable(tableModel2);
        pane2 = new JScrollPane(protestsTable);

        tempMarksLabel = new JLabel ("Courses temp marks:");
        protestsLabel = new JLabel ("Protests:");

        addProtestButton = new JButton ("Add protest");
        addProtestButton.addActionListener(this);
        addProtestButton.setActionCommand("add protest");
        protestText = new JTextArea (5, 5);
        courseIdField = new JTextField (5);
        courseIdLabel = new JLabel ("CourseID:");
        protestTextLabel = new JLabel ("Protest text:");

        //set components properties
        protestText.setToolTipText ("Enter Text of your protest");
        courseIdField.setToolTipText ("Enter course you have protest to");

        //adjust size and set layout
        setPreferredSize (new Dimension (870, 430));
        setLayout (null);

        //add components
        add (pane1);
        add (tempMarksLabel);
        add (protestsLabel);
        add (pane2);
        if(Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber() == student.getIdNumber()
                && Controller.getInstance().isOnline()){
            add(addProtestButton);
            add(protestText);
            add(courseIdField);
            add(courseIdLabel);
            add(protestTextLabel);
        }

        //set component bounds (only needed by Absolute Positioning)
        pane1.setBounds (15, 30, 850, 105);
        tempMarksLabel.setBounds (0, 0, 125, 25);
        protestsLabel.setBounds (0, 135, 100, 25);
        pane2.setBounds (15, 160, 850, 105);
        addProtestButton.setBounds (90, 330, 100, 25);
        protestText.setBounds (295, 275, 220, 75);
        courseIdField.setBounds (90, 275, 100, 25);
        courseIdLabel.setBounds (35, 275, 100, 25);
        protestTextLabel.setBounds (220, 275, 75, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public  void reInitialize(){
        Controller.getInstance().getLibrary().refreshPublicInfo();
        student = (Student) Controller.getInstance().getOfflineData().getUserById(student.getIdNumber());

        this.remove(pane1);
        this.remove(pane2);

        tableModel1 = TableModel.createTableModel(StudentTempCoursesInfo.class,
                StudentTempCoursesInfo.tableList(student.getTempCourses(false), student));

        tempMarksTable = new JTable (tableModel1);
        pane1 = new JScrollPane(tempMarksTable);

        tableModel2 = TableModel.createTableModel(ProtestInfo.class,
                ProtestInfo.tableList(student.getProtests(false)));

        protestsTable = new JTable(tableModel2);
        pane2 = new JScrollPane(protestsTable);

        this.add (pane1);
        this.add (pane2);

        pane1.setBounds (15, 30, 850, 105);
        pane2.setBounds (15, 160, 850, 105);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
   //     frame.getContentPane().add (new StudentCourseTempMarksTable());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        String command = e.getActionCommand();

        if(command.equals("add protest")){
            try {
               ServerResponse response = Controller.getInstance().getLibrary().makeProtest
                       (student.getIdNumber(), Long.parseLong(courseIdField.getText()), protestText.getText());

                frame.addComponent(new StudentCourseTempMarksTable(student));
                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
            }
        }
    }
}