package client.gui.reportcard_affairs.courses;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.enrollment.CoursesTable;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.users.Master;
import server.logic.users.Student;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.LinkedList;

public class M_CoursesTable extends CoursesTable {
    private JLabel courseDetailLabel;
    private JTextField courseIdField;
    private JButton courseDetailButton;

    private JLabel studentDetailLabel;
    private JTextField studentIdField;
    private JButton studentDetailButton;

    private JLabel masterDetailLabel;
    private JTextField masterIdField;
    private JButton masterDetailButton;

    public M_CoursesTable(LinkedList<Course> courses) {
        super(courses);

        courseDetailLabel = new JLabel ("Course details:");
        courseIdField = new JTextField (5);
        courseDetailButton = new JButton ("Details");
        courseDetailButton.addActionListener(this);
        courseDetailButton.setActionCommand("course details");

        studentDetailLabel = new JLabel ("Student details:");
        studentIdField = new JTextField (5);
        studentDetailButton = new JButton ("Details");
        studentDetailButton.addActionListener(this);
        studentDetailButton.setActionCommand("student details");

        masterDetailLabel = new JLabel ("Master details:");
        masterIdField = new JTextField (5);
        masterDetailButton = new JButton ("Details");
        masterDetailButton.addActionListener(this);
        masterDetailButton.setActionCommand("master details");

        //tool tips
        courseIdField.setToolTipText ("Enter one of your coursesIDs to see details and marks");
        studentIdField.setToolTipText("Enter a studentID to see details and marks");
        courseDetailButton.setToolTipText ("Press to go to course details panel");

        //add components
        add (courseDetailLabel);
        add (courseIdField);
        add (courseDetailButton);

        if(((Master)Controller.getInstance().getLibrary().refreshPublicInfo()).isChancellor()){
            add (studentDetailLabel);
            add (studentIdField);
            add (studentDetailButton);

            add (masterDetailLabel);
            add (masterIdField);
            add (masterDetailButton);
        }
        //set bounds

        courseDetailLabel.setBounds (380, 285, 135, 25);
        courseIdField.setBounds (535, 285, 120, 25);
        courseDetailButton.setBounds (665, 285, 100, 25);

        studentDetailLabel.setBounds (380, 310, 135, 25);
        studentIdField.setBounds (535, 310, 120, 25);
        studentDetailButton.setBounds (665, 310, 100, 25);

        masterDetailLabel.setBounds (380, 335, 135, 25);
        masterIdField.setBounds (535, 335, 120, 25);
        masterDetailButton.setBounds (665, 335, 100, 25);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
       // Edu edu = Edu.getInstance();
        Master user = (Master) Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("course details")){
            try {
                long id = Long.parseLong(courseIdField.getText());
                if (!user.getCoursesId().contains(id) && !user.isChancellor()){
                    frame.setSysMessageText("you don't have course with that id");
                    return;
                }

                Course course = Controller.getInstance().getOfflineData().getCourseById(id);
                if (course == null){
                    frame.setSysMessageText("course with that id doesn't exist");
                    return;
                }

                if(!course.isMarkRegistered()){
                    frame.addComponent(new CourseNotRegisteredTable(course));
                    return;

                } else frame.addComponent(new MasterCourseTempMarksTable(course));

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
            }
        }

        if(command.equals("student details")){
            try {
                Controller.getInstance().getLibrary().refreshPublicInfo();
                long id = Long.parseLong(studentIdField.getText());
                Student student = (Student) Controller.getInstance().getOfflineData().getUserById(id);
                if(student == null){
                    frame.setSysMessageText("student with this id doesn't exist");
                    return;
                }

                frame.addComponent(new StudentCourseTempMarksTable(student));
                return;

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
            }
        }

        if(command.equals("master details")){
            try {
                long id = Long.parseLong(masterIdField.getText());
                Master master = (Master) Controller.getInstance().getOfflineData().getUserById(id);

                if(master == null){
                    frame.setSysMessageText("master with this id doesn't exist");
                    return;
                }

                frame.addComponent(new M_CoursesTable
                        (Controller.getInstance().getOfflineData().getOnGoingCoursesList(master.getIdNumber())));

            } catch (Exception ex){

                Logger.logException(this, "actionPerformed", "input Exception");
                frame.setSysMessageText("invalid inputs");
            }
        }
    }
}
