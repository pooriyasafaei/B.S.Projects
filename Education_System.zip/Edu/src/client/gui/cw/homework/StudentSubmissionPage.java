package client.gui.cw.homework;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.courses.cw.Cw;
import server.logic.courses.cw.Homework;
import server.logic.users.Student;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class StudentSubmissionPage extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel releaseTimeLabel;
    private JLabel deadlineLabel;
    private JLabel closeTimeLabel;
    private JLabel infoLabel;
    private JTextArea answerArea;
    private JLabel statusLabel;
    private JLabel gradeLabel;
    private JTextField pathField;
    private JLabel pathLabel;
    private JButton sendButton;
    private JButton downloadButton;

    private Cw cw;
    private Homework homework;
    public StudentSubmissionPage(Cw cw, Homework homework) {
        Loop.getInstance().killLoop();

        this.homework = homework;
        this.cw = cw;
        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        //construct components
        nameLabel = new JLabel ("Name: " + homework.getName());
        releaseTimeLabel = new JLabel ("Release time: " + DateTime.getDateTimeNoSec(homework.getTime()));
        deadlineLabel = new JLabel ("Deadline: " + DateTime.getDateTimeNoSec(homework.getDeadline()));
        closeTimeLabel = new JLabel ("Close time: " + DateTime.getDateTimeNoSec(homework.getCloseTime()));
        infoLabel = new JLabel ("Info: " + homework.getInfo());
        answerArea = new JTextArea (5, 5);

        int grade = homework.getGrade(student.getIdNumber());
        statusLabel = new JLabel ("Status: " + (grade < -99 ? "Not submit": grade == -1 ? "Not graded" : "Graded"));

        gradeLabel = new JLabel ("Grading: " + (grade >= 0 ? grade : "-"));
        pathField = new JTextField (5);
        pathLabel = new JLabel ("Path:");

        sendButton = new JButton ("send");
        sendButton.addActionListener(this);
        sendButton.setActionCommand("send");

        downloadButton = new JButton ("download");
        downloadButton.addActionListener(this);
        downloadButton.setActionCommand("download");
        //adjust size and set layout
        setPreferredSize (new Dimension (752, 425));
        setLayout (null);

        //add components
        add (nameLabel);
        add (releaseTimeLabel);
        add (deadlineLabel);
        add (closeTimeLabel);
        add (infoLabel);
        add (statusLabel);
        add (gradeLabel);
        add (sendButton);
        add (downloadButton);

        if(homework.isAnswerText()){
            add(answerArea);
            answerArea.setBounds(465, 30, 250, 160);

        } else {
            add(pathField);
            add(pathLabel);

            pathLabel.setBounds(410, 205, 55, 25);
            pathField.setBounds(465, 205, 250, 25);

        }

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (15, 30, 350, 25);
        releaseTimeLabel.setBounds (15, 60, 220, 25);
        deadlineLabel.setBounds (15, 90, 220, 25);
        closeTimeLabel.setBounds (15, 120, 220, 25);
        infoLabel.setBounds (15, 150, 415, 25);
        statusLabel.setBounds (15, 180, 170, 25);
        gradeLabel.setBounds (15, 210, 130, 25);
        sendButton.setBounds (635, 260, 70, 25);
        downloadButton.setBounds (500, 260, 100, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        cw = Controller.getInstance().getOfflineDataNoUpdate().getCourseById(cw.getCourseId()).getCourseware();
        homework = cw.getHomework(homework.getName());
        //construct components
        nameLabel.setText("Name: " + homework.getName());
        releaseTimeLabel.setText ("Release time: " + DateTime.getDateTimeNoSec(homework.getTime()));
        deadlineLabel.setText ("Deadline: " + DateTime.getDateTimeNoSec(homework.getDeadline()));
        closeTimeLabel.setText ("Close time: " + DateTime.getDateTimeNoSec(homework.getCloseTime()));
        infoLabel.setText ("Info: " + homework.getInfo());

        int grade = homework.getGrade(student.getIdNumber());
        statusLabel.setText ("Status: " + (grade < -99 ? "Not submit": grade == -1 ? "Not graded" : "Graded"));

        gradeLabel.setText ("Grading: " + (grade >= 0 ? grade : "-"));

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().add (new StudentSubmissionPage());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();

        if(e.getActionCommand().equals("send")){
            ServerResponse response = Controller.getInstance().getLibrary().addSubmission
                    (homework.isAnswerText(), cw.getCourseId(), student.getIdNumber(), homework.getName(),
                            homework.isAnswerText() ? answerArea.getText() : pathField.getText());
            frame.setSysMessageText(response.getServerMessage());

            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("download")){
            ServerResponse response = Controller.getInstance().getLibrary().downloadHomework(cw.getCourseId(), homework.getName());
            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
