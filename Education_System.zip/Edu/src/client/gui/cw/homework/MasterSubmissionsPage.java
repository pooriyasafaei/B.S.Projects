package client.gui.cw.homework;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.messanger.PopUpText;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.SubmissionInfo;
import communication.server.ServerResponse;
import server.controller.ServerRunner;
import server.logic.courses.cw.Cw;
import server.logic.courses.cw.Homework;
import server.logic.courses.cw.Submission;
import server.logic.users.Master;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.AbstractTableModel;

public class MasterSubmissionsPage extends JPanel implements ActionListener {
    private JLabel submissionsLabel;
    private JTable submissionsTable;
    private JTextField submissionIdField;
    private JLabel submissionIdLabel;
    private JLabel markLabel;
    private JTextField markField;
    private JButton markRegisterButton;
    private JButton downloadButton;

    private Homework homework;
    private Cw cw;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    public MasterSubmissionsPage(Cw cw, Homework homework) {
        Loop.getInstance().killLoop();

        this.homework = homework;
        this.cw = cw;

        //construct components
        submissionsLabel = new JLabel ("Submissions:");

        tableModel = TableModel.createTableModel(SubmissionInfo.class, SubmissionInfo.tableList(homework.getSubmissionsList()));
        submissionsTable = new JTable (tableModel);
        pane = new JScrollPane(submissionsTable);

        submissionIdField = new JTextField (5);
        submissionIdLabel = new JLabel ("Submission ID:");
        markLabel = new JLabel ("Mark:");
        markField = new JTextField (5);

        markRegisterButton = new JButton ("register");
        markRegisterButton.addActionListener(this);
        markRegisterButton.setActionCommand("register");

        downloadButton = new JButton ("download");
        downloadButton.addActionListener(this);
        downloadButton.setActionCommand("download");

        //adjust size and set layout
        setPreferredSize (new Dimension (805, 522));
        setLayout (null);

        //add components
        add (submissionsLabel);
        add (pane);
        add (submissionIdField);
        add (submissionIdLabel);
        add (markLabel);
        add (markField);
        add (markRegisterButton);
        add (downloadButton);

        //set component bounds (only needed by Absolute Positioning)
        submissionsLabel.setBounds (5, 0, 100, 25);
        pane.setBounds (0, 30, 805, 290);
        submissionIdField.setBounds (630, 330, 100, 25);
        submissionIdLabel.setBounds (525, 330, 100, 25);
        markLabel.setBounds (525, 365, 95, 25);
        markField.setBounds (630, 365, 100, 25);
        markRegisterButton.setBounds (680, 400, 80, 25);
        downloadButton.setBounds (680, 430, 90, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        this.cw = Controller.getInstance().getOfflineData().getCourseById(cw.getCourseId()).getCourseware();
        this.homework = cw.getHomework(homework.getName());

        remove (pane);

        tableModel = TableModel.createTableModel(SubmissionInfo.class, SubmissionInfo.tableList(homework.getSubmissionsList()));
        submissionsTable = new JTable (tableModel);
        pane = new JScrollPane(submissionsTable);

        add (pane);
        pane.setBounds (0, 30, 805, 290);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().add (new MasterSubmissionsPage());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        if(e.getActionCommand().equals("download")){
            try {
                int submissionNumber = Integer.parseInt(submissionIdField.getText());
                Submission submission = homework.getSubmission(submissionNumber);

                if(submission == null){
                    frame.setSysMessageText("submission doesnt exist");
                    return;
                }

                if (homework.isAnswerText()) {
                    PopUpText.popUp(user instanceof Master ? Controller.getInstance().getOfflineDataNoUpdate().
                            getUserById(submission.getStudentId()).getName(): "****" , submission.getText(), null);
                    return;
                }

                ServerResponse response = Controller.getInstance().getLibrary().getSubmissionFile(cw.getCourseId(),
                        submission.getNumber(), homework.getName());

                frame.setSysMessageText(response.getServerMessage());
                return;

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
                return;
            }
        }

        if(e.getActionCommand().equals("register")){
            try {
                int submissionNumber = Integer.parseInt(submissionIdField.getText());
                Submission submission = homework.getSubmission(submissionNumber);
                if(submission == null){
                    frame.setSysMessageText("submission doesnt exist");
                    return;
                }

                int mark = Integer.parseInt(markField.getText());
                if(mark < 0 || mark > 100){
                    frame.setSysMessageText("invalid grade range");
                    return;
                }
                ServerResponse response = Controller.getInstance().getLibrary().markSubmission(cw.getCourseId(),
                        homework.getName(), submission.getNumber(), mark);

                frame.setSysMessageText(response.getServerMessage());

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }
    }
}
