package client.gui.cw.homework;


import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import server.logic.courses.cw.Cw;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Collections;
import javax.swing.*;

public class AddHomework extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel releaseTimeLabel;
    private JTextField releaseTimeField;
    private JLabel deadlineLabel;
    private JTextField deadlineField;
    private JLabel closeTimeLabel;
    private JTextField closeTimeField;
    private JLabel infoLabel;
    private JTextField infoField;
    private JLabel filePathLabel;
    private JTextField filePathField;
    private JButton submitButton;
    private JRadioButton isAnswerText;

    private Cw cw;

    public AddHomework(Cw cw) {
        Loop.getInstance().killLoop();

        this.cw = cw;
        //construct components
        nameLabel = new JLabel ("Name:");
        nameField = new JTextField (5);
        releaseTimeLabel = new JLabel ("Release time:");
        releaseTimeField = new JTextField (5);
        deadlineLabel = new JLabel ("Deadline:");
        deadlineField = new JTextField (5);
        closeTimeLabel = new JLabel ("Close time:");
        closeTimeField = new JTextField (5);
        infoLabel = new JLabel ("Info:");
        infoField = new JTextField (5);
        filePathLabel = new JLabel ("File path:");
        filePathField = new JTextField (5);

        submitButton = new JButton ("submit");
        submitButton.addActionListener(this);
        submitButton.setActionCommand("submit");

        isAnswerText = new JRadioButton ("Answer must be text");

        //adjust size and set layout
        setPreferredSize (new Dimension (682, 420));
        setLayout (null);

        //add components
        add (nameLabel);
        add (nameField);
        add (releaseTimeLabel);
        add (releaseTimeField);
        add (deadlineLabel);
        add (deadlineField);
        add (closeTimeLabel);
        add (closeTimeField);
        add (infoLabel);
        add (infoField);
        add (filePathLabel);
        add (filePathField);
        add (submitButton);
        add (isAnswerText);

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (40, 30, 45, 25);
        nameField.setBounds (145, 30, 170, 25);
        releaseTimeLabel.setBounds (40, 70, 95, 25);
        releaseTimeField.setBounds (145, 70, 170, 25);
        deadlineLabel.setBounds (40, 110, 100, 25);
        deadlineField.setBounds (145, 110, 170, 25);
        closeTimeLabel.setBounds (40, 150, 100, 25);
        closeTimeField.setBounds (145, 150, 170, 25);
        infoLabel.setBounds (40, 190, 100, 25);
        infoField.setBounds (145, 190, 450, 25);
        filePathLabel.setBounds (40, 230, 100, 25);
        filePathField.setBounds (145, 230, 450, 25);
        submitButton.setBounds (550, 300, 75, 25);
        isAnswerText.setBounds (145, 295, 140, 25);

    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
    //    frame.getContentPane().add (new AddHomework());
        frame.pack();
        frame.setVisible (true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        String homeworkName = nameField.getText();
        cw = Controller.getInstance().getOfflineData().getCourseById(cw.getCourseId()).getCourseware();

        try {
            if (cw.getHomework(homeworkName) != null) {
                frame.setSysMessageText("Homework with this name already exist");
                return;
            }

            File file = new File(filePathField.getText());
            if (!file.isFile()){
                frame.setSysMessageText("file not found");
                return;
            }

            FileEncode fileEncode = new FileEncode(filePathField.getText());
            ServerResponse response = Controller.getInstance().getLibrary().addHomework(cw.getCourseId(), homeworkName,
                    false, DateTime.toDateTime(releaseTimeField.getText()), infoField.getText(),
                    DateTime.toDateTime(deadlineField.getText()), DateTime.toDateTime(closeTimeField.getText()),
                    isAnswerText.isSelected(), fileEncode);

            frame.setSysMessageText(response.getServerMessage());

        }catch (Exception exception){
            frame.setSysMessageText("invalid input");
        }
    }
}
