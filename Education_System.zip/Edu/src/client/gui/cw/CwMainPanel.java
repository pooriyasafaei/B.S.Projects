package client.gui.cw;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CalenderPublicInfo;
import client.gui.table.objects_table_module.CoursePublicInfo;
import server.logic.courses.Course;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;


public class CwMainPanel extends JPanel implements ActionListener {
    private JLabel coursesLabel;
    private JTable coursesTable;
    private JTextField courseIdField;
    private JLabel courseIdLabel;
    private JButton openCoursewareButton;
    private JLabel comprehensiveCalendarLabel;
    private JTable comprehensiveCalendarTable;

    private AbstractTableModel tableModel1;
    private AbstractTableModel tableModel2;
    private JScrollPane pane1;
    private JScrollPane pane2;

    public CwMainPanel() {
        Loop.getInstance().killLoop();

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        //construct components
        LinkedList<Course> courses = new LinkedList<>();
        if(user instanceof Master master) courses.addAll(Controller.getInstance().getOfflineDataNoUpdate()
                .convertToCourse(master.getCoursesId()));
        else{
            courses.addAll(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse(((Student) user).getCoursesId()));
            courses.addAll(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse
                    (new LinkedList<>(((Student) user).getAssistantCourses())));
        }
        coursesLabel = new JLabel ("Courses:");
        tableModel1 = TableModel.createTableModel(CoursePublicInfo.class, CoursePublicInfo.tableList(courses));
        coursesTable = new JTable (tableModel1);
        pane1 = new JScrollPane(coursesTable);

        courseIdField = new JTextField (5);
        courseIdLabel = new JLabel ("Course ID:");
        openCoursewareButton = new JButton ("Open Courseware");
        openCoursewareButton.addActionListener(this);
        openCoursewareButton.setActionCommand("open courseware");

        comprehensiveCalendarLabel = new JLabel ("Comprehensive calendar:");
        tableModel2 = TableModel.createTableModel(CalenderPublicInfo.class,
               CalenderPublicInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortExamAndDeadlines(user, null)));
        comprehensiveCalendarTable = new JTable (tableModel2);
        pane2 = new JScrollPane(comprehensiveCalendarTable);

        //adjust size and set layout
        setPreferredSize (new Dimension (725, 628));
        setLayout (null);

        //add components
        add (coursesLabel);
        add (pane1);
        add (courseIdField);
        add (courseIdLabel);
        add (openCoursewareButton);
        add (comprehensiveCalendarLabel);
        add (pane2);

        //set component bounds (only needed by Absolute Positioning)
        coursesLabel.setBounds (5, 0, 100, 25);
        pane1.setBounds (0, 30, 725, 185);
        courseIdField.setBounds (470, 220, 100, 25);
        courseIdLabel.setBounds (400, 220, 70, 25);
        openCoursewareButton.setBounds (580, 220, 130, 25);
        comprehensiveCalendarLabel.setBounds (5, 230, 150, 25);
        pane2.setBounds (0, 260, 725, 300);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        remove(pane1);
        remove(pane2);
        //construct components
        LinkedList<Course> courses = new LinkedList<>();
        if(user instanceof Master master) courses.addAll(Controller.getInstance().getOfflineDataNoUpdate()
                .convertToCourse(master.getCoursesId()));
        else{
            courses.addAll(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse(((Student) user).getCoursesId()));
            courses.addAll(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse
                    (new LinkedList<>(((Student) user).getAssistantCourses())));
        }
        coursesLabel = new JLabel ("Courses:");
        tableModel1 = TableModel.createTableModel(CoursePublicInfo.class, CoursePublicInfo.tableList(courses));
        coursesTable = new JTable (tableModel1);
        pane1 = new JScrollPane(coursesTable);

        tableModel2 = TableModel.createTableModel(CalenderPublicInfo.class,
                CalenderPublicInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortExamAndDeadlines(user, null)));
        comprehensiveCalendarTable = new JTable (tableModel2);
        pane2 = new JScrollPane(comprehensiveCalendarTable);

        add(pane1);
        add(pane2);

        pane1.setBounds (0, 30, 725, 185);
        pane2.setBounds (0, 260, 725, 300);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new CwMainPanel());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();

        if(e.getActionCommand().equals("open courseware")){
            try {
                long courseId = Long.parseLong(courseIdField.getText());
                Course course = Controller.getInstance().getOfflineData().getCourseById(courseId);
                if(course == null || (user instanceof Student student ? (!student.getCoursesId().contains(courseId) &&
                        !student.getAssistantCourses().contains(courseId)) :
                        !((Master)user).getCoursesId().contains(courseId))){
                    frame.setSysMessageText("you don't have this course");
                    return;
                }
                frame.addComponent(new CwCoursePanel(course));
            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }
    }
}
