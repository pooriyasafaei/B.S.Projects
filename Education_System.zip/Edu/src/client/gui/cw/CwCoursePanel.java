package client.gui.cw;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.cw.content.EducationalContentPage;
import client.gui.cw.homework.AddHomework;
import client.gui.cw.homework.MasterSubmissionsPage;
import client.gui.cw.homework.StudentSubmissionPage;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CalenderPublicInfo;
import client.gui.table.objects_table_module.ContentInfo;
import client.gui.table.objects_table_module.EducationalContentInfo;
import communication.server.ServerResponse;
import server.logic.courses.Course;
import server.logic.courses.cw.Content;
import server.logic.courses.cw.Cw;
import server.logic.courses.cw.EducationalContent;
import server.logic.courses.cw.Homework;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class CwCoursePanel extends JPanel implements ActionListener {
    private JLabel contentsLabel;
    private JTable contentsTable;
    private JTextField contentIdField;
    private JLabel contentIdLabel;
    private JButton openContentButton;
    private JLabel homeworksLabel;
    private JTable comprehensiveCalendarTable;
    private JLabel calenderLabel;
    private JLabel homeworkIdLabel;
    private JTextField homeworkIdField;
    private JButton openHomeworkButton;
    private JTable calenderTable;
    private JButton addContentButton;
    private JButton addHomeworkButton;

    private Course course;

    private AbstractTableModel tableModel1;
    private AbstractTableModel tableModel2;
    private AbstractTableModel tableModel3;
    private JScrollPane pane1;
    private JScrollPane pane2;
    private JScrollPane pane3;

    private JLabel studentIdLabel;
    private JTextField studentIdField;
    private JButton addAssistantButton;
    private JButton addStudentButton;


    public CwCoursePanel(Course course) {
        Loop.getInstance().killLoop();

        //construct components
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        this.course = course;
        Cw cw = course.getCourseware();

        contentsLabel = new JLabel ("Educational contents:");

        tableModel1 = TableModel.createTableModel(EducationalContentInfo.class,
                EducationalContentInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortByTime(cw.getContents())));
        contentsTable = new JTable (tableModel1);
        pane1 = new JScrollPane(contentsTable);

        contentIdField = new JTextField (5);
        contentIdLabel = new JLabel ("Content:");



        homeworksLabel = new JLabel ("Homeworks: ");
        tableModel2 = TableModel.createTableModel(ContentInfo.class, ContentInfo.tableList(new LinkedList<Content>(
                Controller.getInstance().getOfflineDataNoUpdate().sortByTime(cw.getHomeworks()))));
        comprehensiveCalendarTable = new JTable (tableModel2);
        pane2 = new JScrollPane(comprehensiveCalendarTable);

        calenderLabel = new JLabel ("Calender:");
        tableModel3 = TableModel.createTableModel(CalenderPublicInfo.class,
                CalenderPublicInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortExamAndDeadlines(user, course)));
        calenderTable = new JTable (tableModel3);
        pane3 = new JScrollPane(calenderTable);

        homeworkIdLabel = new JLabel ("Homework:");
        homeworkIdField = new JTextField (5);

        openContentButton = new JButton ("Open content");
        openContentButton.addActionListener(this);
        openContentButton.setActionCommand("open content");

        openHomeworkButton = new JButton ("Open homework");
        openHomeworkButton.addActionListener(this);
        openHomeworkButton.setActionCommand("open homework");

        addContentButton = new JButton ("add content");
        addContentButton.addActionListener(this);
        addContentButton.setActionCommand("add content");

        addHomeworkButton = new JButton ("add h-work");
        addHomeworkButton.addActionListener(this);
        addHomeworkButton.setActionCommand("add h-work");


        studentIdLabel = new JLabel ("Student ID:");
        studentIdField = new JTextField (5);

        addAssistantButton = new JButton ("Add as assistant");
        addAssistantButton.addActionListener(this);
        addAssistantButton.setActionCommand("add assistant");

        addStudentButton = new JButton ("Add as student");
        addStudentButton.addActionListener(this);
        addStudentButton.setActionCommand("add student");

        //adjust size and set layout
        setPreferredSize (new Dimension (726, 658));
        setLayout (null);

        //add components
        add (contentsLabel);
        add (pane1);
        add (contentIdField);
        add (contentIdLabel);
        add (openContentButton);
        add (homeworksLabel);
        add (pane2);
        add (calenderLabel);
        add (homeworkIdLabel);
        add (homeworkIdField);
        add (openHomeworkButton);
        add (pane3);



        if(user instanceof Master){
            add(addContentButton);
            add(addHomeworkButton);
            add (studentIdLabel);
            add (studentIdField);
            add (addAssistantButton);
            add (addStudentButton);

            addContentButton.setBounds (285, 190, 105, 25);
            addHomeworkButton.setBounds (285, 375, 105, 25);
            studentIdLabel.setBounds (165, 555, 90, 25);
            studentIdField.setBounds (260, 555, 100, 25);
            addAssistantButton.setBounds (435, 555, 125, 25);
            addStudentButton.setBounds (590, 555, 125, 25);
        }


        //set component bounds (only needed by Absolute Positioning)
        contentsLabel.setBounds (5, 0, 130, 25);
        pane1.setBounds (0, 30, 725, 155);
        contentIdField.setBounds (470, 190, 100, 25);
        contentIdLabel.setBounds (400, 190, 70, 25);
        openContentButton.setBounds (585, 190, 130, 25);
        homeworksLabel.setBounds (5, 200, 150, 25);
        pane2.setBounds (0, 230, 725, 135);
        calenderLabel.setBounds (5, 380, 100, 25);
        homeworkIdLabel.setBounds (400, 375, 70, 25);
        homeworkIdField.setBounds (470, 375, 100, 25);
        openHomeworkButton.setBounds (585, 375, 130, 25);
        pane3.setBounds (0, 410, 725, 145);


        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        this.course = Controller.getInstance().getOfflineDataNoUpdate().getCourseById(course.getId());
        Cw cw = course.getCourseware();


        remove(pane1);
        remove(pane2);
        remove(pane3);

        tableModel1 = TableModel.createTableModel(EducationalContentInfo.class,
                EducationalContentInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortByTime(cw.getContents())));
        contentsTable = new JTable (tableModel1);
        pane1 = new JScrollPane(contentsTable);


        tableModel2 = TableModel.createTableModel(ContentInfo.class, ContentInfo.tableList(new LinkedList<Content>(
                Controller.getInstance().getOfflineDataNoUpdate().sortByTime(cw.getHomeworks()))));
        comprehensiveCalendarTable = new JTable (tableModel2);
        pane2 = new JScrollPane(comprehensiveCalendarTable);

        tableModel3 = TableModel.createTableModel(CalenderPublicInfo.class,
                CalenderPublicInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().sortExamAndDeadlines(user, course)));
        calenderTable = new JTable (tableModel3);
        pane3 = new JScrollPane(calenderTable);

        add(pane1);
        add(pane2);
        add(pane3);

        pane1.setBounds (0, 30, 725, 155);
        pane2.setBounds (0, 230, 725, 135);
        pane3.setBounds (0, 410, 725, 145);

        repaint();
        revalidate();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().add (new CwCoursePanel());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        Cw cw = course.getCourseware();

        if(e.getActionCommand().equals("open content")){
            String contentName = contentIdField.getText();
            EducationalContent content = cw.getContent(contentName);
            if (content == null){
                frame.setSysMessageText("content doesn't exist");
                return;
            }

            frame.addComponent(new EducationalContentPage(cw, content));
            return;
        }

        if(e.getActionCommand().equals("open homework")){
            String homeworkName = homeworkIdField.getText();
            Homework homework = cw.getHomework(homeworkName);
            if (homework == null){
                frame.setSysMessageText("homework doesn't exist");
                return;
            }

            if(user instanceof Master) {
                frame.addComponent(new MasterSubmissionsPage(cw,homework));
                return;
            }

            if(course.getAssistants().contains(user.getIdNumber())){
                frame.addComponent(new MasterSubmissionsPage(cw, homework));
                return;
            }

            frame.addComponent(new StudentSubmissionPage(cw, homework));
            return;
        }

        if(e.getActionCommand().equals("add content")){
            String name = contentIdField.getText();

            if(cw.getContent(name) != null){
                frame.setSysMessageText("content with this name already exist");
                return;
            }

            ServerResponse response = Controller.getInstance().getLibrary().newContent(course.getId(), name);
            if(!response.isFlag()){
                frame.setSysMessageText(response.getServerMessage());
                return;
            }
            cw = Controller.getInstance().getOfflineData().getCourseById(course.getId()).getCourseware();
            frame.addComponent(new EducationalContentPage(cw, cw.getContent(name)));
            return;
        }

        if(e.getActionCommand().equals("add h-work")){
            frame.addComponent(new AddHomework(cw));
            return;
        }

        if(e.getActionCommand().equals("add assistant")){
            try {
                long studentId = Long.parseLong(studentIdField.getText());
                if(course.getAssistants().contains(studentId)){
                    frame.setSysMessageText("student is already assistant");
                    return;
                }

                if(!(Controller.getInstance().getOfflineDataNoUpdate().getUserById(studentId) instanceof Student)){
                    frame.setSysMessageText("student doesnt exist");
                    return;
                }

                ServerResponse response = Controller.getInstance().getLibrary().addStudentToCourseware(course.getId(),
                        studentId, true);

                frame.setSysMessageText(response.getServerMessage());

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }

        if(e.getActionCommand().equals("add student")){
            try {
                long studentId = Long.parseLong(studentIdField.getText());
                if(course.getStudentsMark().containsKey(studentId)){
                    frame.setSysMessageText("student has the course");
                    return;
                }

                if(!(Controller.getInstance().getOfflineDataNoUpdate().getUserById(studentId) instanceof Student)){
                    frame.setSysMessageText("student doesnt exist");
                    return;
                }

                ServerResponse response = Controller.getInstance().getLibrary().addStudentToCourseware(course.getId(),
                        studentId, false);

                frame.setSysMessageText(response.getServerMessage());

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }


    }
}
