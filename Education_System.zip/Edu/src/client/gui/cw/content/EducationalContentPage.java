package client.gui.cw.content;


import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.cw.CwCoursePanel;
import client.gui.cw.homework.StudentSubmissionPage;
import client.gui.messanger.PopUpText;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.ContentInfo;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import server.logic.courses.Course;
import server.logic.courses.cw.Content;
import server.logic.courses.cw.Cw;
import server.logic.courses.cw.EducationalContent;
import server.logic.users.Master;
import server.logic.users.User;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class EducationalContentPage extends JPanel implements ActionListener {
    private JLabel contentsLabel;
    private JTable contentsTable;
    private JLabel contentIdLabel;
    private JTextField contentIdField;
    private JTextArea textContentArea;
    private JTextField pathField;
    private JButton addTextButton;
    private JButton editTextButton;
    private JButton addFileButton;
    private JButton editFileButton;
    private JLabel pathLabel;
    private JButton downloadButton;
    private JButton removeButton;
    private JButton deleteAll;

    private Cw cw;
    private EducationalContent content;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    public EducationalContentPage(Cw cw, EducationalContent content) {

        Loop.getInstance().killLoop();

        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        Course course = Controller.getInstance().getOfflineDataNoUpdate().getCourseById(cw.getCourseId());

        this.cw = cw;
        this.content = content;

        //construct components
        contentsLabel = new JLabel ("Contents:");

        tableModel = TableModel.createTableModel(ContentInfo.class, ContentInfo.tableList(content.getContents()));
        contentsTable = new JTable(tableModel);
        pane = new JScrollPane(contentsTable);

        contentIdLabel = new JLabel ("Item name:");
        contentIdField = new JTextField (5);
        textContentArea = new JTextArea (5, 5);
        pathLabel = new JLabel ("Path:");
        pathField = new JTextField (5);

        addTextButton = new JButton ("add text");
        addTextButton.addActionListener(this);
        addTextButton.setActionCommand("add text");

        editTextButton = new JButton ("edit text");
        editTextButton.addActionListener(this);
        editTextButton.setActionCommand("edit text");

        addFileButton = new JButton ("add file");
        addFileButton.addActionListener(this);
        addFileButton.setActionCommand("add file");

        editFileButton = new JButton ("edit file");
        editFileButton.addActionListener(this);
        editFileButton.setActionCommand("edit file");

        downloadButton = new JButton ("Download");
        downloadButton.addActionListener(this);
        downloadButton.setActionCommand("download");

        removeButton = new JButton ("Remove");
        removeButton.addActionListener(this);
        removeButton.setActionCommand("remove");

        deleteAll = new JButton ("Delete all content");
        deleteAll.addActionListener(this);
        deleteAll.setActionCommand("delete all");

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 437));
        setLayout (null);

        //add components
        if(user instanceof Master){
            add (addTextButton);
            add (addFileButton);
            add (removeButton);
            add (deleteAll);
            add (textContentArea);
            add (pathLabel);
            add (pathField);
            add (editTextButton);
            add (editFileButton);
        }else {
            if(course.getAssistants().contains(user.getIdNumber())){
                add (textContentArea);
                add (pathLabel);
                add (pathField);
                add (editTextButton);
                add (editFileButton);
            }
        }
        add (contentsLabel);
        add (pane);
        add (contentIdLabel);
        add (contentIdField);
        add (downloadButton);

        //set component bounds (only needed by Absolute Positioning)
        contentsLabel.setBounds (5, 0, 100, 25);
        pane.setBounds (0, 30, 750, 130);
        contentIdLabel.setBounds (10, 165, 70, 25);
        contentIdField.setBounds (80, 165, 100, 25);
        textContentArea.setBounds (555, 170, 170, 125);
        pathField.setBounds (440, 305, 285, 25);
        addTextButton.setBounds (440, 170, 100, 25);
        editTextButton.setBounds (440, 200, 100, 25);
        addFileButton.setBounds (285, 305, 100, 25);
        editFileButton.setBounds (285, 335, 100, 25);
        pathLabel.setBounds (405, 305, 35, 20);
        downloadButton.setBounds (100, 200, 100, 25);
        removeButton.setBounds (100, 230, 100, 25);
        deleteAll.setBounds (40, 340, 140, 30);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();

    }

    public void reInitialize(){
        this.cw = Controller.getInstance().getOfflineData().getCourseById(cw.getCourseId()).getCourseware();
        this.content = cw.getContent(content.getName());

        remove(pane);

        tableModel = TableModel.createTableModel(ContentInfo.class, ContentInfo.tableList(content.getContents()));
        contentsTable = new JTable(tableModel);
        pane = new JScrollPane(contentsTable);

        add(pane);
        pane.setBounds (0, 30, 750, 130);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
//        frame.getContentPane().add (new StudentSubmissionPage());
        frame.pack();
        frame.setVisible (true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Course course = Controller.getInstance().getOfflineData().getCourseById(cw.getCourseId());
        cw = course.getCourseware();
        content = cw.getContent(content.getName());
        ServerResponse response;

        if(e.getActionCommand().equals("add text")){
            if(content.getContents().size() > 4){
                frame.setSysMessageText("only 5 items can be added");
                return;
            }

            if(content.getItem(contentIdField.getText()) != null){
                frame.setSysMessageText("item with that name already exists");
                return;
            }

            response = Controller.getInstance().getLibrary().addItem(course.getId(), content.getName(), contentIdField.getText(),
                    true, new DateTime(), textContentArea.getText(), null);
            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("edit text")){
            Content item = content.getItem(contentIdField.getText());
            if(item == null || !item.isText()){
                frame.setSysMessageText("item doesn't exist");
                return;
            }

            response = Controller.getInstance().getLibrary().editItem(course.getId(), content.getName(), item.getName(),
                    true, new DateTime(), textContentArea.getText(), null, 0);

            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("add file")){
            if(content.getContents().size() > 4){
                frame.setSysMessageText("only 5 items can be added");
                return;
            }

            if(content.getItem(contentIdField.getText()) != null){
                frame.setSysMessageText("item with that name already exists");
                return;
            }

            File file = new File(pathField.getText());
            if(!file.isFile()){
                frame.setSysMessageText("file doesnt exist");
                return;
            }

            FileEncode fileEncode = new FileEncode(pathField.getText());
            response = Controller.getInstance().getLibrary().addItem(course.getId(), content.getName(), contentIdField.getText(),
                    false, new DateTime(), fileEncode.getFileName(), fileEncode);
            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("edit file")){
            Content item = content.getItem(contentIdField.getText());
            if(item == null || item.isText()){
                frame.setSysMessageText("item doesn't exist");
                return;
            }

            File file = new File(pathField.getText());
            if(!file.isFile()){
                frame.setSysMessageText("file doesnt exist");
                return;
            }

            FileEncode fileEncode = new FileEncode(pathField.getText());
            response = Controller.getInstance().getLibrary().editItem(course.getId(), content.getName(), item.getName(),
                    false, new DateTime(), fileEncode.getFileName(), fileEncode, 0);

            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("download")){
            Content item = content.getItem(contentIdField.getText());
            if(item == null){
                frame.setSysMessageText("item doesn't exist");
                return;
            }

            if(item.isText()){
                PopUpText.popUp(course.getName(), item.getText(), null);
                return;
            }

            response = Controller.getInstance().getLibrary().downloadItem(course.getId(), content.getName(), item.getName());
            frame.setSysMessageText(response.getServerMessage());
        }

        if(e.getActionCommand().equals("remove")){
            Content item = content.getItem(contentIdField.getText());
            if(item == null){
                frame.setSysMessageText("item doesn't exist");
                return;
            }

            response = Controller.getInstance().getLibrary().editItem(course.getId(), content.getName(), item.getName(),
                    true, new DateTime(), "", null, 1);

            frame.setSysMessageText(response.getServerMessage());
            return;
        }

        if(e.getActionCommand().equals("delete all")){
            response = Controller.getInstance().getLibrary().editItem(course.getId(), content.getName(), "",
                    true, new DateTime(), "", null, -1);

            frame.addComponent(new CwCoursePanel(course));
            frame.setSysMessageText(response.getServerMessage());

        }
    }
}
