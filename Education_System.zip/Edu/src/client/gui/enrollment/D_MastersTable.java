package client.gui.enrollment;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.editing.adding.AddMaster;
import client.gui.editing.edit.EditMaster;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.users.Master;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class D_MastersTable extends MastersTable implements ActionListener {
    private JLabel editLabel;
    private JTextField editField;
    private JButton editButton;
    private JLabel deleteLabel;
    private JTextField deleteField;
    private JButton deleteButton;
    private JButton addButton;

    public D_MastersTable(LinkedList<Master> masters){
        super(masters);

        editLabel = new JLabel ("Enter master ID to edit:");
        editField = new JTextField (5);
        editButton = new JButton ("Edit panel");
        editButton.addActionListener(this);
        editButton.setActionCommand("edit");

        deleteLabel = new JLabel ("Enter master ID to delete:");
        deleteField = new JTextField (5);
        deleteButton = new JButton ("Delete");
        deleteButton.addActionListener(this);
        deleteButton.setActionCommand("delete");

        addButton = new JButton ("Add Master");
        addButton.addActionListener(this);
        addButton.setActionCommand("add");

        editField.setToolTipText ("Enter one of your college master ID to edit it");
        editButton.setToolTipText ("Press to go to edit panel");
        deleteField.setToolTipText ("Enter master ID to delete it ");
        addButton.setToolTipText ("Click to go to adding a master panel");

        if(Controller.getInstance().isOnline()){
            add(editLabel);
            add(editField);
            add(editButton);
            add(deleteLabel);
            add(deleteField);
            add(deleteButton);
            add(addButton);
        }

        editLabel.setBounds (280, 285, 135, 25);
        editField.setBounds (435, 285, 120, 25);
        editButton.setBounds (565, 285, 100, 25);
        deleteLabel.setBounds (280, 310, 150, 25);
        deleteField.setBounds (435, 310, 120, 25);
        deleteButton.setBounds (565, 310, 100, 25);
        addButton.setBounds (770, 270, 100, 25);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        super.actionPerformed(e);
        MainPanel frame = MainPanel.getInstance();
       // Edu edu = Edu.getInstance();
        String command = e.getActionCommand();

        if(command.equals("add")){
            frame.addComponent(new AddMaster());
        }

        if(command.equals("delete")){
            try {
                long id = Long.parseLong(deleteField.getText());
                ServerResponse response = Controller.getInstance().getLibrary().deleteMaster(id);
                frame.addComponent(new D_MastersTable(Controller.getInstance().getOfflineData().getMastersList
                        (collegeField.getText(),masterNameField.getText(),degreeField.getText())));
                frame.setSysMessageText(response.getServerMessage());

            }catch (Exception ex){

                Logger.logException(this, "actionPerformed", "input Exception");
                frame.setSysMessageText("invalid inputs");
            }
        }

        if (command.equals("edit")){
            try {
                long id = Long.parseLong(editField.getText());
                Controller.getInstance().getLibrary().refreshPublicInfo();

                Master master = (Master) Controller.getInstance().getOfflineData().getUserById(id);

                if(master == null){
                    frame.setSysMessageText("master doesn't exist");
                    return;
                }
                if (Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId() != master.getCollegeId()) {
                    frame.setSysMessageText("You can't change this master info");
                    return;
                }

                frame.addComponent(new EditMaster(master));

            }catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");

                frame.setSysMessageText("invalid inputs");
            }
        }

    }
}
