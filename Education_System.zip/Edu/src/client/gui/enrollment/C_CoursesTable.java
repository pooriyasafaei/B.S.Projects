package client.gui.enrollment;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.editing.adding.AddCourse;
import client.gui.editing.edit.EditCourse;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.LinkedList;

public class C_CoursesTable extends CoursesTable {

    private JLabel editLabel;
    private JTextField editField;
    private JButton editButton;
    private JLabel deleteLabel;
    private JTextField deleteField;
    private JButton deleteButton;
    private JButton addButton;

    public C_CoursesTable(LinkedList<Course> courses){
        super(courses);

        editLabel = new JLabel ("Enter CourseID to edit:");
        editField = new JTextField (5);
        editButton = new JButton ("Edit panel");
        editButton.addActionListener(this);
        editButton.setActionCommand("edit");

        deleteLabel = new JLabel ("Enter CourseID to delete:");
        deleteField = new JTextField (5);
        deleteButton = new JButton ("Delete");
        deleteButton.addActionListener(this);
        deleteButton.setActionCommand("delete");

        addButton = new JButton ("Add Course");
        addButton.addActionListener(this);
        addButton.setActionCommand("add");

        editField.setToolTipText ("Enter one of your college coursesID to edit it");
        editButton.setToolTipText ("Press to go to edit panel");
        deleteField.setToolTipText ("Enter course ide to delete it ");
        addButton.setToolTipText ("Click to go to adding a course panel");

        if(Controller.getInstance().isOnline()){
            add(editLabel);
            add(editField);
            add(editButton);
            add(deleteLabel);
            add(deleteField);
            add(deleteButton);
            add(addButton);
        }

        editLabel.setBounds (280, 285, 135, 25);
        editField.setBounds (435, 285, 120, 25);
        editButton.setBounds (565, 285, 100, 25);
        deleteLabel.setBounds (280, 310, 150, 25);
        deleteField.setBounds (435, 310, 120, 25);
        deleteButton.setBounds (565, 310, 100, 25);
        addButton.setBounds (770, 270, 100, 25);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        super.actionPerformed(e);
        MainPanel frame = MainPanel.getInstance();
    //    Edu edu = Edu.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("edit")){
            try {
                user = Controller.getInstance().getLibrary().refreshPublicInfo();
                Course course = Controller.getInstance().getOfflineData().getCourseById(Long.parseLong(editField.getText()));
                if(course == null || course.getCollegeId() != user.getCollegeId()){
                    frame.setSysMessageText("can't edit course with this id");
                    return;
                }

                frame.addComponent(new EditCourse(course));
                return;
            }
            catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");
                frame.setSysMessageText("invalid input");

            }
        }

        if(command.equals("add")){
            frame.addComponent(new AddCourse());
            return;
        }

        if(command.equals("delete")){
            try {
                Controller.getInstance().getLibrary().refreshPublicInfo();
                Course course = Controller.getInstance().getOfflineData().getCourseById(Long.parseLong(deleteField.getText()));
                if(course == null || course.getCollegeId() != user.getCollegeId()){

                    Logger.logException(this, "actionPerformed", "exist Exception");
                    frame.setSysMessageText("can't delete course with this id");
                    return;
                }
                ServerResponse response = Controller.getInstance().getLibrary().deleteCourse(course.getId());

                frame.addComponent(new C_CoursesTable(Controller.getInstance().getOfflineData()
                        .getCoursesList(collegeField.getText(), courseIdField.getText(), unitsField.getText())));
                frame.setSysMessageText(response.getServerMessage());
            }
            catch (Exception ex){
                Logger.logException(this, "actionPerformed", "input Exception");
                frame.setSysMessageText("invalid input");
            }
        }
    }
}
