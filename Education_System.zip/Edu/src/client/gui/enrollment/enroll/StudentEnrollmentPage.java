package client.gui.enrollment.enroll;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CourseEnrollInfo;
import server.logic.courses.Course;
import server.logic.users.Student;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class StudentEnrollmentPage extends JPanel implements ActionListener {

    private JLabel collegeCoursesLabel;
    private JTable collegeCoursesTable;
    private JComboBox filtersBox;
    private JLabel collegeLabel;
    private JTextField collegeField;
    private JLabel recommendedCoursesLabel;
    private JTable recommendedTable;
    private JLabel markedCoursesLabel;
    private JTable markedCoursesTable;
    private JLabel courseIdLabel;
    private JTextField courseIdField;
    private JButton courseItemsButton;
    private JButton filterButton;

    private AbstractTableModel tableModel1;
    private AbstractTableModel tableModel2;
    private AbstractTableModel tableModel3;

    private JScrollPane pane1;
    private JScrollPane pane2;
    private JScrollPane pane3;


    public StudentEnrollmentPage() {
        Loop.getInstance().killLoop();

        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        //construct preComponents
        String[] filtersBoxItems = {"Filters", "Name", "Section", "Exam time"};

        //construct components
        collegeCoursesLabel = new JLabel ("College courses:");

        tableModel1 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(Controller.getInstance().getOfflineData().getCourses()));
        collegeCoursesTable = new JTable (tableModel1);
        pane1 = new JScrollPane(collegeCoursesTable);

        collegeLabel = new JLabel ("College:");
        collegeField = new JTextField (5);
        recommendedCoursesLabel = new JLabel ("Recommended:");

        tableModel2 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(Controller.getInstance().
                        getOfflineData().getRecommendedCourses(student.getIdNumber())));
        recommendedTable = new JTable (tableModel2);
        pane2 = new JScrollPane(recommendedTable);

        markedCoursesLabel = new JLabel ("Marked:");

        tableModel3 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse(
                        new LinkedList<>(student.getMarkedCourses()))));
        markedCoursesTable = new JTable (tableModel3);
        pane3 = new JScrollPane(markedCoursesTable);

        courseIdLabel = new JLabel ("CourseID:");
        courseIdField = new JTextField (5);

        courseItemsButton = new JButton ("Course items");
        courseItemsButton.addActionListener(this);
        courseItemsButton.setActionCommand("course items");

        filterButton = new JButton ("filter");
        filterButton.addActionListener(this);
        filterButton.setActionCommand("filter");
        filtersBox = new JComboBox (filtersBoxItems);

        //adjust size and set layout
        setPreferredSize (new Dimension (901, 664));
        setLayout (null);

        //add components
        add (collegeCoursesLabel);
        add (pane1);
        add (filtersBox);
        add (collegeLabel);
        add (collegeField);
        add (recommendedCoursesLabel);
        add (pane2);
        add (markedCoursesLabel);
        add (pane3);
        add (courseIdLabel);
        add (courseIdField);
        add (courseItemsButton);
        add (filterButton);

        //set component bounds (only needed by Absolute Positioning)
        collegeCoursesLabel.setBounds (5, 5, 100, 20);
        pane1.setBounds (0, 30, 900, 200);
        filtersBox.setBounds (135, 5, 100, 20);
        collegeLabel.setBounds (245, 5, 100, 20);
        collegeField.setBounds (300, 5, 105, 20);
        recommendedCoursesLabel.setBounds (5, 230, 100, 25);
        pane2.setBounds (0, 255, 900, 135);
        markedCoursesLabel.setBounds (5, 395, 100, 25);
        pane3.setBounds (0, 420, 900, 135);
        courseIdLabel.setBounds (600, 560, 75, 25);
        courseIdField.setBounds (670, 560, 115, 25);
        courseItemsButton.setBounds (790, 560, 110, 25);
        filterButton.setBounds (420, 5, 60, 20);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    public void reInitialize(){

        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        LinkedList<Course> courses = Controller.getInstance().getOfflineData().getCoursesList(collegeField.getText(),
                "","");

        System.out.println(courses);
        if(String.valueOf(filtersBox.getSelectedItem()).equals("Name")) {
            courses = Controller.getInstance().
                    getOfflineDataNoUpdate().sortByName(courses);
            System.out.println("we are in name");
        }

        if(String.valueOf(filtersBox.getSelectedItem()).equals("Section")) {
            courses = Controller.getInstance().
                    getOfflineDataNoUpdate().sortBySection(courses);
            System.out.println("we are in section");
        }

        if(String.valueOf(filtersBox.getSelectedItem()).equals("Exam time")) {
            courses = DateTime.sortCoursesByExamTime(courses);
            System.out.println("we are in exam time");
        }

        System.out.println(String.valueOf(filtersBox.getSelectedItem()));

        remove(pane1);
        remove(pane2);
        remove(pane3);

        System.out.println(courses);

        tableModel1 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(courses));
        collegeCoursesTable = new JTable (tableModel1);
        pane1 = new JScrollPane(collegeCoursesTable);

        tableModel2 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(Controller.getInstance().
                        getOfflineData().getRecommendedCourses(student.getIdNumber())));
        recommendedTable = new JTable (tableModel2);
        pane2 = new JScrollPane(recommendedTable);

        tableModel3 = TableModel.createTableModel(CourseEnrollInfo.class,
                CourseEnrollInfo.tableList(Controller.getInstance().getOfflineDataNoUpdate().convertToCourse(
                        new LinkedList<>(student.getMarkedCourses()))));
        markedCoursesTable = new JTable (tableModel3);
        pane3 = new JScrollPane(markedCoursesTable);

        add(pane1);
        add(pane2);
        add(pane3);

        pane1.setBounds (0, 30, 900, 200);
        pane2.setBounds (0, 255, 900, 135);
        pane3.setBounds (0, 420, 900, 135);

        revalidate();
        repaint();
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new StudentEnrollmentPage());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("filter")) reInitialize();

        if(e.getActionCommand().equals("course items")){
            try {
                Course course = Controller.getInstance().getOfflineData().getCourseById(Long.parseLong(courseIdField.getText()));
                if(course == null){
                    frame.setSysMessageText("course doesn't exist");
                    return;
                }

                CourseEnrollmentPage.popUp(course.getId());

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }


    }
}
