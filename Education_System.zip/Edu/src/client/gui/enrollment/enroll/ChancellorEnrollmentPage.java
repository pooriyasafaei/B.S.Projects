package client.gui.enrollment.enroll;

import client.controller.Controller;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.*;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Objects;
import javax.swing.*;

public class ChancellorEnrollmentPage extends JPanel implements ActionListener {
    private JLabel entryYearLabel;
    private JTextField entryYearField;
    private JLabel sectionLabel;
    private JTextField sectionField;
    private JLabel enrollTimeLabel;
    private JButton setButton;
    private JTextField enrollTimeField;
    private JLabel particularIds;
    private JTextField studentIdsField;
    private JButton purgeButton;

    public ChancellorEnrollmentPage() {
        //construct components
        entryYearLabel = new JLabel ("Entry year:");
        entryYearField = new JTextField (5);
        sectionLabel = new JLabel ("Section:");
        sectionField = new JTextField (5);
        enrollTimeLabel = new JLabel ("Enroll time:");

        setButton = new JButton ("set");
        setButton.addActionListener(this);
        setButton.setActionCommand("set");

        enrollTimeField = new JTextField (5);
        particularIds = new JLabel ("Particular IDs:");
        studentIdsField = new JTextField (5);

        purgeButton = new JButton ("purge all!");
        purgeButton.addActionListener(this);
        purgeButton.setActionCommand("purge");

        //adjust size and set layout
        setPreferredSize (new Dimension (521, 333));
        setLayout (null);

        //add components
        add (entryYearLabel);
        add (entryYearField);
        add (sectionLabel);
        add (sectionField);
        add (enrollTimeLabel);
        add (setButton);
        add (enrollTimeField);
        add (particularIds);
        add (studentIdsField);
        add (purgeButton);

        //set component bounds (only needed by Absolute Positioning)
        entryYearLabel.setBounds (125, 70, 100, 25);
        entryYearField.setBounds (225, 70, 100, 25);
        sectionLabel.setBounds (125, 110, 100, 25);
        sectionField.setBounds (225, 110, 100, 25);
        enrollTimeLabel.setBounds (125, 220, 100, 25);
        setButton.setBounds (390, 245, 55, 25);
        enrollTimeField.setBounds (225, 220, 100, 25);
        particularIds.setBounds (125, 150, 100, 25);
        studentIdsField.setBounds (225, 150, 240, 25);
        purgeButton.setBounds (230, 275, 90, 30);

    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new ChancellorEnrollmentPage());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("set")){
            try {
                Controller.getInstance().getLibrary().refreshPublicInfo();
                LinkedList<Long> particulars = new LinkedList<>();

                if (!Objects.equals(studentIdsField.getText(), ""))
                    for (String assistantId : studentIdsField.getText().split(",")) {
                        User student = Controller.getInstance().getOfflineDataNoUpdate().
                                getUserById(Long.parseLong(assistantId));

                        if (!(student instanceof Student)) {
                            frame.setSysMessageText("invalid students id");
                            return;
                        }
                        particulars.add(student.getIdNumber());
                    }

                int entryYear = 0;
                if (!entryYearField.getText().equals("")) entryYear = Integer.parseInt(entryYearField.getText());

                particulars.addAll(Controller.getInstance().getOfflineData().getStudentForEnrollTime(entryYear,
                        sectionField.getText()));

                HashSet<Long> studentsId = new HashSet<>(particulars);

                ServerResponse response = Controller.getInstance().getLibrary().changeEnrollTime
                        (studentsId, DateTime.toDateTime(enrollTimeField.getText()));

                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex) {
                Logger.logException(this, "actionPerformed", "inputException");
                frame.setSysMessageText("invalid input");
            }
        }

        if(e.getActionCommand().equals("purge")){
            ServerResponse response = Controller.getInstance().getLibrary().purge();
            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
