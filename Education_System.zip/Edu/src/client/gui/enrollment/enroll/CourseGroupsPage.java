package client.gui.enrollment.enroll;

import client.controller.Controller;
import client.gui.MainPanel;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CourseEnrollInfo;
import communication.server.ServerResponse;
import server.logic.courses.Course;
import server.logic.users.Student;

import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class CourseGroupsPage extends JPanel implements ActionListener {

    private JLabel allGroupsLabel;
    private JTable allGroupsTable;
    private JTextField idField;
    private JLabel idLabel;
    private JButton changeButton;

    private static JFrame frame;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    private Long studentId;
    private Long courseId;

    public CourseGroupsPage(Long studentId, Long courseId, LinkedList<Course> groups) {
         this.studentId = studentId;
         this.courseId = courseId;

        //construct components

        allGroupsLabel = new JLabel ("All groups:");

        tableModel = TableModel.createTableModel(CourseEnrollInfo.class, CourseEnrollInfo.tableList(groups));
        allGroupsTable = new JTable (tableModel);
        pane = new JScrollPane(allGroupsTable);

        idField = new JTextField (5);
        idLabel = new JLabel ("ID:");

        changeButton = new JButton ("change");
        changeButton.addActionListener(this);
        changeButton.setActionCommand("change");

        //adjust size and set layout
        setPreferredSize (new Dimension (596, 206));
        setLayout (null);

        //add components
        add (allGroupsLabel);
        add (pane);
        add (idField);
        add (idLabel);
        add (changeButton);

        //set component bounds (only needed by Absolute Positioning)
        allGroupsLabel.setBounds (5, 0, 100, 25);
        pane.setBounds (0, 25, 595, 145);
        idField.setBounds (425, 175, 90, 25);
        idLabel.setBounds (380, 175, 45, 25);
        changeButton.setBounds (515, 175, 80, 25);
    }

    public static void popUp(Long studentId, Long courseId,LinkedList<Course> groups){
        frame = new JFrame ("CourseGroupsPage");
        frame.setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add (new CourseGroupsPage(studentId, courseId,groups));
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Course currentCourse = Controller.getInstance().getOfflineData().getCourseById(courseId);
        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();

        if(currentCourse == null) {
            frame.dispose();
            return;
        }

        if(e.getActionCommand().equals("change")){
            try {
                long id = Long.parseLong(idField.getText());
                Course course = Controller.getInstance().getOfflineData().getCourseById(id);

                if(course == null){
                    frame.setSysMessageText("course doesn't exist");
                    return;
                }

                if(course.getId() == Controller.getInstance().getOfflineDataNoUpdate().studentHasCourse
                        (student.getIdNumber(), course.getAbsoluteId()).getId()){
                    frame.setSysMessageText("you already have this group");
                    return;
                }

                if(course.getAbsoluteId() != currentCourse.getAbsoluteId()){
                    frame.setSysMessageText("not same courses");
                    return;
                }

                if(!course.hasCapacity()){
                    frame.setSysMessageText("no capacity in this group");
                    return;
                }

                ServerResponse response = Controller.getInstance().getLibrary().courseChangeGroup(studentId,
                        Controller.getInstance().getOfflineDataNoUpdate().studentHasCourse
                        (student.getIdNumber(), course.getAbsoluteId()).getId(), id);
                frame.setSysMessageText(response.getServerMessage());

                CourseGroupsPage.frame.dispose();

            }catch (Exception exception){
                frame.setSysMessageText("invalid input");
            }
        }
    }
}
