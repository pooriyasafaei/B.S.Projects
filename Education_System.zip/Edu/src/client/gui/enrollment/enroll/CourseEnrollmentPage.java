package client.gui.enrollment.enroll;

import client.controller.Controller;
import client.gui.MainPanel;
import client.gui.edu_services.request.RequestType;
import communication.client.ClientRequest;
import communication.client.ClientRequestType;
import communication.server.ServerResponse;
import server.logic.courses.Course;
import server.logic.users.Student;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;

public class CourseEnrollmentPage extends JPanel implements ActionListener {
    private static JFrame frame;

    private JLabel courseNameLabel;
    private JLabel masterLabel;
    private JLabel unitsLabel;
    private JLabel groupLabel;
    private JLabel idLabel;
    private JButton addOrRemoveButton;
    private JButton changeGroupButton;
    private JButton requestForAddButton;
    private JButton markOrUnmarkLabel;
    private Course course;

    public CourseEnrollmentPage(long courseId) {
      //  Loop.getInstance().killLoop();

        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        course = Controller.getInstance().getOfflineDataNoUpdate().getCourseById(courseId);

        //construct components
        courseNameLabel = new JLabel ("Course: " + course.getName());
        masterLabel = new JLabel ("Master: " + Controller.getInstance().getOfflineDataNoUpdate().getUserById(
                course.getMasterId()).getName());

        unitsLabel = new JLabel ("Units: " + course.getUnits());
        groupLabel = new JLabel ("Group: " + course.getGroup());
        idLabel = new JLabel ("ID: " + course.getAbsoluteId());

        addOrRemoveButton = new JButton ();
        changeGroupButton = new JButton ("change group");
        changeGroupButton.addActionListener(this);
        changeGroupButton.setActionCommand("change group");

        requestForAddButton = new JButton ("request for add");
        requestForAddButton.addActionListener(this);
        requestForAddButton.setActionCommand("request for add");

        markOrUnmarkLabel = new JButton ();
        markOrUnmarkLabel.addActionListener(this);

        if (student.getMarkedCourses().contains(courseId)){
            markOrUnmarkLabel.setText("unmark");
            markOrUnmarkLabel.setActionCommand("unmark");
        } else{
            markOrUnmarkLabel.setText("mark");
            markOrUnmarkLabel.setActionCommand("mark");
        }

        //adjust size and set layout
        setPreferredSize (new Dimension (501, 327));
        setLayout (null);

        //add components
        if (Controller.getInstance().getOfflineData().studentHasCourse(student.getIdNumber(), course.getAbsoluteId()) == null){
            addOrRemoveButton.setText("add");
            addOrRemoveButton.addActionListener(this);
            addOrRemoveButton.setActionCommand("add");

            add (requestForAddButton);

        } else{
            addOrRemoveButton.setText("remove");
            addOrRemoveButton.addActionListener(this);
            addOrRemoveButton.setActionCommand("remove");

            add (changeGroupButton);
        }

        add (courseNameLabel);
        add (masterLabel);
        add (unitsLabel);
        add (groupLabel);
        add (idLabel);
        add (addOrRemoveButton);
        add (markOrUnmarkLabel);

        //set component bounds (only needed by Absolute Positioning)
        courseNameLabel.setBounds (75, 30, 300, 25);
        masterLabel.setBounds (75, 55, 300, 25);
        unitsLabel.setBounds (75, 80, 100, 25);
        groupLabel.setBounds (75, 105, 100, 25);
        idLabel.setBounds (75, 155, 115, 25);
        addOrRemoveButton.setBounds (275, 140, 80, 30);
        changeGroupButton.setBounds (360, 140, 120, 30);
        requestForAddButton.setBounds (355, 200, 130, 30);
        markOrUnmarkLabel.setBounds (75, 200, 80, 25);
    }


    public static void popUp(long courseId){
        frame = new JFrame ("CourseEnrollPage");
        frame.setDefaultCloseOperation (JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add (new CourseEnrollmentPage(courseId));
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Student student = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("mark")){
            ServerResponse response = Controller.getInstance().getLibrary().
                    markOrUnmarkCourse(student.getIdNumber(), course.getId(), true);
            frame.setSysMessageText(response.getServerMessage());
        }

        if(e.getActionCommand().equals("unmark")){
            ServerResponse response = Controller.getInstance().getLibrary().
                    markOrUnmarkCourse(student.getIdNumber(), course.getId(), false);
            frame.setSysMessageText(response.getServerMessage());
        }

        if(e.getActionCommand().equals("add")){
            ServerResponse response = Controller.getInstance().getLibrary().enrollCourse(student.getIdNumber(),
                    course.getId(), true);
            frame.setSysMessageText(response.getServerMessage());
        }

        if(e.getActionCommand().equals("change group")){
            LinkedList<Course> allGroups = Controller.getInstance().getOfflineDataNoUpdate().
                    getCourseByAbsoluteId(course.getAbsoluteId(), Controller.getInstance().
                            getOfflineDataNoUpdate().getCourses());

            if(allGroups.size() < 2){
                frame.setSysMessageText("No other groups to change");
                return;
            }

            CourseGroupsPage.popUp(student.getIdNumber(), course.getId(), allGroups);

        }

        if(e.getActionCommand().equals("remove")){
            ServerResponse response = Controller.getInstance().getLibrary().courseChangeGroup(student.getIdNumber(),
                    Controller.getInstance().getOfflineDataNoUpdate().studentHasCourse
                            (student.getIdNumber(), course.getAbsoluteId()).getId()
                    , 0L);
            frame.setSysMessageText(response.getServerMessage());
        }

        if(e.getActionCommand().equals("request for add")){
            ClientRequest request = new ClientRequest();
            request.setType(ClientRequestType.RegisterNewRequest);
            request.addData("studentId", student.getIdNumber());
            request.addData("courseId", course.getId());
            request.addData("chancellorId", Controller.getInstance().getOfflineDataNoUpdate().getCollegeById
                    (course.getCollegeId()).getChancellorId());
            request.addData("requestType", RequestType.EnrollCourse);

            ServerResponse response = Controller.getInstance().getLibrary().registerNewRequest(request);
            frame.setSysMessageText(response.getServerMessage());
        }


        CourseEnrollmentPage.frame.dispose();
    }
}
