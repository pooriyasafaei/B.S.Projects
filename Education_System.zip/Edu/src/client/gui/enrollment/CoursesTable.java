package client.gui.enrollment;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.reportcard_affairs.courses.M_CoursesTable;
import client.gui.table.TableModel;
import client.gui.table.objects_table_module.CoursePublicInfo;
import server.logic.courses.Course;
import server.logic.users.Master;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class CoursesTable extends JPanel implements ActionListener {
    private JTable coursesTable;
    private JLabel coursesListLabel;
    private JLabel filtersLabel;
    private JLabel collegeLabel;
    protected JTextField collegeField;
    private JLabel courseIdLabel;
    protected JTextField courseIdField;
    private JLabel unitsLabel;
    protected JTextField unitsField;
    private JButton filterButton;

    private AbstractTableModel tableModel;
    private JScrollPane pane;

    public CoursesTable(LinkedList<Course> courses) {
        Loop.getInstance().killLoop();

        tableModel = TableModel.createTableModel(CoursePublicInfo.class, CoursePublicInfo.tableList(courses));

        //construct components
        coursesTable = new JTable (tableModel);
        pane = new JScrollPane(coursesTable);
        add(pane);

        coursesListLabel = new JLabel ("Courses:");
        filtersLabel = new JLabel ("Filters:");
        collegeLabel = new JLabel ("College:");
        collegeField = new JTextField (5);
        courseIdLabel = new JLabel ("CourseID:");
        courseIdField = new JTextField (5);
        unitsLabel = new JLabel ("Units:");
        unitsField = new JTextField (5);

        filterButton = new JButton("Filter");
        filterButton.addActionListener(this);
        filterButton.setActionCommand("filter");

        //set components properties
        collegeField.setToolTipText ("Enter college name");
        courseIdField.setToolTipText ("Enter course id");
        unitsField.setToolTipText ("Enter units of course");

        //adjust size and set layout
        setPreferredSize (new Dimension (870, 430));
        setLayout (null);

        //add components
        add (coursesListLabel);
        if(!(this instanceof M_CoursesTable)){
           addComponents();
        }
        else if (((Master) Controller.getInstance().getLibrary().refreshPublicInfo()).isChancellor()) addComponents();


        //set component bounds (only needed by Absolute Positioning)
        pane.setBounds (15, 30, 850, 230);
        coursesListLabel.setBounds (0, 0, 100, 25);
        filtersLabel.setBounds (10, 260, 100, 25);
        collegeLabel.setBounds (15, 285, 85, 25);
        collegeField.setBounds (110, 285, 145, 25);
        courseIdLabel.setBounds (15, 310, 70, 25);
        courseIdField.setBounds (110, 310, 145, 25);
        unitsLabel.setBounds (15, 335, 60, 25);
        unitsField.setBounds (110, 335, 145, 25);
        filterButton.setBounds (260, 335, 65, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        repaint();
        revalidate();
    }

    public void  reInitialize(){
        LinkedList<Course> courses = Controller.getInstance()
                .getOfflineData().getCoursesList(collegeField.getText(), courseIdField.getText(), unitsField.getText());

        this.remove(pane);
        tableModel = TableModel.createTableModel
                (CoursePublicInfo.class, CoursePublicInfo.tableList(courses));

        //construct components

        coursesTable = new JTable(tableModel);
        pane = new JScrollPane(coursesTable);

        this.add(pane);
        pane.setBounds(15, 30, 850, 230);

        revalidate();
        repaint();
    }

    private void addComponents(){
        add(filtersLabel);
        add(collegeLabel);
        add(collegeField);
        add(courseIdLabel);
        add(courseIdField);
        add(unitsLabel);
        add(unitsField);
        add(filterButton);
    }

    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new CoursesTable(Controller.getInstance().getOfflineData().
                getCoursesList("","","")));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        //Edu edu = Edu.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("filter")){
            if(user instanceof Master )
                if (((Master) user).isChancellor()) {

                    frame.addComponent(new C_CoursesTable
                            (Controller.getInstance().getOfflineData().getCoursesList
                                    (collegeField.getText(), courseIdField.getText(), unitsField.getText())));
                    return;
                }

            frame.addComponent(new CoursesTable
                    (Controller.getInstance().getOfflineData().getCoursesList
                            (collegeField.getText(), courseIdField.getText(), unitsField.getText())));
        }
    }
}