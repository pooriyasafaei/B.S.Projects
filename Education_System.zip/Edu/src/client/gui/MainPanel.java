package client.gui;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.menus.LoginPanel;
import client.gui.menus.MasterMainMenu;
import client.gui.menus.StudentMainMenu;
import client.gui.profile.ResetPasswordMenu;
import server.logger.Logger;
import server.logic.users.Student;
import server.time.DateTime;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainPanel extends JFrame implements ActionListener, Runnable {

    private static MainPanel frame;
    private final JLabel clock = new JLabel (" " + DateTime.getDateTime());
    private final JButton quitButton = new JButton ("Quit");
    private final JButton mainMenuButton = new JButton ("Main menu");
    private final JButton connectionButton = new JButton ("Main menu");
    private final JLabel sysMessageLabel = new JLabel ("");
    private int theme = 1;


    public static MainPanel getInstance(){
        if (frame == null)
            frame = new MainPanel("Educational System");
        return frame;
    }

    public void disconnect(){
        connectionButton.setText("connect");
        connectionButton.setBackground(new Color(218, 58, 58));
        connectionButton.setEnabled(true);
        setSysMessageText("connection lost");
        repaint();
        revalidate();
    }

    public void setTheme(int theme){
        this.theme = theme;
    }

    public MainPanel(String title){
        this.setTitle(title);

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);

        //setClock(LoginPanel.getInstance());

        quitButton.addActionListener(this);
        quitButton.setActionCommand("quit");

        mainMenuButton.addActionListener(this);
        mainMenuButton.setActionCommand("main menu");

        connectionButton.addActionListener(this);
        connectionButton.setActionCommand("connect");

        this.pack();
        this.revalidate();
        this.repaint();

        Thread ticker = new Thread(this);
        ticker.start();
    }

    public synchronized void addComponent(Component component){

        if(Controller.getInstance().getLoggedIn() == null && !(component instanceof LoginPanel)){
            addComponent(new LoginPanel());
            return;
        }

        this.getContentPane().removeAll();
        this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        repaint();

        if(!((component instanceof LoginPanel) || (component instanceof ResetPasswordMenu))){

            setMainMenuButton((JPanel) component);
            if (theme == 1)
                component.setBackground(new Color(95, 173, 222));

            else  component.setBackground(new Color(176, 143, 95));
        }

        setQuitButton((JPanel) component);

        setClock((JPanel) component);
        setSysMessage((JPanel) component);
        setConnectionButton((JPanel) component);


        this.getContentPane().add(component);

        this.setVisible(true);
        this.pack();
        this.setResizable(false);
        this.setVisible (true);

        sysMessageLabel.setText("");
        revalidate();
        repaint();

    }

    public void addMainMenu(){

        if(Controller.getInstance().getLibrary().refreshPublicInfo() == null) {
        Loop.getInstance().killLoop();
        addComponent(new LoginPanel());
    }
    else {
        if(Controller.getInstance().getLibrary().refreshPublicInfo().getLastSignIn().hasExpired()){
            MainPanel.getInstance().addComponent(new ResetPasswordMenu());
            return;
        }

        if(Controller.getInstance().getLibrary().refreshPublicInfo() instanceof Student){
            MainPanel.getInstance().addComponent(new StudentMainMenu());
        }
        else {
            MainPanel.getInstance().addComponent(new MasterMainMenu());
        }
    }
    }

    private void setQuitButton(JPanel component){
        component.add (quitButton);
        Dimension d = component.getPreferredSize();
        quitButton.setBounds ((int) (d.getWidth() - 60), (int) (d.getHeight() - 25), 60, 25);
    }

    private void setMainMenuButton(JPanel component){
        component.add (mainMenuButton);
        Dimension d = component.getPreferredSize();
        mainMenuButton.setBounds ((int) (d.getWidth() - 160), (int) (d.getHeight() - 25), 100, 25);
    }

    private void setConnectionButton(JPanel component){

        if(Controller.getInstance().isOnline()){
            connectionButton.setText("connected");
            connectionButton.setBackground(new Color(58, 218, 91));
            connectionButton.setEnabled(false);
        } else{
            connectionButton.setText("connect");
            connectionButton.setBackground(new Color(218, 58, 58));
            connectionButton.setEnabled(true);
        }

        component.add (connectionButton);
        Dimension d = component.getPreferredSize();
        connectionButton.setBounds ((int) (d.getWidth() - 260), (int) (d.getHeight() - 25), 100, 25);

        connectionButton.repaint();
        connectionButton.revalidate();
    }

    private void  setSysMessage(JPanel component){
        component.add (sysMessageLabel);
        Dimension d = component.getPreferredSize();
        sysMessageLabel.setBounds (5, (int) (d.getHeight() - 50), 600, 35);
        sysMessageLabel.setEnabled(true);
    }


//    public void setSysMessageText(){
//        sysMessageLabel.setText(Edu.getInstance().getMessage());
//    }

    public void setSysMessageText(String message){
        sysMessageLabel.setText(message);
    }

    private void setClock(JPanel component){
        component.add (clock);
        Dimension d = component.getPreferredSize();
        if (theme == 1)
            clock.setBackground(new Color(143, 203, 130));
        else clock.setBackground(new Color(227, 166, 96));

        clock.setOpaque(true);
        clock.setBounds ((int) (d.getWidth() - 115), 0, 155, 30);
    }

    @Override
    public void actionPerformed(ActionEvent e) {


        switch (e.getActionCommand()){
            case "quit":
                Controller.getInstance().getLibrary().logout();
                Loop.getInstance().killLoop();
                addComponent(new LoginPanel());
                break;

            case "main menu":
                if(Controller.getInstance().getLibrary().refreshPublicInfo() == null) {
                    Loop.getInstance().killLoop();
                    addComponent(new LoginPanel());
                }
                else {
                    if(Controller.getInstance().getLibrary().refreshPublicInfo().getLastSignIn().hasExpired()){
                        Loop.getInstance().killLoop();
                        MainPanel.getInstance().addComponent(new ResetPasswordMenu());
                        return;
                    }

                    if(Controller.getInstance().getLibrary().refreshPublicInfo() instanceof Student){
                        Loop.getInstance().killLoop();
                        MainPanel.getInstance().addComponent(new StudentMainMenu());
                    }
                    else {
                        Loop.getInstance().killLoop();
                        MainPanel.getInstance().addComponent(new MasterMainMenu());
                    }
                }
                break;

            case "connect":
                Controller.getInstance().reconnect();
        }

    }

    @Override
    public void run() {
        try{
            while (true){
                Thread.sleep(1000);
                clock.setText(" " + DateTime.getDateTime());
            }
        }
        catch (InterruptedException e) {
            Logger.logException(clock, "MainPanel.run()", "clock thread broke down!" );
        }
    }
}
