package client.gui.menus;

import client.controller.Controller;
import client.gui.MainPanel;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import server.logic.users.User;

import java.awt.*;
import java.io.File;
import javax.swing.*;

public class MainMenu extends JPanel{

    protected JMenuBar mainMenuBar;
    protected JLabel picture;
    protected JLabel nameLabel;
    protected JLabel emailLabel;
    protected JLabel nameBar;
    protected JLabel emailBar;
    protected JLabel lastLoginLabel;
    protected JLabel lastLoginBar;

    public MainMenu() {

        User user;

         if(Controller.getInstance().isOnline()){
             ServerResponse response = Controller.getInstance().getLibrary().mainMenu();
             user = Controller.getInstance().getLibrary().refreshPublicInfo();
             Controller.getInstance().getLibrary().savePicture((FileEncode) response.readData("picture"));

         } else user = Controller.getInstance().getLibrary().refreshPublicInfo();

        //construct components
        mainMenuBar = new JMenuBar();
        picture = new JLabel ("picture here");

        File f = new File(Controller.getProperties().getProperty("pictures_path") +
                Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber() + ".jpg");
        if(f.isFile())
            picture.setIcon(new ImageIcon(f.getAbsolutePath()));
        else picture.setIcon(new ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));

        nameLabel = new JLabel ("Name:");
        emailLabel = new JLabel ("Email:");
        nameBar = new JLabel (user.getName());
        emailBar = new JLabel (user.getEmail());
        lastLoginLabel = new JLabel ("Last login:");


        lastLoginBar = new JLabel (user.getLastSignIn().toString());

        //adjust size and set layout
        setPreferredSize (new Dimension (605, 430));
        setLayout (null);

        //add components
        add (mainMenuBar);
        add (picture);
        add (nameLabel);
        add (emailLabel);
        add (nameBar);
        add (emailBar);
        add (lastLoginLabel);
        add (lastLoginBar);

        //set component bounds (only needed by Absolute Positioning)
        mainMenuBar.setBounds (0, 0, 460, 30);
        picture.setBounds (10, 40, 90, 120);
        nameLabel.setBounds (115, 50, 40, 25);
        emailLabel.setBounds (115, 75, 40, 25);
        nameBar.setBounds (195, 50, 250, 25);
        emailBar.setBounds (195, 75, 255, 25);
        lastLoginLabel.setBounds (115, 100, 60, 25);
        lastLoginBar.setBounds (195, 100, 120, 25);


    }

    protected User reInitialize(){
        User user;

        if(Controller.getInstance().isOnline()){

            user = Controller.getInstance().getLibrary().refreshPublicInfo();

        } else user = Controller.getInstance().getLibrary().refreshPublicInfo();

        File f = new File(Controller.getProperties().getProperty("pictures_path") +
                Controller.getInstance().getLibrary().refreshPublicInfo().getIdNumber() + ".jpg");
        if(f.isFile())
            picture.setIcon(new ImageIcon(f.getAbsolutePath()));
        else picture.setIcon(new ImageIcon(Controller.getProperties().getProperty("pictures_path") + "default.jpg"));

        nameBar.setText(user.getName());
        emailBar.setText(user.getEmail());

        revalidate();
        repaint();

        return user;
    }

    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new StudentMainMenu());
    }
}
