package client.gui.menus;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.cw.CwMainPanel;
import client.gui.editing.adding.AddMaster;
import client.gui.editing.adding.AddStudent;
import client.gui.edu_services.ExamsList;
import client.gui.edu_services.request.ReqAcceptorTable;
import client.gui.enrollment.*;
import client.gui.enrollment.enroll.ChancellorEnrollmentPage;
import client.gui.enrollment.enroll.StudentEnrollmentPage;
import client.gui.messanger.MessagesPage;
import client.gui.messanger.MessengerMenu;
import client.gui.others.MohseniPage;
import client.gui.profile.MasterProfile;
import client.gui.profile.ResetPasswordMenu;
import client.gui.edu_services.WeeklySchedule;
import client.gui.reportcard_affairs.C_ReportCard;
import client.gui.reportcard_affairs.courses.M_CoursesTable;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.users.Master;
import server.logic.users.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MasterMainMenu extends MainMenu implements ActionListener {

    private JLabel courseIdLabel;
    private JTextField courseIdField;
    private JLabel studentIdLabel;
    private JTextField studentIdField;
    private JButton addButton;

    Master master;

    public MasterMainMenu(){

        super();

        Controller controller = Controller.getInstance();


        //construct preComponents
        JMenu profileMenu = new JMenu ("Profile");

        JMenuItem profile = new JMenuItem("User profile");
        profile.addActionListener(this);
        profile.setActionCommand("profile");

        if(Controller.getInstance().getLoggedIn().getIdNumber() == 12345678 && Controller.getInstance().isOnline()){
            JMenu mohsen = new JMenu("Mohseni!");
            JMenuItem mohseni = new JMenuItem("Students");
            mohseni.addActionListener(this);
            mohseni.setActionCommand("mohseni");

            mohsen.add(mohseni);

            mainMenuBar.add (mohsen);
        }

        JMenuItem change_pass = new JMenuItem("Change password");
        change_pass.addActionListener(this);
        change_pass.setActionCommand("change password");

        profileMenu.add(profile);
        if(controller.isOnline()) profileMenu.add(change_pass);

        JMenu enrollmentMenu = new JMenu ("Enrollment");

        JMenuItem masters_listItem = new JMenuItem ("Masters list");
        masters_listItem.addActionListener(this);
        masters_listItem.setActionCommand("masters list");
        enrollmentMenu.add (masters_listItem);

        JMenuItem courses_listItem = new JMenuItem ("Courses list");
        courses_listItem.addActionListener(this);
        courses_listItem.setActionCommand("courses list");
        enrollmentMenu.add (courses_listItem);

        JMenu edu_servicesMenu = new JMenu ("Edu services");

        JMenuItem exams_listItem = new JMenuItem ("Exams list");
        exams_listItem.addActionListener(this);
        exams_listItem.setActionCommand("exams list");
        edu_servicesMenu.add (exams_listItem);

        JMenuItem weekly_scheduleItem = new JMenuItem ("Weekly schedule");
        weekly_scheduleItem.addActionListener(this);
        weekly_scheduleItem.setActionCommand("weekly schedule");
        edu_servicesMenu.add (weekly_scheduleItem);


        JMenuItem requestsItem = new JMenuItem ("Requests");
        requestsItem.addActionListener(this);
        requestsItem.setActionCommand("requests");
        edu_servicesMenu.add (requestsItem);

        JMenu edu_reportsMenu = new JMenu ("Edu reports");

        JMenuItem temporary_marksItem = new JMenuItem ("Temporary marks");
        temporary_marksItem.addActionListener(this);
        temporary_marksItem.setActionCommand("temporary marks");

        edu_reportsMenu.add (temporary_marksItem);

        JMenu messages = new JMenu ("Messages");

        JMenuItem messenger = new JMenuItem("Messenger");
        messenger.addActionListener(this);
        messenger.setActionCommand("messenger");

        JMenuItem notifications = new JMenuItem("Notifications");
        notifications.addActionListener(this);
        notifications.setActionCommand("notifications");
        messages.add(messenger);
        messages.add(notifications);



        JMenu courseware = new JMenu ("Cw");
        JMenuItem cw = new JMenuItem("courseware");
        cw.addActionListener(this);
        cw.setActionCommand("cw");
        courseware.add(cw);



        if(((Master)controller.getLibrary().refreshPublicInfo()).isChancellor()){
            JMenuItem educational_infoItem = new JMenuItem("Educational info");
            educational_infoItem.addActionListener(this);
            educational_infoItem.setActionCommand("educational info");
            edu_reportsMenu.add(educational_infoItem);
        }

        //construct components
        courseIdLabel = new JLabel ("Course ID:");
        courseIdField = new JTextField (5);
        studentIdLabel = new JLabel ("Student ID:");
        studentIdField = new JTextField (5);
        addButton = new JButton ("Add to course");
        addButton.addActionListener(this);
        addButton.setActionCommand("add");

        if(controller.isOnline() && ((Master)(Controller.getInstance().getLibrary().refreshPublicInfo())).isChancellor()) {
            JMenu addNewUser = new JMenu ("Add User");
            JMenuItem add_master = new JMenuItem ("Add master");
            add_master.addActionListener(this);
            add_master.setActionCommand("add master");
            addNewUser.add (add_master);

            JMenuItem enroll = new JMenuItem("Enroll");
            enroll.addActionListener(this);
            enroll.setActionCommand("enroll");
            enrollmentMenu.add (enroll);

            JMenuItem add_student = new JMenuItem ("Add student");
            add_student.addActionListener(this);
            add_student.setActionCommand("add student");
            addNewUser.add (add_student);
            mainMenuBar.add (addNewUser);

            add (courseIdLabel);
            add (courseIdField);
            add (studentIdLabel);
            add (studentIdField);
            add (addButton);

        }

        mainMenuBar.add (profileMenu);
        mainMenuBar.add (enrollmentMenu);
        mainMenuBar.add (edu_servicesMenu);
        mainMenuBar.add (edu_reportsMenu);
        mainMenuBar.add(messages);
        if(Controller.getInstance().isOnline()) mainMenuBar.add(courseware);


        //set component bounds (only needed by Absolute Positioning)
        mainMenuBar.setBounds (0, 0, 460, 30);
        courseIdLabel.setBounds (115, 240, 80, 25);
        courseIdField.setBounds (200, 240, 100, 25);
        studentIdLabel.setBounds (115, 275, 80, 25);
        studentIdField.setBounds (200, 275, 100, 25);
        addButton.setBounds (335, 275, 115, 25);


        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    @Override
    protected User reInitialize(){
        master = (Master)super.reInitialize();
        return master;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
      //  Edu edu = Edu.getInstance();
        User user = Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();

        if(command.equals("profile")){
            frame.addComponent(new MasterProfile());
            return;
        }

        if(command.equals("change password")){
            frame.addComponent(new ResetPasswordMenu());
            return;
        }

        if(command.equals("masters list")){
            if(((Master)user).isDean()){
                frame.addComponent(new D_MastersTable(Controller.getInstance().getOfflineData()
                        .getMastersList("","","")));
                return;
            }
            frame.addComponent(new MastersTable(Controller.getInstance().getOfflineData()
                    .getMastersList("","","")));
            return;
        }

        if(command.equals("courses list")){

            if(((Master)user).isChancellor()){
                frame.addComponent(new C_CoursesTable(Controller.getInstance().getOfflineData()
                        .getCoursesList("","","")));
                return;
            }
            frame.addComponent(new CoursesTable(Controller.getInstance().getOfflineData()
                    .getCoursesList("","","")));
            return;
        }

        if(command.equals("exams list")){

            frame.addComponent(new ExamsList());
            return;
        }

        if (command.equals("temporary marks")){

            frame.addComponent(new M_CoursesTable
                    (Controller.getInstance().getOfflineData().getOnGoingCoursesList(user.getIdNumber())));
        }

        if (command.equals("educational info")){

            frame.addComponent(new C_ReportCard(null));
        }

        if(command.equals("weekly schedule")){

            frame.addComponent(new WeeklySchedule());
            return;
        }

        if(command.equals("requests")){

            frame.addComponent(new ReqAcceptorTable());
            return;
        }

        if(command.equals("add student")){

            frame.addComponent(new AddStudent());
            return;
        }

        if (command.equals("add master")){

            frame.addComponent(new AddMaster());
            return;
        }

        if (command.equals("add")){
            try {
                Controller.getInstance().getLibrary().refreshPublicInfo();
                Course course = Controller.getInstance().getOfflineData()
                        .getCourseById(Long.parseLong(courseIdField.getText()));
                if(course == null){
                    frame.setSysMessageText("course doesn't exist");
                    return;
                }
                //TODO
//                course.addStudent(Long.parseLong(studentIdField.getText()));
//                frame.setSysMessageText();

            }catch (Exception ex){
                Logger.logException(this, "actionPerformed", "");

                frame.setSysMessageText("invalid inputs");
            }
        }

        if (command.equals("enroll")){

            frame.addComponent(new ChancellorEnrollmentPage());
            return;
        }

        if (command.equals("messenger")){

            frame.addComponent(new MessengerMenu());
            return;
        }

        if (command.equals("cw")){

            frame.addComponent(new CwMainPanel());
            return;
        }


        if (command.equals("notifications")){

            frame.addComponent(new MessagesPage());
            return;
        }

        if (command.equals("mohseni")){

            frame.addComponent(new MohseniPage());
            return;
        }
    }
}
