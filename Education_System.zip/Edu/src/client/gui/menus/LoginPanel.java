package client.gui.menus;

import client.controller.Controller;
import client.controller.Loop;
import communication.server.ServerResponse;
import server.logic.login.CaptchaClass;
import client.gui.MainPanel;
import client.gui.profile.ResetPasswordMenu;
import server.logger.Logger;
import server.logic.users.Student;
import server.logic.users.User;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class LoginPanel extends JPanel implements ActionListener {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel welcomeLabel;
    private JLabel captchaIcon;
    private JButton captchaReload;
    private JButton loginButton;
    private JButton exitButton;
    private JLabel usernameLabel;
    private JLabel passwordLabel;
    private JTextField captchaField;
    private JLabel captchaReloadLabel;
    private JLabel enterCaptchaLabel;

    public LoginPanel() {

        makeComponents();

        //adjust size and set layout
        setPreferredSize (new Dimension (601, 449));
        setLayout (null);

        //add components
        addComponents();

        //set component bounds (only needed by Absolute Positioning)
        setBounds();
        setPreferredSize (new Dimension (588, 430));
        setLayout (null);
    }

    private void makeComponents(){

        //construct components
        usernameField = new JTextField (5);
        passwordField = new JPasswordField (5);
        welcomeLabel = new JLabel ("Welcome to EDU!");
        welcomeLabel.setBackground(new Color(76, 90, 243));
        welcomeLabel.setOpaque(true);

        exitButton = new JButton("Exit");
        exitButton.addActionListener(this);
        exitButton.setActionCommand("exit");

        captchaIcon = new JLabel ("");
        captchaIcon.setIcon(CaptchaClass.getInstance().getRandomCaptcha());

        captchaReload = new JButton ("");
        captchaReload.addActionListener(this);
        captchaReload.setActionCommand("reload captcha");

        loginButton = new JButton ("login");
        loginButton.addActionListener(this);
        loginButton.setActionCommand("login");

        usernameLabel = new JLabel ("     username:");
        usernameLabel.setBackground(new Color(116, 190, 136));
        usernameLabel.setOpaque(true);

        passwordLabel = new JLabel ("     password:");
        passwordLabel.setBackground(new Color(116, 190, 136));
        passwordLabel.setOpaque(true);

        captchaField = new JTextField (5);

        captchaReloadLabel = new JLabel ("recaptcha");
        enterCaptchaLabel = new JLabel ("enter captcha:");

        //set components properties
        usernameField.setToolTipText ("enter username");
        passwordField.setToolTipText ("enter password");
        captchaField.setToolTipText("enter captcha");
    }

    private void addComponents(){

        add (usernameField);
        add (passwordField);
        add (welcomeLabel);
        add (captchaIcon);
        add (captchaReload);
        add (loginButton);
        add (usernameLabel);
        add (passwordLabel);
        add (captchaField);
        add (captchaReloadLabel);
        add (enterCaptchaLabel);
        add (exitButton);
    }

    private void setBounds(){

        usernameField.setBounds (240, 95, 100, 25);
        passwordField.setBounds (240, 135, 100, 25);
        welcomeLabel.setBounds (30, 20, 100, 25);
        captchaIcon.setBounds (240, 160, 100, 75);
        captchaReload.setBounds (340, 245, 20, 20);
        loginButton.setBounds (150, 305, 100, 25);
        usernameLabel.setBounds (120, 95, 100, 25);
        passwordLabel.setBounds (120, 135, 100, 25);
        captchaField.setBounds (240, 240, 60, 25);
        captchaReloadLabel.setBounds (360, 240, 60, 30);
        enterCaptchaLabel.setBounds (120, 240, 100, 25);
        exitButton.setBounds ((588 - 60), (430 - 25), 60, 25);
    }

    public void refresh(){

        captchaIcon.setIcon(CaptchaClass.getInstance().getRandomCaptcha());

        revalidate();
        repaint();
    }

    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new LoginPanel());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    //    Edu edu = Edu.getInstance();
        MainPanel frame = MainPanel.getInstance();

        switch (e.getActionCommand()){

            case "login":
               try {

                       if(!CaptchaClass.getInstance().checkCaptchaCode(captchaField.getText(), (ImageIcon) captchaIcon.getIcon()))
                       {
                           MainPanel.getInstance().setSysMessageText(Controller.getProperties().getProperty("captcha_error"));
                           break;
                       }

                       ServerResponse loginResponse = Controller.getInstance().getLibrary().
                           login(Long.parseLong(usernameField.getText()),String.valueOf(passwordField.getPassword()));

                       User user;

                       if(!loginResponse.isFlag()){
                           frame.setSysMessageText(loginResponse.getServerMessage());
                           break;
                       }


                       user =  Controller.getInstance().getOfflineDataNoUpdate().
                               getUserById((Long) loginResponse.readData("user"));


                       if(user.getLastSignIn().hasExpired()){
                           MainPanel.getInstance().addComponent(new ResetPasswordMenu());
                           return;
                       }

                       if (user instanceof Student) {
                           MainPanel.getInstance().addComponent(new StudentMainMenu());
                       } else MainPanel.getInstance().addComponent(new MasterMainMenu());

                     //  frame.setSysMessageText();

            } catch (Exception ex){

                   ex.printStackTrace();

                   Logger.logException(this, "actionPerformed", "input Exception");
                   frame.setSysMessageText("invalid username or password");
               }
                break;

            case "reload captcha":
                captchaIcon.setIcon(CaptchaClass.getInstance().getRandomCaptcha());
                revalidate();
                repaint();
                break;

            case "exit":
                //TODO.

        }
        refresh();
    }
}
