package client.gui.menus;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import client.gui.cw.CwMainPanel;
import client.gui.edu_services.ExamsList;
import client.gui.edu_services.WeeklySchedule;
import client.gui.edu_services.request.BachelorReqTable;
import client.gui.edu_services.request.MastersReqTable;
import client.gui.edu_services.request.PhdReqTable;
import client.gui.enrollment.CoursesTable;
import client.gui.enrollment.enroll.StudentEnrollmentPage;
import client.gui.messanger.MessagesPage;
import client.gui.messanger.MessengerMenu;
import client.gui.profile.ResetPasswordMenu;
import client.gui.profile.StudentProfile;
import client.gui.enrollment.MastersTable;
import client.gui.reportcard_affairs.ReportCard;
import client.gui.reportcard_affairs.courses.StudentCourseTempMarksTable;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentMainMenu extends MainMenu implements ActionListener {

    private JLabel supervisorLabel;
    private JLabel supervisorField;
    private JLabel allowEnroll;
    private JLabel enrollmentAllowed;
    private JLabel enrollTimeLabel;
    private JLabel enrollTimeField;
    private JLabel eduStatusLabel;
    private JLabel statLabel;

    private Student student;

    public StudentMainMenu(){

        super();

        Controller controller = Controller.getInstance();

        //construct preComponents
        JMenu profileMenu = new JMenu ("Profile");

        JMenuItem profile = new JMenuItem("User profile");
        profile.addActionListener(this);
        profile.setActionCommand("profile");


        JMenuItem change_pass = new JMenuItem("Change password");
        change_pass.addActionListener(this);
        change_pass.setActionCommand("change password");

        
        JMenu enrollmentMenu = new JMenu ("Enrollment");
        JMenuItem masters_listItem = new JMenuItem ("Masters list");
        masters_listItem.addActionListener(this);
        masters_listItem.setActionCommand("masters list");
        enrollmentMenu.add (masters_listItem);

        JMenuItem courses_listItem = new JMenuItem ("Courses list");
        courses_listItem.addActionListener(this);
        courses_listItem.setActionCommand("courses list");
        enrollmentMenu.add (courses_listItem);

        JMenu edu_servicesMenu = new JMenu ("Edu services");
        JMenuItem exams_listItem = new JMenuItem ("Exams list");
        exams_listItem.addActionListener(this);
        exams_listItem.setActionCommand("exams list");
        edu_servicesMenu.add (exams_listItem);

        JMenuItem weekly_scheduleItem = new JMenuItem ("Weekly schedule");
        weekly_scheduleItem.addActionListener(this);
        weekly_scheduleItem.setActionCommand("weekly schedule");
        edu_servicesMenu.add (weekly_scheduleItem);

        JMenuItem requestsItem = new JMenuItem ("Requests");
        requestsItem.addActionListener(this);
        requestsItem.setActionCommand("requests");
        edu_servicesMenu.add (requestsItem);

        JMenu edu_reportsMenu = new JMenu ("Edu reports");
        JMenuItem temporary_marksItem = new JMenuItem ("Temporary marks");
        temporary_marksItem.addActionListener(this);
        temporary_marksItem.setActionCommand("temporary marks");
        edu_reportsMenu.add (temporary_marksItem);

        JMenuItem educational_infoItem = new JMenuItem ("Educational info");
        educational_infoItem.addActionListener(this);
        educational_infoItem.setActionCommand("educational info");
        edu_reportsMenu.add (educational_infoItem);

        JMenu messages = new JMenu ("Messages");

        JMenuItem messenger = new JMenuItem("Messenger");
        messenger.addActionListener(this);
        messenger.setActionCommand("messenger");

        JMenuItem notifications = new JMenuItem("Notifications");
        notifications.addActionListener(this);
        notifications.setActionCommand("notifications");
        messages.add(messenger);
        messages.add(notifications);


        JMenu courseware = new JMenu ("Courseware");
        JMenuItem cw = new JMenuItem("Cw");
        cw.addActionListener(this);
        cw.setActionCommand("cw");
        courseware.add(cw);


        profileMenu.add(profile);
        if(controller.isOnline()) {
            profileMenu.add(change_pass);

            if(DateTime.isEnrollTime(((Student)Controller.getInstance().getLoggedIn()).getRegisterTime())){
                JMenuItem enroll = new JMenuItem("Enroll");
                enroll.addActionListener(this);
                enroll.setActionCommand("enroll");
                enrollmentMenu.add(enroll);
            }
        }

        //construct components

        mainMenuBar.add (profileMenu);
        mainMenuBar.add (enrollmentMenu);
        mainMenuBar.add (edu_servicesMenu);
        mainMenuBar.add (edu_reportsMenu);
        mainMenuBar.add (messages);
        if(Controller.getInstance().isOnline()) mainMenuBar.add(courseware);



        supervisorLabel = new JLabel ("Supervisor:");


        allowEnroll = new JLabel ("Enrollment is allowed:");
        enrollTimeLabel = new JLabel ("Enrollment time:");
        eduStatusLabel = new JLabel ("Educational status:");

        supervisorField = new JLabel();
        enrollmentAllowed = new JLabel();
        enrollTimeField = new JLabel ();
        statLabel = new JLabel ();

        reInitialize();

        //add components
        add (supervisorLabel);
        add (supervisorField);
        add (allowEnroll);
        add (enrollmentAllowed);
        add (enrollTimeLabel);
        add (enrollTimeField);
        add (eduStatusLabel);
        add (statLabel);

        //set component bounds (only needed by Absolute Positioning)
        supervisorLabel.setBounds (115, 155, 70, 25);
        supervisorField.setBounds (195, 155, 250, 25);
        allowEnroll.setBounds (115, 180, 130, 25);
        enrollmentAllowed.setBounds (255, 180, 40, 25);
        enrollTimeLabel.setBounds (115, 205, 100, 25);
        enrollTimeField.setBounds (220, 205, 120, 25);
        eduStatusLabel.setBounds (115, 260, 250, 25);
        statLabel.setBounds (240, 260, 250, 25);

        Loop.getInstance().makePingLoop(this::reInitialize);

        revalidate();
        repaint();
    }

    @Override
    protected User reInitialize(){

        student = (Student) super.reInitialize();

        Controller controller = Controller.getInstance();

        supervisorField.setText(controller.getOfflineData()
                        .getUserById(student.getSupervisorId()).getName());

        enrollmentAllowed.setText(String.valueOf(student.isRegisterAllowed()));
        enrollTimeField.setText(String.valueOf(student.getRegisterTime()));
        statLabel.setText(student.getEduStatus());

        revalidate();
        repaint();

        return student;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
        Student user = (Student) Controller.getInstance().getLibrary().refreshPublicInfo();
        String command = e.getActionCommand();
       // Edu edu = Edu.getInstance();

        if (command.equals("profile")){
            frame.addComponent(new StudentProfile(user));
        }

        if (command.equals("change password")){
            frame.addComponent(new ResetPasswordMenu());
        }

        if(command.equals("masters list")){
            frame.addComponent(new MastersTable
                    (Controller.getInstance().getOfflineData().getMastersList("","","")));
        }

        if (command.equals("courses list")){
            frame.addComponent(new CoursesTable
                    (Controller.getInstance().getOfflineData().getCoursesList("","","")));
        }

        if (command.equals("exams list")){
            frame.addComponent(new ExamsList());
        }

        if (command.equals("weekly schedule")){
            frame.addComponent(new WeeklySchedule());
        }

        if (command.equals("requests")){

            if(student.isMasters()){
                frame.addComponent(new MastersReqTable());
                return;
            }
            if(student.isPhd()){
                frame.addComponent(new PhdReqTable());
                return;
            }

                frame.addComponent(new BachelorReqTable());
        }

        if (command.equals("temporary marks")){

            frame.addComponent(new StudentCourseTempMarksTable(user));
        }

        if (command.equals("educational info")){

            frame.addComponent(new ReportCard(user));
        }

        if (command.equals("enroll")){

            frame.addComponent(new StudentEnrollmentPage());
        }

        if (command.equals("messenger")){

            frame.addComponent(new MessengerMenu());
            return;
        }

        if (command.equals("cw")){

            frame.addComponent(new CwMainPanel());
            return;
        }

        if (command.equals("notifications")){

            frame.addComponent(new MessagesPage());
            return;
        }
    }
}
