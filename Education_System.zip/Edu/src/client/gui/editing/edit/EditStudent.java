package client.gui.editing.edit;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.users.Student;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EditStudent extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel nationalIdLabel;
    private JLabel masterNumberLabel;
    private JLabel phoneNoLabel;
    private JLabel emailLabel;
    private JLabel collegeLabel;
    private JLabel entryYearLabel;
    private JLabel eduLevelLabel;
    private JTextField emailField;
    private JTextField phoneNoField;
    private JTextField entryYearField;
    private JTextField levelField;
    private JButton registerButton;
    private JLabel registerTimeLabel;
    private JTextField registerTimeField;
    private JLabel supervisorIDLabel;
    private JTextField supervisorIDField;
    private JRadioButton accountActivated;
    private JRadioButton registerAllowed;

    private Student student;

    public EditStudent(Student student) {
        Loop.getInstance().killLoop();

        this.student = student;
        //construct components
        nameLabel = new JLabel ("Full Name: " + student.getName());
        nationalIdLabel = new JLabel ("National ID: " + student.getNationalId());
        masterNumberLabel = new JLabel ("Student Number: " + student.getIdNumber());
        phoneNoLabel = new JLabel ("Phone No. :");
        emailLabel = new JLabel ("Email:");
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData()
                .getCollegeById(student.getCollegeId()).getName());
        entryYearLabel = new JLabel ("Entry Year:");
        eduLevelLabel = new JLabel ("Educational Level:");
        emailField = new JTextField (5);
        phoneNoField = new JTextField (5);
        entryYearField = new JTextField (5);
        levelField = new JTextField (5);
        registerButton = new JButton ("Save");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("save");

        supervisorIDLabel = new JLabel ("SupervisorID:");
        supervisorIDField = new JTextField (5);
        accountActivated = new JRadioButton ("Account is active");
        registerAllowed = new JRadioButton ("Prohibit enrollment");

        registerTimeLabel = new JLabel ("Registering client.time:");
        registerTimeField = new JTextField (5);

        //set components properties
        emailField.setToolTipText ("Enter new email then press 'Edit profile'");
        phoneNoField.setToolTipText ("Enter new phone number then press 'Edit profile'");
        levelField.setToolTipText ("Enter student educational level(masters, phd or bachelor)");
        registerTimeField.setToolTipText("Enter date in standard protocol(YY/MM/DD)");


        //adjust size and set layout
        setPreferredSize (new Dimension (650, 430));
        setLayout (null);

        //add components
        add (nameLabel);
        add (nationalIdLabel);
        add (masterNumberLabel);
        add (phoneNoLabel);
        add (emailLabel);
        add (collegeLabel);
        add (entryYearLabel);
        add (eduLevelLabel);
        add (emailField);
        add (phoneNoField);
        add (entryYearField);
        add (levelField);
        add (registerButton);
        add (supervisorIDLabel);
        add (supervisorIDField);
        add (accountActivated);
        add (registerAllowed);
        add (registerTimeLabel);
        add (registerTimeField);

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (140, 55, 400, 25);
        nationalIdLabel.setBounds (140, 80, 240, 25);
        masterNumberLabel.setBounds (140, 105, 250, 25);
        phoneNoLabel.setBounds (140, 165, 70, 25);
        emailLabel.setBounds (140, 190, 40, 25);
        collegeLabel.setBounds (140, 130, 290, 25);
        entryYearLabel.setBounds (140, 215, 65, 25);
        eduLevelLabel.setBounds (140, 240, 105, 25);
        emailField.setBounds (265, 190, 250, 25);
        phoneNoField.setBounds (265, 165, 250, 25);
        entryYearField.setBounds (265, 215, 100, 25);
        levelField.setBounds (265, 240, 100, 25);
        registerButton.setBounds (415, 350, 85, 28);
        supervisorIDLabel.setBounds (140, 265, 100, 25);
        supervisorIDField.setBounds (265, 265, 100, 25);
        registerTimeLabel.setBounds (140, 290, 100, 25);
        registerTimeField.setBounds (265, 290, 100, 25);
        accountActivated.setBounds (145, 325, 130, 25);
        registerAllowed.setBounds (145, 350, 150, 25);

    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
    //    frame.addComponent(new EditStudent());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("save")){
            ServerResponse response = Controller.getInstance().getLibrary().editStudent
                    (student.getIdNumber(), phoneNoField.getText(), entryYearField.getText(), emailField.getText(),
                    levelField.getText(), supervisorIDField.getText(), registerTimeField.getText(),
                    !accountActivated.isSelected(), !registerAllowed.isSelected());
            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
