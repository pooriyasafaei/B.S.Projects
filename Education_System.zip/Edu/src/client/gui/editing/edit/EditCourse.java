package client.gui.editing.edit;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.courses.Course;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EditCourse extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel CourseIdLabel;
    private JLabel phoneNoLabel;
    private JLabel masterLabel;
    private JLabel collegeLabel;
    private JLabel examTimeLabel;
    private JLabel unitsLabel;
    private JTextField timeInWeekField;
    private JTextField nameField;
    private JTextField examTimeField;
    private JTextField masterField;
    private JButton editButton;
    private JTextField unitsField;
    private Course course;

    public EditCourse(Course course) {
        Loop.getInstance().killLoop();

        this.course = course;
        //construct components
        nameLabel = new JLabel ("Course Name:");
        CourseIdLabel = new JLabel ("Course ID: " + course.getId());
        phoneNoLabel = new JLabel ("Time in week:");
        masterLabel = new JLabel ("MasterID:");
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData()
                .getCollegeById(course.getCollegeId()).getName());
        examTimeLabel = new JLabel ("Exam client.time:");
        unitsLabel = new JLabel ("Units: ");
        timeInWeekField = new JTextField (5);
        nameField = new JTextField (5);
        examTimeField = new JTextField (5);
        masterField = new JTextField (5);
        editButton = new JButton ("Edit");
        editButton.addActionListener(this);
        editButton.setActionCommand("edit");

        unitsField = new JTextField (5);

        //set components properties
        timeInWeekField.setToolTipText ("Change day and hour in week");
        nameField.setToolTipText ("Enter new name");
        examTimeField.setToolTipText ("Enter new client.time(with client.time standard protocol YY/MM/DD HH:MM)");
        masterField.setToolTipText ("master id");
        unitsField.setToolTipText ("Enter int units for the course");

        //adjust size and set layout
        setPreferredSize (new Dimension (650, 430));
        setLayout (null);

        //add components
        add (nameLabel);
        add (CourseIdLabel);
        add (phoneNoLabel);
        add (masterLabel);
        add (collegeLabel);
        add (examTimeLabel);
        add (unitsLabel);
        add (timeInWeekField);
        add (nameField);
        add (examTimeField);
        add (masterField);
        add (editButton);
        add (unitsField);

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (140, 120, 90, 25);
        CourseIdLabel.setBounds (140, 60, 200, 25);
        phoneNoLabel.setBounds (140, 145, 90, 25);
        masterLabel.setBounds (140, 195, 65, 25);
        collegeLabel.setBounds (140, 85, 290, 25);
        examTimeLabel.setBounds (140, 170, 65, 25);
        unitsLabel.setBounds (140, 235, 40, 25);
        timeInWeekField.setBounds (265, 145, 250, 25);
        nameField.setBounds (265, 120, 250, 25);
        examTimeField.setBounds (265, 170, 100, 25);
        masterField.setBounds (265, 195, 100, 25);
        editButton.setBounds (415, 315, 85, 28);
        unitsField.setBounds (265, 235, 50, 25);
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
       // frame.addComponent(new EditCourse());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("edit")){
            ServerResponse response = Controller.getInstance().getLibrary().editCourse(
                    course.getId() ,nameField.getText(), timeInWeekField.getText(), examTimeField.getText(),
                    masterField.getText(), unitsField.getText());
            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
