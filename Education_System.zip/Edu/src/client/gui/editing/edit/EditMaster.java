package client.gui.editing.edit;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logic.users.Master;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class EditMaster extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel nationalIdLabel;
    private JLabel masterNumberLabel;
    private JLabel phoneNoLabel;
    private JLabel emailLabel;
    private JLabel collegeLabel;
    private JLabel entryYearLabel;
    private JLabel eduLevelLabel;
    private JTextField emailField;
    private JTextField phoneNoField;
    private JTextField roomNoField;
    private JTextField levelField;
    private JButton registerButton;
    private JRadioButton accountActivated;
    private JRadioButton setChancellor;
    private Master master;

    public EditMaster(Master master) {
        Loop.getInstance().killLoop();

        this.master = master;
        //construct components
        nameLabel = new JLabel ("Full Name: " + master.getName());
        nationalIdLabel = new JLabel ("National ID: " + master.getNationalId());
        masterNumberLabel = new JLabel ("Master Number: " + master.getIdNumber());
        phoneNoLabel = new JLabel ("Phone No.: ");
        emailLabel = new JLabel ("Email:");
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData()
                .getCollegeById(master.getCollegeId()).getName());
        entryYearLabel = new JLabel ("Room No.:");
        eduLevelLabel = new JLabel ("Master Degree:");
        emailField = new JTextField (5);
        phoneNoField = new JTextField (5);
        roomNoField = new JTextField (5);
        levelField = new JTextField (5);
        registerButton = new JButton ("Save");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("save");

        accountActivated = new JRadioButton ("Deactivate the account");
        setChancellor = new JRadioButton ("Set chancellor of college");

        //accountActivated.doClick();

        //set components properties
        emailField.setToolTipText ("Enter new email then press 'Edit profile'");
        phoneNoField.setToolTipText ("Enter new phone number then press 'Edit profile'");
        levelField.setToolTipText ("Enter student educational level(masters, phd or...)");

        //adjust size and set layout
        setPreferredSize (new Dimension (650, 430));
        setLayout (null);

        //add components
        add (nameLabel);
        add (nationalIdLabel);
        add (masterNumberLabel);
        add (phoneNoLabel);
        add (emailLabel);
        add (collegeLabel);
        add (entryYearLabel);
        add (eduLevelLabel);
        add (emailField);
        add (phoneNoField);
        add (roomNoField);
        add (levelField);
        add (registerButton);
        add (accountActivated);
        add (setChancellor);

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (140, 55, 400, 25);
        nationalIdLabel.setBounds (140, 80, 200, 25);
        masterNumberLabel.setBounds (140, 105, 250, 25);
        phoneNoLabel.setBounds (140, 165, 70, 25);
        emailLabel.setBounds (140, 190, 40, 25);
        collegeLabel.setBounds (140, 130, 290, 25);
        entryYearLabel.setBounds (140, 215, 65, 25);
        eduLevelLabel.setBounds (140, 240, 105, 25);
        emailField.setBounds (265, 190, 250, 25);
        phoneNoField.setBounds (265, 165, 250, 25);
        roomNoField.setBounds (265, 215, 100, 25);
        levelField.setBounds (265, 240, 100, 25);
        registerButton.setBounds (415, 315, 85, 28);
        accountActivated.setBounds (145, 315, 170, 25);
        setChancellor.setBounds (145, 290, 170, 25);


    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
      //  frame.addComponent(new EditMaster());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
    // Edu edu = Edu.getInstance();
  //  User user = edu.getUserLoggedIn();
        String command = e.getActionCommand();

        if(e.getActionCommand().equals("save")){
           ServerResponse response = Controller.getInstance().getLibrary().editMaster(master.getIdNumber(),
                    phoneNoField.getText(), roomNoField.getText(), emailField.getText(),
                    levelField.getText(), setChancellor.isSelected(), !accountActivated.isSelected());
            frame.addComponent(new EditMaster(master));
            frame.setSysMessageText(response.getServerMessage());
        }
    }
}
