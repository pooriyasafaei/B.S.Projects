package client.gui.editing.adding;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AddMaster extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel nationalIdLabel;
    private JLabel masterNumberLabel;
    private JLabel phoneNoLabel;
    private JLabel emailLabel;
    private JLabel collegeLabel;
    private JLabel entryYearLabel;
    private JLabel eduLevelLabel;
    private JLabel birthdayLabel;

    private JTextField emailField;
    private JTextField phoneNoField;
    private JTextField nameField;
    private JTextField nationalIdField;
    private JTextField masterNoField;
    private JTextField roomNoField;
    private JTextField levelField;
    private JTextField birthdayField;

    private JLabel idLabel;
    private JTextField idField;

    private JButton registerButton;

    public AddMaster() {
        Loop.getInstance().killLoop();

        Controller.getInstance().getLibrary().refreshPublicInfo();
        //construct components
        nameLabel = new JLabel ("Full Name:");
        nationalIdLabel = new JLabel ("National ID: ");
        masterNumberLabel = new JLabel ("Master Number: ");
        phoneNoLabel = new JLabel ("Phone No. :");
        emailLabel = new JLabel ("Email:");
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData().getCollegeById
                (Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId()).getName());
        entryYearLabel = new JLabel ("Room No.:");
        eduLevelLabel = new JLabel ("Master Degree:");
        emailField = new JTextField (5);
        phoneNoField = new JTextField (5);
        nameField = new JTextField (5);
        nationalIdField = new JTextField (5);
        masterNoField = new JTextField (5);
        roomNoField = new JTextField (5);
        levelField = new JTextField (5);
        registerButton = new JButton ("Register");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("register");

        birthdayLabel = new JLabel ("Birthday:");
        birthdayField = new JTextField (5);

        idLabel = new JLabel ("ID:");
        idField = new JTextField (5);


        //set components properties
        emailField.setToolTipText ("Enter new email then press 'Edit profile'");
        phoneNoField.setToolTipText ("Enter new phone number then press 'Edit profile'");
        nationalIdField.setToolTipText ("It should not be duplicate");
        masterNoField.setToolTipText ("It should not be duplicate");
        levelField.setToolTipText ("Enter student educational level(masters, phd or...)");
        birthdayField.setToolTipText("Enter date in standard protocol(YY/MM/DD)");
        idField.setToolTipText("Enter a new ID for user");

        //adjust size and set layout
        setPreferredSize (new Dimension (601, 430));
        setLayout (null);

        //add components
        add (nameLabel);
        add (nationalIdLabel);
        add (masterNumberLabel);
        add (phoneNoLabel);
        add (emailLabel);
        add (collegeLabel);
        add (entryYearLabel);
        add (eduLevelLabel);
        add (emailField);
        add (phoneNoField);
        add (nameField);
        add (nationalIdField);
        add (masterNoField);
        add (roomNoField);
        add (levelField);
        add (registerButton);
        add (birthdayLabel);
        add (birthdayField);

        //set component bounds (only needed by Absolute Positioning)
        idLabel.setBounds(140, 30, 65, 25);
        nameLabel.setBounds (140, 55, 65, 25);
        nationalIdLabel.setBounds (140, 80, 70, 25);
        masterNumberLabel.setBounds (140, 105, 100, 25);
        phoneNoLabel.setBounds (140, 130, 70, 25);
        emailLabel.setBounds (140, 155, 40, 25);
        collegeLabel.setBounds (140, 180, 290, 25);
        entryYearLabel.setBounds (140, 215, 65, 25);
        eduLevelLabel.setBounds (140, 240, 105, 25);
        birthdayLabel.setBounds (140, 265, 105, 25);

        emailField.setBounds (265, 155, 250, 25);
        phoneNoField.setBounds (265, 130, 250, 25);
        idField.setBounds(265, 30, 100, 25);
        nameField.setBounds (265, 55, 100, 25);
        nationalIdField.setBounds (265, 80, 100, 25);
        masterNoField.setBounds (265, 105, 100, 25);
        roomNoField.setBounds (265, 215, 100, 25);
        levelField.setBounds (265, 240, 100, 25);
        birthdayField.setBounds (265, 265, 100, 25);

        registerButton.setBounds (415, 315, 85, 28);

    }

    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new AddMaster());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();

        if(e.getActionCommand().equals("register")){
            try {
                ServerResponse response = Controller.getInstance().
                        getLibrary().addMaster(nameField.getText(), nationalIdField.getText(), nationalIdField.getText(),
                        Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId(), Long.parseLong(masterNoField.getText()),
                        DateTime.toDateTime(birthdayField.getText() + " 00:00:00"),
                        levelField.getText(), false, false, Integer.parseInt(roomNoField.getText()));


                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex){
                frame.setSysMessageText("invalid inputs");
                Logger.logException(this, "actionPerformed", "input Exception");
            }
        }
    }
}

