package client.gui.editing.adding;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;
import server.time.TimeInWeek;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Objects;
import javax.swing.*;

public class AddCourse extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel courseIdLabel;
    private JLabel phoneNoLabel;
    private JLabel masterLabel;
    private JLabel collegeLabel;
    private JLabel examTimeLabel;
    private JLabel unitsLabel;
    private JTextField timeInWeekField;
    private JTextField nameField;
    private JTextField examTimeField;
    private JTextField masterField;
    private JButton addButton;
    private JTextField unitsField;
    private JTextField courseIdField;

    private JLabel sectionLabel;
    private JTextField sectionField;
    private JLabel prerequisitesLabel;
    private JTextField prerequisitesField;
    private JLabel necessitiesLabel;
    private JTextField necessitiesField;
    private JLabel capacityLabel;
    private JTextField capacityField;
    private JLabel semisterLabel;
    private JTextField semisterField;
    private JLabel groupLabel;
    private JTextField groupField;
    private JLabel assistantsLabel;
    private JTextField assistantsField;

    public AddCourse() {
        Loop.getInstance().killLoop();

        //construct components
        nameLabel = new JLabel ("Course Name:");
        courseIdLabel = new JLabel ("Course ID: ");
        phoneNoLabel = new JLabel ("Time in week:");
        masterLabel = new JLabel ("MasterID:");

        Controller.getInstance().getLibrary().refreshPublicInfo();

        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData().getCollegeById
                (Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId()).getName());
        examTimeLabel = new JLabel ("Exam time:");
        unitsLabel = new JLabel ("Units: ");
        timeInWeekField = new JTextField (5);
        nameField = new JTextField (5);
        examTimeField = new JTextField (5);
        masterField = new JTextField (5);
        addButton = new JButton ("Add");
        addButton.addActionListener(this);
        addButton.setActionCommand("add");

        unitsField = new JTextField (5);
        courseIdField = new JTextField (5);

        sectionLabel = new JLabel ("Section:");
        sectionField = new JTextField (5);
        prerequisitesLabel = new JLabel ("Prerequisites:");
        prerequisitesField = new JTextField (5);
        necessitiesLabel = new JLabel ("Necessities:");
        necessitiesField = new JTextField (5);
        capacityLabel = new JLabel ("Capacity:");
        capacityField = new JTextField (5);
        semisterLabel = new JLabel ("Semister:");
        semisterField = new JTextField (5);
        groupLabel = new JLabel ("Group:");
        groupField = new JTextField (5);
        assistantsLabel = new JLabel ("Assistants:");
        assistantsField = new JTextField (5);

        //set components properties
        timeInWeekField.setToolTipText ("Change day and hour in week");
        nameField.setToolTipText ("Enter new name");
        examTimeField.setToolTipText ("Enter new client.time(with client.time standard protocol YY/MM/DD HH:MM)");
        masterField.setToolTipText ("master id");
        unitsField.setToolTipText ("Enter int units for the course");
        courseIdField.setToolTipText ("Enter course ID here");

        sectionField.setToolTipText ("Enter section here(Bachelor, Masters or PHD)");
        prerequisitesField.setToolTipText ("Seprat prerequisites id with ','");
        necessitiesField.setToolTipText ("Seprate necessities id with ','");


        //adjust size and set layout
        setPreferredSize (new Dimension (657, 620));
        setLayout (null);

        //add components
        add (nameLabel);
        add (courseIdLabel);
        add (phoneNoLabel);
        add (masterLabel);
        add (collegeLabel);
        add (examTimeLabel);
        add (unitsLabel);
        add (timeInWeekField);
        add (nameField);
        add (examTimeField);
        add (masterField);
        add (addButton);
        add (unitsField);
        add (courseIdField);

        add (sectionLabel);
        add (sectionField);
        add (prerequisitesLabel);
        add (prerequisitesField);
        add (necessitiesLabel);
        add (necessitiesField);
        add (capacityLabel);
        add (capacityField);
        add (semisterLabel);
        add (semisterField);
        add (groupLabel);
        add (groupField);
        add (assistantsLabel);
        add (assistantsField);


        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (140, 120, 90, 25);
        courseIdLabel.setBounds (140, 80, 65, 25);
        phoneNoLabel.setBounds (140, 145, 90, 25);
        masterLabel.setBounds (140, 195, 65, 25);
        collegeLabel.setBounds (140, 275, 290, 25);
        examTimeLabel.setBounds (140, 170, 65, 25);
        unitsLabel.setBounds (140, 235, 40, 25);
        timeInWeekField.setBounds (265, 145, 250, 25);
        nameField.setBounds (265, 120, 250, 25);
        examTimeField.setBounds (265, 170, 100, 25);
        masterField.setBounds (265, 195, 100, 25);
        addButton.setBounds (435, 490, 85, 28);
        unitsField.setBounds (265, 235, 50, 25);
        courseIdField.setBounds (265, 85, 100, 25);

        sectionLabel.setBounds (140, 310, 100, 25);
        sectionField.setBounds (265, 310, 100, 25);
        prerequisitesLabel.setBounds (140, 335, 100, 25);
        prerequisitesField.setBounds (265, 335, 255, 25);
        necessitiesLabel.setBounds (140, 360, 100, 25);
        necessitiesField.setBounds (265, 360, 255, 25);
        capacityLabel.setBounds (145, 425, 100, 25);
        capacityField.setBounds (265, 425, 50, 25);
        semisterLabel.setBounds (145, 450, 100, 25);
        semisterField.setBounds (265, 450, 50, 25);
        groupLabel.setBounds (145, 475, 100, 25);
        groupField.setBounds (265, 475, 50, 25);
        assistantsLabel.setBounds (140, 385, 100, 25);
        assistantsField.setBounds (265, 385, 255, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new AddCourse());
        frame.pack();
        frame.setVisible (true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
       // Edu edu = Edu.getInstance();
      //  User user = edu.getUserLoggedIn();
        String command = e.getActionCommand();

        if(e.getActionCommand().equals("add")){
            try {
                Controller.getInstance().getLibrary().refreshPublicInfo();

                LinkedList<Long> assistants = new LinkedList<>();
                LinkedList<Long> prerequisites = new LinkedList<>();
                LinkedList<Long> necessities = new LinkedList<>();

                if(!Objects.equals(assistantsField.getText(), ""))
                    for (String assistantId: assistantsField.getText().split(",")) {
                    User student = Controller.getInstance().getOfflineDataNoUpdate().
                            getUserById(Long.parseLong(assistantId));

                    if(!(student instanceof Student)){
                        frame.setSysMessageText("invalid assistant id");
                        return;
                    }
                    assistants.add(student.getIdNumber());
                }

                if(!Objects.equals(prerequisitesField.getText(), ""))
                    for (String prerequisite: prerequisitesField.getText().split(",")) {


                    prerequisites.add(Long.parseLong(prerequisite));
                }

                if(!Objects.equals(necessitiesField.getText(), ""))
                    for (String necessitie: necessitiesField.getText().split(",")) {


                        necessities.add(Long.parseLong(necessitie));
                }

                ServerResponse response = Controller.getInstance().getLibrary().addCourse(nameField.getText(),
                        Long.parseLong(masterField.getText()), Integer.parseInt(unitsField.getText()),
                        Long.parseLong(courseIdField.getText()),
                        Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId()
                        , TimeInWeek.makeTimeFromString(timeInWeekField.getText()),
                        DateTime.toDateTime(examTimeField.getText()), assistants, prerequisites,
                        necessities, sectionField.getText(), Integer.parseInt(semisterField.getText()),
                        Integer.parseInt(capacityField.getText()), Integer.parseInt(groupField.getText()));

                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex){
                Logger.logException(this, "actionPerformed", "inputException");
                frame.setSysMessageText("invalid input");
            }
        }
    }
}
