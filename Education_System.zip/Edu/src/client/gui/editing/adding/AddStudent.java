package client.gui.editing.adding;

import client.controller.Controller;
import client.controller.Loop;
import client.gui.MainPanel;
import communication.server.ServerResponse;
import server.time.DateTime;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AddStudent extends JPanel implements ActionListener {
    private JLabel nameLabel;
    private JLabel nationalIdLabel;
    private JLabel studentNumberLabel;
    private JLabel phoneNoLabel;
    private JLabel emailLabel;
    private JLabel collegeLabel;
    private JLabel supervisorLabel;
    private JLabel entryYearLabel;
    private JLabel eduLevelLabel;
    private JLabel birthdayLabel;

    private JTextField emailField;
    private JTextField phoneNoField;
    private JTextField nameField;
    private JTextField nationalIdField;
    private JTextField studentNoField;
    private JTextField supervisorField;
    private JTextField entryYearField;
    private JTextField levelField;
    private JTextField birthdayField;


    private JLabel registerTimeLabel;
    private JTextField registerTimeField;

    private JButton registerButton;

    public AddStudent() {
        Loop.getInstance().killLoop();

        Controller.getInstance().getLibrary().refreshPublicInfo();

        //construct components
        nameLabel = new JLabel ("Full Name:");
        nationalIdLabel = new JLabel ("National ID: ");
        studentNumberLabel = new JLabel ("Student Number: ");
        phoneNoLabel = new JLabel ("Phone No. :");
        emailLabel = new JLabel ("Email:");
        collegeLabel = new JLabel ("College: " + Controller.getInstance().getOfflineData().getCollegeById
                (Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId()).getName());
        supervisorLabel = new JLabel ("Supervisor ID:");
        entryYearLabel = new JLabel ("Entry Year:");
        eduLevelLabel = new JLabel ("Educational Level:");
        emailField = new JTextField (5);
        phoneNoField = new JTextField (5);
        nameField = new JTextField (5);
        nationalIdField = new JTextField (5);
        studentNoField = new JTextField (5);
        supervisorField = new JTextField (5);
        entryYearField = new JTextField (5);
        levelField = new JTextField (5);
        registerButton = new JButton ("Register");
        registerButton.addActionListener(this);
        registerButton.setActionCommand("register");

        birthdayLabel = new JLabel ("BirthDay:");
        birthdayField = new JTextField (5);

        registerTimeLabel = new JLabel ("Registering time:");
        registerTimeField = new JTextField (5);



        //set components properties
        emailField.setToolTipText ("Enter new email then press 'Edit profile'");
        phoneNoField.setToolTipText ("Enter new phone number then press 'Edit profile'");
        nationalIdField.setToolTipText ("It should not be duplicate");
        studentNoField.setToolTipText ("It should not be duplicate");
        supervisorField.setToolTipText ("Enter the supervisor ID");
        levelField.setToolTipText ("Enter student educational level(masters, phd or bachelor)");
        birthdayField.setToolTipText("Enter date in standard protocol(YY/MM/DD)");
        registerTimeField.setToolTipText("Enter date in standard protocol(YY/MM/DD)");

        //adjust size and set layout
        setPreferredSize (new Dimension (600, 430));
        setLayout (null);

        //add components
        add (nameLabel);
        add (nationalIdLabel);
        add (studentNumberLabel);
        add (phoneNoLabel);
        add (emailLabel);
        add (collegeLabel);
        add (supervisorLabel);
        add (entryYearLabel);
        add (eduLevelLabel);
        add (emailField);
        add (phoneNoField);
        add (nameField);
        add (nationalIdField);
        add (studentNoField);
        add (supervisorField);
        add (entryYearField);
        add (levelField);
        add (registerButton);
        add (birthdayLabel);
        add (birthdayField);
        add (registerTimeLabel);
        add (registerTimeField);

        //set component bounds (only needed by Absolute Positioning)
        nameLabel.setBounds (140, 55, 65, 25);
        nationalIdLabel.setBounds (140, 80, 70, 25);
        studentNumberLabel.setBounds (140, 105, 100, 25);
        phoneNoLabel.setBounds (140, 130, 70, 25);
        emailLabel.setBounds (140, 155, 40, 25);
        collegeLabel.setBounds (140, 180, 290, 25);
        supervisorLabel.setBounds (140, 205, 85, 25);
        entryYearLabel.setBounds (140, 230, 65, 25);
        eduLevelLabel.setBounds (140, 255, 105, 25);
        birthdayLabel.setBounds (140, 280, 105, 25);
        registerTimeLabel.setBounds (140, 305, 105, 25);

        emailField.setBounds (265, 155, 250, 25);
        phoneNoField.setBounds (265, 130, 250, 25);
        nameField.setBounds (265, 55, 100, 25);
        nationalIdField.setBounds (265, 80, 100, 25);
        studentNoField.setBounds (265, 105, 100, 25);
        supervisorField.setBounds (265, 205, 100, 25);
        entryYearField.setBounds (265, 230, 100, 25);
        levelField.setBounds (265, 255, 100, 25);
        birthdayField.setBounds (265, 280, 100, 25);
        registerTimeField.setBounds (265, 305, 100, 25);

        registerButton.setBounds (415, 315, 85, 28);
    }


    public static void main (String[] args) {
        MainPanel frame = MainPanel.getInstance();
        frame.addComponent(new AddStudent());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        MainPanel frame = MainPanel.getInstance();
     //   Edu edu = Edu.getInstance();
     //   User user = edu.getUserLoggedIn();
        String command = e.getActionCommand();

        if(e.getActionCommand().equals("register")){
            try {
                String maghta = levelField.getText().toLowerCase();
                boolean masters;
                boolean phd;
                switch (maghta){
                    case "masters":
                        masters = true;
                        phd = false;
                        break;

                    case "phd":
                        phd = true;
                        masters = false;
                        break;

                    case "bachelor":
                        phd = false;
                        masters = false;
                        break;

                    default:
                        frame.setSysMessageText("invalid educational level");
                        return;
                }

                ServerResponse response = Controller.getInstance().getLibrary().addStudent(nameField.getText(), studentNoField.getText(), nationalIdField.getText(),
                        Controller.getInstance().getLibrary().refreshPublicInfo().getCollegeId(), Long.parseLong(studentNoField.getText()),
                        DateTime.toDateTime(birthdayField.getText() + " 00:00:00"), Long.parseLong(supervisorField.getText()),
                        true, "active studying at university", masters, phd,
                        Integer.parseInt(entryYearField.getText()),DateTime.toDateTime(registerTimeField.getText()));

                frame.setSysMessageText(response.getServerMessage());

            } catch (Exception ex){
                frame.setSysMessageText("invalid inputs");

            }
        }
    }
}

