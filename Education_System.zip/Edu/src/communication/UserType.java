package communication;

public enum UserType {
    STUDENT, MASTER, DEAN, CHANCELLOR, MRMOHSENI, ADMIN
}
