package communication.client;

public enum ClientRequestType {
    LOGIN, LOGOUT, MainMenu, ChangePassword, ChangeEmailAndPhone,
    DeleteMaster, EditMaster, AddMaster, EditCourse, AddCourse,
    DeleteCourse, AddStudent, EditMark, RegisterCourse,
    ResponseProtest, MakeProtest, EditStudent,
    DetermineRequestResult, RegisterNewRequest, Reconnect, GetPicture,
    SendMessage, SendMedia, GetMedia, MarkOrUnmarkCourse, EnrollCourse,
    ChangeCourseGroup, ChangeEnrollTime, NewContent, AddSubmission,
    DownloadHomework, AddHomework, MarkSubmission, GetSubmissionFile, AddItem, EditItem, AddStudentToCourseware, DownloadItem, Purge,
}
