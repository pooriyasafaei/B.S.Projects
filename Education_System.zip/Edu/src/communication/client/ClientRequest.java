package communication.client;

import communication.PageType;

import java.util.HashMap;
import java.util.Map;

public class ClientRequest {
    private Map<String, Object> data = new HashMap<>();
    private ClientRequestType type;
    private String auth;
    private PageType page;

    public ClientRequest(){}

    public ClientRequest(ClientRequestType type, String auth){
        this.type = type;
        this.auth = auth;
    }

    public void addData(String key, Object data){
        this.data.put(key, data);
    }

    public Object readData(String key){
        return data.get(key);
    }


    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public ClientRequestType getType() {
        return type;
    }

    public void setType(ClientRequestType type) {
        this.type = type;
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth;
    }

    public PageType getPage() {
        return page;
    }

    public void setPage(PageType page) {
        this.page = page;
    }
}
