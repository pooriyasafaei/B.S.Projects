package communication.server;

import communication.PageType;

import java.util.HashMap;
import java.util.Map;

public class ServerResponse {

    private Map<String, Object> data = new HashMap<>();
    private ServerResponseType type;
    private String serverMessage;
    private boolean flag;
    private boolean ping = false;
    private PageType page;

    public ServerResponse(){}

    public ServerResponse(ServerResponseType type){
        this.type = type;
    }

    public void addData(String key, Object data){
        this.data.put(key, data);
    }

    public Object readData(String type){
        return data.get(type);
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public ServerResponseType getType() {
        return type;
    }

    public void setType(ServerResponseType type) {
        this.type = type;
    }

    public String getServerMessage() {
        return serverMessage;
    }

    public void setServerMessage(String serverMessage) {
        this.serverMessage = serverMessage;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public boolean isPing() {
        return ping;
    }

    public void setPing(boolean ping) {
        this.ping = ping;
    }

    public PageType getPage() {
        return page;
    }

    public void setPage(PageType page) {
        this.page = page;
    }
}
