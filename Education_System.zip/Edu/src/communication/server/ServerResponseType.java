package communication.server;

public enum ServerResponseType {
    AUTH, Failed, Done, Login, PageData, Action
}
