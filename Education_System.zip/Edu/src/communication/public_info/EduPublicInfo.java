package communication.public_info;

import server.logic.colleges.College;
import server.logic.courses.Course;
import server.logic.courses.cw.Content;
import server.logic.courses.cw.EducationalContent;
import server.logic.courses.cw.Homework;
import server.logic.main_data.Edu;
import server.logic.messenger.TextBox;
import server.logic.request.Request;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EduPublicInfo {

    private LinkedList<College> colleges = new LinkedList<>();
    private LinkedList<Course> courses = new LinkedList<>();
    private LinkedList<Student> students = new LinkedList<>();
    private LinkedList<Master> masters = new LinkedList<>();

    private LinkedList<Integer> collagesNumber = new LinkedList<>();
    private LinkedList<Long> studentsId = new LinkedList<>();
    private LinkedList<Long> mastersId = new LinkedList<>();
    private LinkedList<Long> coursesId = new LinkedList<>();

    private String message = "";
    private boolean flag;

    public static EduPublicInfo makePublicInfoCopy(){
        EduPublicInfo info = new EduPublicInfo();
        info.colleges = (LinkedList<College>) Edu.getColleges().clone();
        info.students = (LinkedList<Student>) Edu.getInstance().getStudentsList("","","").clone();
        info.masters = (LinkedList<Master>) Edu.getInstance().getMastersList("","","").clone();
        info.courses = (LinkedList<Course>) Edu.getCourses().clone();

        info.collagesNumber = (LinkedList<Integer>) Edu.getInstance().getCollagesNumber().clone();
        info.studentsId = (LinkedList<Long>) Edu.getInstance().getStudentsId().clone();
        info.mastersId = (LinkedList<Long>) Edu.getInstance().getMastersId().clone();
        info.coursesId = (LinkedList<Long>) Edu.getInstance().getCoursesId().clone();

        return info;
    }

    public College getCollegeById(int collegeId) {
        for (College college: colleges)
            if (college.getNumber() == collegeId) {
                flag = true;
                return college;
            }

        flag = false;
        message = "College with this id number doesn't exist.";
        return null;
    }

    public LinkedList<Master> getMastersList(String collegeFilter, String nameFilter, String degreeFilter){
        LinkedList<Master> result = new LinkedList<>();
        for(Master user: masters){
            if((user != null) && (user.getIdNumber() > 0)) result.add((Master) user);
        }

        if(collegeFilter != null && !collegeFilter.equals("")){

            result.removeIf(master -> !getCollegeById(master.getCollegeId()).getName()
                    .toLowerCase().contains(collegeFilter.toLowerCase()));

        }

        if(nameFilter != null && !nameFilter.equals("")){
            result.removeIf(master -> !master.getName().toLowerCase().contains(nameFilter.toLowerCase()));
        }

        if(degreeFilter != null && !degreeFilter.equals("")){
            result.removeIf(master -> !master.getMasterDegree().toLowerCase().contains(degreeFilter.toLowerCase()));
        }

        return result;
    }

    public LinkedList<Course> getCoursesList(String collegeFilter, String courseIdFilter, String unitsFilter){
        LinkedList<Course> result = new LinkedList<>();
        boolean t = result.addAll(courses);

        try {
            if (collegeFilter != null && !collegeFilter.equals("")) {
                result.removeIf(course -> !getCollegeById(course.getCollegeId())
                        .getName().toLowerCase().contains(collegeFilter.toLowerCase()));
            }

            if (courseIdFilter != null && !courseIdFilter.equals("")) {
                result.removeIf(course -> !String.valueOf(course.getId()).toLowerCase()
                        .contains(courseIdFilter.toLowerCase()));
            }

            if (unitsFilter != null && !unitsFilter.equals("")) {
                result.removeIf(course -> !String.valueOf(course.getUnits()).toLowerCase()
                        .contains(unitsFilter.toLowerCase()));
            }
        } catch (Exception e){
            result = new LinkedList<>();
        }

        return result;
    }

    public LinkedList<Student> getStudentsList(String studentIdFilter, String entryYear, String collegeFilter, String section){
        LinkedList<Student> result = new LinkedList<>();
        for(Student student: students){
            if( (student.getIdNumber() > 0)) result.add(student);
        }

        if(collegeFilter != null && !collegeFilter.equals("")){

            result.removeIf(student -> !getCollegeById(student.getCollegeId()).getName()
                    .toLowerCase().contains(collegeFilter.toLowerCase()));

        }

        if(entryYear != null && !entryYear.equals("")){
            result.removeIf(student -> !String.valueOf(student.getEnteringYear()).contains(entryYear));
        }

        if(studentIdFilter != null && !studentIdFilter.equals("")){
            result.removeIf(student -> !String.valueOf(student.getIdNumber()).
                    toLowerCase().contains(studentIdFilter.toLowerCase()));
        }

        if(section != null && !section.equals("")){
            result.removeIf(student -> {
                if(student.isMasters()) return !section.equalsIgnoreCase("masters");
                if(student.isPhd()) return !section.equalsIgnoreCase("phd");
                return !section.equalsIgnoreCase("bachelor");
            });
        }

        result.sort(this::compareStudents);


        return result;
    }

    public int compareStudents(Student s1, Student s2){
        if(s1.getEnteringYear() > s2.getEnteringYear()) return 1;
        return -1;
    }

    public LinkedList<Long> getStudentForEnrollTime(int entryYear, String section){
        LinkedList<Student> result = new LinkedList<>();
        for(Student student: students){
            if( (student.getIdNumber() > 0)) result.add(student);
        }

        if(entryYear != 0){

            result.removeIf(student -> student.getEnteringYear() != entryYear);

        }

        if(section != null && !section.equals("")){
            result.removeIf(student -> {
                if(student.isMasters()) return !section.equalsIgnoreCase("masters");
                if(student.isPhd()) return !section.equalsIgnoreCase("phd");
                return !section.equalsIgnoreCase("bachelor");
            });
        }

        LinkedList<Long> finalResult = new LinkedList<>();
        for (Student student: result) {
            finalResult.add(student.getIdNumber());
        }

        return finalResult;
    }

    public LinkedList<Object> sortExamAndDeadlines(User user, Course isCourse){
        LinkedList<Object> result = new LinkedList<>();
        if(isCourse != null) result.add(isCourse);

        if(user instanceof Student student){
            if(isCourse == null) {
                for (Course course : getOnGoingCoursesList(student.getIdNumber())) {
                    result.add(course);
                    result.addAll(course.getCourseware().getHomeworks());
                }

                for (Course course : convertToCourse(new LinkedList<>(student.getAssistantCourses()))) {
                    result.add(course);
                    result.addAll(course.getCourseware().getHomeworks());
                }
            }

            else result.addAll(isCourse.getCourseware().getHomeworks());
        }

        if(user instanceof Master master){
            if(isCourse == null)
            for (Course course: getOnGoingCoursesList(master.getIdNumber())) {
                result.add(course);
                result.addAll(course.getCourseware().getHomeworks());
            }

            else result.addAll(isCourse.getCourseware().getHomeworks());
        }

        result.sort(new Comparator<Object>() {
            @Override
            public int compare(final Object object1, final Object object2) {
                return compareTime(object1, object2);
            }
        });

        return result;
    }

    public <T> LinkedList<T> sortByTime(LinkedList<T> list){
        list.sort(new Comparator<Object>() {
            @Override
            public int compare(final Object object1, final Object object2) {
                return compareTime(object1, object2);
            }
        });
        return list;
    }

    public int compareTime(Object object1, Object object2){
        DateTime time1 = object1 instanceof Homework homework ? homework.getDeadline() :
                object1 instanceof EducationalContent educationalContent? educationalContent.getLastChange() :
                object1 instanceof Content content ? content.getTime() :
                        ((Course)object1).getExamTime();

        DateTime time2 = object2 instanceof Homework homework ? homework.getDeadline() :
                object2 instanceof EducationalContent educationalContent? educationalContent.getLastChange() :
                        object2 instanceof Content content ? content.getTime() :
                                ((Course)object2).getExamTime();

        if(DateTime.isFirstLaterThanSecond(time1, time2)) return 1;
        return -1;
    }

    public LinkedList<Request> getMessagesSorted(User user){
        LinkedList<Request> result = new LinkedList<>(user.getRequests());
        result.addAll(user.getMessages());

        result.sort(this::compareMessages);

        return result;
    }

    public int compareMessages(Request r1, Request r2){
        if(DateTime.isFirstLaterThanSecond(r1.getRegisteredTime(), r2.getRegisteredTime())) return -1;
        return 1;
    }

    public LinkedList<User> getRelatedUsers(long id){
        LinkedList<User> results = new LinkedList<>();

        if(id == 1){
            results.addAll(students);
            results.addAll(masters);
            return results;
        }

        if(id == 12345678){
            results.addAll(students);
            return results;
        }

        User user = getUserById(id);
        if(user instanceof Student){
            results.addAll(getStudentsList("",
                    String.valueOf(((Student)user).getEnteringYear()),
                    getCollegeById(user.getCollegeId()).getName(), ""));

            Master supervisor = (Master) getUserById(((Student) user).getSupervisorId());
            if(supervisor != null) results.add(supervisor);
        }

        if(user instanceof Master master){
            if(master.isDean() || master.isChancellor()){
                results.addAll(getStudentsList("","",getCollegeById(master.getCollegeId()).getName(),
                        ""));
            }
            else for (long studentId: ((Master)user).getStudentsSupervisedId()){
                Student student = (Student) getUserById(studentId);
                if(student != null) results.add(student);
            }
        }

        for (TextBox textBox: user.getChats()) {
            if(!results.contains(getUserById(textBox.getContactId()))) results.add(getUserById(textBox.getContactId()));
        }
        return results;
    }

    public LinkedList<Course> getCourseByAbsoluteId(long absoluteId, LinkedList<Course> courses){
        LinkedList<Course> result = new LinkedList<>();

        for (Course course: courses) {
            if(course.getAbsoluteId() == absoluteId)
                result.add(course);
        }

        return result;
    }

    public LinkedList<Course> convertToCourse(LinkedList<Long> coursesId){
        LinkedList<Course> courses = new LinkedList<>();
        for (long id: coursesId) {
            Course course = getCourseById(id);
            if(course != null)
                courses.add(course);
        }

        return courses;
    }

    public LinkedList<Course> sortByName(LinkedList<Course> courses){
        if(courses.size() < 1) return courses;

        courses.sort(new Comparator<Course>() {
            @Override
            public int compare(final Course object1, final Course object2) {
                return object1.getName().toLowerCase().compareTo(object2.getName().toLowerCase());
            }
        });

        return courses;
    }

    public LinkedList<Course> sortBySection(LinkedList<Course> courses){
        if(courses.size() < 1) return courses;

        courses.sort(new Comparator<Course>() {
            @Override
            public int compare(final Course object1, final Course object2) {
                return object1.getSection().toLowerCase().compareTo(object2.getSection().toLowerCase());
            }
        });

        return courses;
    }

    public boolean canEnroll(long studentId, long courseId){
        Course course = getCourseById(courseId);
        Student student = (Student) getUserById(studentId);

        if(student == null || course == null) return false;

        for (Long id: course.getPrerequisites()) {

            LinkedList<Course> possibleCourses = getCourseByAbsoluteId(id, courses);
            boolean t = false;

            for (Course possiblePassed: possibleCourses) {
                if(possiblePassed.isStudentPassed(studentId)){
                    t = true;
                    break;
                }
            }

            if(!t) return false;
        }

        return true;
    }

    public LinkedList<Course> getRecommendedCourses(long idNumber) {
        LinkedList<Course> result = new LinkedList<>();

        Student student = (Student) getUserById(idNumber);
        for (Course course: courses) {
            if(course == null) continue;

            if(canEnroll(student.getIdNumber(), course.getId()) && areFromSameSection(student.getIdNumber(), course.getId()) &&
                    course.hasCapacity())
                result.add(course);

        }
        return result;
    }

    public Course studentHasCourse(long studentId, long courseAbsoluteId){
        Student student = (Student) getUserById(studentId);

        if(student == null) return null;

        for (long id: student.getTemporaryEnrolledCourses()){
            Course course = getCourseById(id);
            if(course == null) continue;

            if(course.getAbsoluteId() == courseAbsoluteId) return course;
        }

        return null;
    }

    public boolean areFromSameSection(long studentId, long courseId){
        Student student = (Student) getUserById(studentId);
        Course course = getCourseById(courseId);
        if(course == null || student == null) return false;

        if(student.isPhd() && course.getSection().equalsIgnoreCase("phd")) return true;
        if(student.isMasters() && course.getSection().equalsIgnoreCase("masters")) return true;
        return !student.isPhd() && !student.isMasters() && course.getSection().equalsIgnoreCase("bachelor");
    }

    public Course getCourseById(long courseId){
        for (Course course: courses)
            if (course.getId() == courseId) {
                flag = true;
                return course;
            }

        flag = false;
        message = "Course with this id number doesn't exist.";
        return null;
    }

    public User getUserById(long id){
        for (Student user: students)
            if (user.getIdNumber() == id) {
                flag = true;
                return user;
            }

        for (Master user: masters)
            if (user.getIdNumber() == id) {
                flag = true;
                return user;
            }

        flag = false;
        message = "User with this id number doesn't exist.";
        return null;
    }

    public  LinkedList<User> getUsers() {
         Stream<User> combinedStream = Stream.concat(students.stream(), masters.stream());
         return combinedStream.collect(Collectors.toCollection(LinkedList::new));
    }

    public  LinkedList<College> getColleges() {
        return colleges;
    }

    public  LinkedList<Course> getCourses() {
        return courses;
    }

    public boolean containsId(LinkedList<User> users, long id){
        for (User user: users) {
            if(user.getIdNumber() == id) return true;
        }

        return false;
    }

    public LinkedList<Integer> getCollagesNumber() {
        return collagesNumber;
    }

    public void setCollagesNumber(LinkedList<Integer> collagesNumber) {
        this.collagesNumber = collagesNumber;
    }

    public LinkedList<Long> getStudentsId() {
        return studentsId;
    }

    public void setStudentsId(LinkedList<Long> studentsId) {
        this.studentsId = studentsId;
    }

    public LinkedList<Long> getMastersId() {
        return mastersId;
    }

    public void setMastersId(LinkedList<Long> mastersId) {
        this.mastersId = mastersId;
    }

    public LinkedList<Long> getCoursesId() {
        return coursesId;
    }

    public void setCoursesId(LinkedList<Long> coursesId) {
        this.coursesId = coursesId;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setColleges(LinkedList<College> colleges) {
        this.colleges = colleges;
    }

    public void setCourses(LinkedList<Course> courses) {
        this.courses = courses;
    }

    public LinkedList<Course> getOnGoingCoursesList(Long userId){
        LinkedList<Course> result = new LinkedList<>();
        User user = getUserById(userId);
        if(user instanceof Student){
            for (long id : ((Student)user).getCoursesId()) {
                Course course = getCourseById(id);
                if (course == null) continue;
                if (!course.isFinalRegistered())
                    result.add(course);
            }
        }

        if(user instanceof Master){
            for (long id : ((Master)user).getCoursesId()) {
                Course course = getCourseById(id);
                if (course == null) continue;
                if (!course.isFinalRegistered())
                    result.add(course);
            }
        }

        return result;
    }

    public LinkedList<Student> getStudents() {
        return students;
    }

    public void setStudents(LinkedList<Student> students) {
        this.students = students;
    }

    public LinkedList<Master> getMasters() {
        return masters;
    }

    public void setMasters(LinkedList<Master> masters) {
        this.masters = masters;
    }
}
