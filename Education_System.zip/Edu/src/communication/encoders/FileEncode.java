package communication.encoders;

import java.io.*;
import java.util.Base64;

public class FileEncode {

    private String fileName;
    private String encoded;

    public FileEncode(){

    }

    public FileEncode(String path){
        File f = new File(path);
        this.fileName = f.getAbsolutePath().substring(f.getAbsolutePath().lastIndexOf("\\")+1);
        this.encoded = encodeFileToString(new File(path));
    }

    public static String encodeFileToString(File file){
        String encodedFile = null;
        try {
            FileInputStream fileInputStreamReader = new FileInputStream(file);
            byte[] bytes = new byte[(int)file.length()];
            fileInputStreamReader.read(bytes);


            encodedFile = (Base64.getEncoder().encodeToString(bytes));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return encodedFile;
    }

    public static void decodeStringToFile(String encoded, String path){
        try {
            File file = new File(path);
            file = new File(file.getParentFile().getPath());
            file.mkdirs();

            byte[] bytes = Base64.getDecoder().decode(encoded);
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            fileOutputStream.write(bytes);
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getEncoded() {
        return encoded;
    }

    public void setEncoded(String encoded) {
        this.encoded = encoded;
    }


}
