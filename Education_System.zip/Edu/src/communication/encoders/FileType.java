package communication.encoders;

public enum FileType {
    PDF, JPG, MP3, MP4
}
