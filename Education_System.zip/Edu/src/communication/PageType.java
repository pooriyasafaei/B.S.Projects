package communication;

public enum PageType {
    LoginPage, MasterMainMenuPage, StudentMainMenuPage
}
