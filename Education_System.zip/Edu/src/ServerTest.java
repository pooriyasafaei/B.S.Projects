import server.controller.ServerRunner;

import java.io.IOException;

public class ServerTest {
    public static void main(String[] args) throws IOException {
        ServerRunner.start();
    }
}
