package server.logic.colleges;

import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.users.Master;

import java.util.LinkedList;

public class College {

    private int number;
    private String name;
    private long chancellorId = -1;
    private long deanId = -1;

    private LinkedList<Long> mastersId = new LinkedList<>();
    private LinkedList<Long> studentsId = new LinkedList<>();
    private LinkedList<Long> coursesId = new LinkedList<>();

    public College(int number, String name){
        this.number = number;
        this.name = name;

        Edu.getInstance().getCollagesNumber().add(number);
        Edu.getColleges().add(this);

        DataAccess.saveCore();
        DataAccess.dumpCollage(this);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
        DataAccess.dumpCollage(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        DataAccess.dumpCollage(this);

    }

    public long getChancellorId() {
        return chancellorId;
    }

    public void setChancellorId(long chancellorId) {
            Master current = (Master) (Edu.getInstance().getUserById(this.chancellorId));
            current.setChancellor(false);

        this.chancellorId = chancellorId;
        DataAccess.dumpCollage(this);
    }

    public long getDeanId() {
        return deanId;
    }

    public void setDeanId(long deanId) {
        if(this.deanId > 0){
            Master current = (Master) (Edu.getInstance().getUserById(this.deanId));
            if (current != null) current.setDean(false);
            DataAccess.dumpCollage(this);
        }

        this.deanId = deanId;
        DataAccess.dumpCollage(this);
    }

    public LinkedList<Long> getMastersId() {
        return mastersId;
    }

    public void setMastersId(LinkedList<Long> mastersId) {
        this.mastersId = mastersId;
        DataAccess.dumpCollage(this);
    }

    public LinkedList<Long> getStudentsId() {
        return studentsId;
    }

    public void setStudentsId(LinkedList<Long> studentsId) {
        this.studentsId = studentsId;
        DataAccess.dumpCollage(this);

    }

    public LinkedList<Long> getCoursesId() {
        return coursesId;
    }

    public void setCoursesId(LinkedList<Long> coursesId) {
        this.coursesId = coursesId;
        DataAccess.dumpCollage(this);

    }
}
