package server.logic.request;

public enum RequestTypes {
    Recommendation, StudyCertificate, Minor,
    StudyQuit, Dorm, ChatRequest, EnrollCourse, SystemMessage, ThesisDefenceTime
}
