package server.logic.request;

import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.messenger.TextBox;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;

import java.util.Random;

public class Request {
    private final long requestId;

    private RequestTypes type;
    private String text;
    private String responseText;

    private long applicantId;
    private long receiverId;
    private long secondReceiverId;

    private boolean reviewed;
    private boolean secondReceiverReviewed;

    private boolean accepted;
    private boolean secondReceiverAccepted;

    private final DateTime registeredTime = new DateTime();

    public Request(RequestTypes type, String text, long applicantId) {
        this.type = type;
        this.text = text;
        this.applicantId = applicantId;

        this.receiverId = -1;
        this.secondReceiverId = -1;

        this.reviewed = false;
        this.accepted = false;

        this.secondReceiverReviewed = true;
        this.secondReceiverAccepted = true;

        Random r = new Random();
        this.requestId = r.nextLong(1000000L);

    }

    public Request(RequestTypes type, String text, long applicantId, long receiverId) {
        this.type = type;
        this.text = text;
        this.applicantId = applicantId;

        this.receiverId = receiverId;
        this.secondReceiverId = -1;

        this.reviewed = false;
        this.accepted = false;

        this.secondReceiverReviewed = true;
        this.secondReceiverAccepted = true;

        Random r = new Random();
        this.requestId = r.nextLong(1000000L);
    }

    public Request(RequestTypes type, String text, long applicantId, long receiverId, long secondReceiverId) {
        this.type = type;
        this.text = text;
        this.applicantId = applicantId;

        this.receiverId = receiverId;
        this.secondReceiverId = secondReceiverId;

        this.reviewed = false;
        this.accepted = false;

        this.secondReceiverReviewed = false;
        this.secondReceiverAccepted = false;

        Random r = new Random();
        this.requestId = r.nextLong(1000000L);
    }

    public boolean isAnswered(){
        if(reviewed && secondReceiverReviewed) return true;
        if(reviewed && !accepted) return true;
        return secondReceiverReviewed && !secondReceiverAccepted;
    }

    public String finalResult(){
        if(!isAnswered()) return "pending";
        return accepted && secondReceiverAccepted ? "accepted" : "rejected";
    }

    public static void makeRecommendationReq(long applicantId, long receiverId, String text) {
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));
        Master master = (Master) (Edu.getInstance().getUserById(receiverId));
        Request request = new Request(RequestTypes.Recommendation,"I have a request for having a recommendation from you " +
                "an I had this courses passed/TA in my resume: " + text, applicantId, receiverId);

        student.getRequests().add(request);
        master.getRequests().add(request);
        Logger.logEvent(request, "makeRecommendationReq", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(student);
        DataAccess.dumpUser(master);
    }

    public static void makeStudyCertificate(long applicantId){
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));
        String text = "It is certified that Mr. / Mrs. " + student.getName() +
                " with student number " + student.getIdNumber() +
                " is studying in the college field " + Edu.getInstance().getCollegeById(student.getCollegeId()).getName() +
                " at Sharif University of technology. " +
                "This certificate is valid from: " + DateTime.getDateTime() + " to two weeks after it.";
        Request request = new Request(RequestTypes.StudyCertificate, text, applicantId);
        request.reviewed = true;
        request.accepted = true;

        student.getRequests().add(request);
        Logger.logEvent(request, "makeStudyCertificate", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(student);
    }

    public static void makeThesisDefenceTime(long applicantId, String message){
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));

        String text = "Request for thesis defense client.time: ";

        Request request = new Request(RequestTypes.ThesisDefenceTime,text + message, applicantId);
        request.setResponseText("you can defence your thesis at: " + DateTime.getDateTime() + " or a week after" +
                " it at the same client.time.");
        request.reviewed = true;
        request.accepted = true;

        Logger.logEvent(request, "makeThesisDefenceTime", "request added",
                new Object[]{request}, LogType.actionDone);
        student.getRequests().add(request);
        DataAccess.dumpUser(student);
    }

    public static void makeMinor(long applicantId, long destChancellorId, String message){
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));
        Master chancellor = (Master) (Edu.getInstance().getUserById(destChancellorId));

        String text = "Mr./Mrs. "+ student.getName() +" with the student number "+ student.getIdNumber()+
                " has a minor request from college "+ Edu.getInstance().getCollegeById(student.getCollegeId()).getName()+
                " to college " + Edu.getInstance().getCollegeById(chancellor.getCollegeId()).getName() +". The student has ";

        if(student.getAverageGrade(true) >= 17)
            text += "the grade point average condition Therefore, the request was" +
                    " sent to the education deputies of the school of origin and destination.";

        else       text += "not the grade point average condition Therefore,"  +
                " the result of request is disagreement.";

        Request request = new Request(RequestTypes.Minor, text + "\r\nDetails from student: " + message, applicantId,
                 destChancellorId, Edu.getInstance().getCollegeById(student.getCollegeId()).getChancellorId());

        if(student.getAverageGrade(true) >= 17)
        {
            request.setReviewed(false);
            request.setSecondReceiverReviewed(false);
        }

        student.getRequests().add(request);
        chancellor.getRequests().add(request);

        Master userById = (Master) (Edu.getInstance().getUserById(Edu.getInstance()
                .getCollegeById(student.getCollegeId()).getChancellorId()));


        userById.getRequests().add(request);
        Logger.logEvent(request, "makeMinor", "request added",
                new Object[]{request}, LogType.actionDone);

        DataAccess.dumpUser(student);
        DataAccess.dumpUser(chancellor);
        DataAccess.dumpUser(userById);
    }

    public static void makeStudyQuit(long applicantId){
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));
        Master chancellor = (Master) (Edu.getInstance().getUserById(Edu.getInstance()
                .getCollegeById(student.getCollegeId()).getChancellorId()));

                String text = "Mr. / Mrs. " + student.getName() +
                        " with student number " + student.getIdNumber() +
                        " that is studying in the college field " +
                        Edu.getInstance().getCollegeById(student.getCollegeId()).getName() +
                        " at Sharif University of technology wants to quit studying.";

        Request request = new Request(RequestTypes.StudyQuit, text, applicantId, chancellor.getIdNumber());

        student.getRequests().add(request);
        chancellor.getRequests().add(request);

        Logger.logEvent(request, "makeStudyQuit", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(student);
        DataAccess.dumpUser(chancellor);
    }

    public static void makeDorm(long applicantId, String message){
        Student student = (Student) (Edu.getInstance().getUserById(applicantId));
        String text = "Your request for a dorm was: ";
        Request request = new Request(RequestTypes.Dorm, text + message, applicantId);

        Random r = new Random();
        if(r.nextBoolean()) {
            text += " not accepted from the guild council.";
            request.setResponseText(text);
            request.accepted = false;
        } else {
            text += " accepted from the guild council.";
            request.setResponseText(text);
            request.accepted = true;
        }

        request.setReviewed(true);
        student.getRequests().add(request);

        Logger.logEvent(request, "makeDorm", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(student);
    }

    public static void chatRequest(long applicantId, long receiverId, String text) {
        User student =  (Edu.getInstance().getUserById(applicantId));
        User master =  (Edu.getInstance().getUserById(receiverId));
        Request request = new Request(RequestTypes.ChatRequest,student.getName() + " has request to start " +
                "a conversation with you in messenger.", applicantId, receiverId);

        master.getMessages().add(request);
        student.getMessages().add(request);

        Logger.logEvent(request, "makeRecommendationReq", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(master);
        DataAccess.dumpUser(student);

    }

    public static void enrollCourseRequest(long applicantId, long receiverId, String text) {

        User student =  (Edu.getInstance().getUserById(applicantId));
        User master =  (Edu.getInstance().getUserById(receiverId));

        Request request = new Request(RequestTypes.EnrollCourse,student.getName() + " has request to enroll to " +
                "course with id " + text + " because it wasn't possible fo them to take this course " +
                "in their enrollment time. \nCourseID: " + text, applicantId, receiverId);

        master.getMessages().add(request);
        student.getMessages().add(request);

        System.out.println(master.getMessages().get(0).text);

        System.out.println(master.getIdNumber());

        Logger.logEvent(request, "makeRecommendationReq", "request added",
                new Object[]{request}, LogType.actionDone);

        DataAccess.dumpUser(master);
        DataAccess.dumpUser(student);
    }

    public static void serverMessage(long receiverId, String text){

        User user =  (Edu.getInstance().getUserById(receiverId));
        Request request = new Request(RequestTypes.SystemMessage,  "Message from system: "+ text, receiverId);

        request.accepted = true;
        request.setReviewed(true);

        user.getMessages().add(request);

        Logger.logEvent(request, "makeRecommendationReq", "request added",
                new Object[]{request}, LogType.actionDone);
        DataAccess.dumpUser(user);
    }

    public void determineResult(long acceptorId, boolean isAccepted, String message){
        User student =  (Edu.getInstance().getUserById(applicantId));
        Request thisReq = student.getReq(requestId);

        User receiver1 =  Edu.getInstance().getUserById(this.receiverId);
        User receiver2 = null;

        Request receiver1Req = receiver1.getReq(requestId);
        Request receiver2Req = null;

        if(this.getSecondReceiverId() > 0) {
            receiver2 =  Edu.getInstance().getUserById(this.secondReceiverId);
        }

        if(receiver2 != null){
            receiver2Req = receiver2.getReq(requestId);
        }

        if(acceptorId == receiverId){
            reviewed = true;
            accepted = isAccepted;

            thisReq.setReviewed(true);
            thisReq.setAccepted(isAccepted);

            if(receiver2Req != null){
            receiver2Req.setReviewed(true);
            receiver2Req.setAccepted(isAccepted);
            }

        } else {
            secondReceiverReviewed = true;
            secondReceiverAccepted = isAccepted;

            thisReq.setSecondReceiverReviewed(true);
            thisReq.setSecondReceiverAccepted(isAccepted);

            receiver1Req.setSecondReceiverReviewed(true);
            receiver1Req.setSecondReceiverAccepted(isAccepted);

        }

        if(isAccepted && this.type == RequestTypes.StudyQuit){
            student.setActive(false);
            ((Student)student).setEduStatus("quit study");

        }

        this.responseText = message;


        if(this.type == RequestTypes.EnrollCourse){
            if(isAccepted){
                Course course = Edu.getInstance().getCourseById(Long.parseLong(this.text.split("CourseID: ")[1]));
                course.addStudent(student.getIdNumber(), false);
                this.responseText = "you added as Student to course with id " + course.getId() + ".";

            } else this.responseText = "Chancellor didn't accept your request for course.";

        }

        if(this.type == RequestTypes.ChatRequest){
            if(isAccepted ){
                TextBox senderBox = student.getChat(receiver1.getIdNumber());
                TextBox receiverBox = receiver1.getChat(student.getIdNumber());

                if (senderBox == null) {
                    student.addNewChat(new TextBox(student.getIdNumber(), receiver1.getIdNumber()));
                }
                if (receiverBox == null) {
                    receiver1.addNewChat
                            (new TextBox(receiver1.getIdNumber(), student.getIdNumber()));
                }
                this.responseText = "User accepted your chat request";

                DataAccess.dumpUser(student);
                DataAccess.dumpUser(receiver1);

            }else this.responseText = "User didnt accept your chat request";

        }

        serverMessage(student.getIdNumber(),  this.responseText);

        Logger.logEvent(thisReq, "determineResult", "request respond",
                new Object[]{thisReq, "Responder ID: " + acceptorId}, LogType.actionDone);



        DataAccess.dumpUser(student);
        DataAccess.dumpUser(Edu.getInstance().getUserById(acceptorId));
    }

    public long getRequestId() {
        return requestId;
    }

    public RequestTypes getType() {
        return type;
    }

    public void setType(RequestTypes type) {
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public long getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(long applicantId) {
        this.applicantId = applicantId;
    }

    public long getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(long receiverId) {
        this.receiverId = receiverId;
    }

    public long getSecondReceiverId() {
        return secondReceiverId;
    }

    public void setSecondReceiverId(long secondReceiverId) {
        this.secondReceiverId = secondReceiverId;
    }

    public boolean isReviewed() {
        return reviewed;
    }

    public void setReviewed(boolean reviewed) {
        this.reviewed = reviewed;
    }

    public boolean isSecondReceiverReviewed() {
        return secondReceiverReviewed;
    }

    public void setSecondReceiverReviewed(boolean secondReceiverReviewed) {
        this.secondReceiverReviewed = secondReceiverReviewed;
    }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public boolean isSecondReceiverAccepted() {
        return secondReceiverAccepted;
    }

    public void setSecondReceiverAccepted(boolean secondReceiverAccepted) {
        this.secondReceiverAccepted = secondReceiverAccepted;
    }

    public DateTime getRegisteredTime() {
        return registeredTime;
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }
}
