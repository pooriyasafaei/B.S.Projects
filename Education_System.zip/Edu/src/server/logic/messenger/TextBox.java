package server.logic.messenger;

import server.logic.main_data.Edu;
import server.time.DateTime;

import java.util.LinkedList;

public class TextBox {

    private long selfId;
    private long contactId;
    private DateTime lastMessageTime;
    private String lastMessage;

    private LinkedList<String> allChat = new LinkedList<String>();

    public TextBox(long selfId, long contactId) {
        this.selfId = selfId;
        this.contactId = contactId;

        this.allChat.add("   " + contactId + " accepted your chat request.\n  " + " '"
                + DateTime.getDateTimeNoSec(new DateTime()) + "'");

        lastMessageTime = new DateTime();
        lastMessage = getAllChat().getLast();
    }

    public void addMessage(boolean isSender, boolean isMedia, String message, DateTime dateTime){
        String text;
        if(isSender) text = "You";
        else text = Edu.getInstance().getUserById(contactId).getName();

        if(isMedia) text += " sent a media file with name " + "'" + message + "'";
        else text += ":\n " + message;

        text += "\n '" + DateTime.getDateTimeNoSec(dateTime) + "'";
        allChat.add(text);
        lastMessageTime = dateTime;
        lastMessage = text;
    }

    public long getSelfId() {
        return selfId;
    }

    public void setSelfId(long selfId) {
        this.selfId = selfId;
    }

    public long getContactId() {
        return contactId;
    }

    public void setContactId(long contactId) {
        this.contactId = contactId;
    }

    public DateTime getLastMessageTime() {
        return lastMessageTime;
    }

    public void setLastMessageTime(DateTime lastMessageTime) {
        this.lastMessageTime = lastMessageTime;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public LinkedList<String> getAllChat() {
        return allChat;
    }

    public void setAllChat(LinkedList<String> allChat) {
        this.allChat = allChat;
    }

    @Override
    public boolean equals(Object object){
        try {
            TextBox text = (TextBox) object;
            return (this.selfId == text.selfId && this.contactId == text.contactId && this.lastMessage.equals(text.lastMessage) &&
                    this.lastMessageTime.equals(text.lastMessageTime));
        }catch (Exception e){
            return false;
        }
    }
}
