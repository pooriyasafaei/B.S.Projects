package server.logic.runner;

import com.google.gson.Gson;
import server.logic.users.Master;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ForgetPass {


    public static void main(String[] args) throws FileNotFoundException {
        Gson gson = new Gson();
        File file = new File("data base/users/81111111.json");
        Scanner scan = new Scanner(file);
        String json = scan.nextLine();
        Master master = gson.fromJson(json, Master.class);
        master.setPassword("81111111");
    }
}
