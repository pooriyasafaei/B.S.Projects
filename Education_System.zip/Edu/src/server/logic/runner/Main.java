package server.logic.runner;

import server.logic.main_data.Edu;

public class Main {
    public static void main(String[] args) {
        Edu.startSystem();         //  :)
    }
}
