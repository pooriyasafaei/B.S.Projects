package server.logic.runner;

import server.logic.colleges.College;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.users.Master;
import server.logic.users.User;
import server.time.DateTime;

/* Note: if you run this class, all of saved data will be removed*/
public class MakeInitialFile {
    public static void main(String[] args) {
        Edu edu = new Edu();
        Edu.setMainData(edu);

        // Making colleges
        College math = new College(11, "Math");
        College ce = new College(22, "Computer engineering");
        College me = new College(33, "Mechanical engineering");
        College ee = new College(44, "Electrical engineering");
        College ph = new College(55, "Physics");
        College maaref = new College(77, "Maaref");


        User noOne = new User("No One", "0", "0", 11, -1, new DateTime());
        Edu.getUsers().add(noOne);
        edu.getMastersId().add(-1L);

        // Making deans
        Master mohseni = new Master("Mohseni", "12345678", "0012345678",
                11, 12345678, new DateTime(), "professor", false, false,111 );

        Master admin = new Master("Admin", "1", "0012345678",
                11, 1, new DateTime(), "professor", false, false,1 );

        Master mathDean = new Master("Davood Fadaei", "11111111", "0012345678",
                11, 11111111, new DateTime(), "professor", false, true,11 );

        Master ceDean = new Master("َAli Ejmali", "22222222", "0022345678",
                22, 22222222, new DateTime(), "professor", false, true,21 );

        Master meDean = new Master("َMohammad NazdikAli", "33333333", "00323456789",
                33, 33333333, new DateTime(), "professor", false, true,31 );

        Master eeDean = new Master("َSeyyed Hashem Akbari", "44444444", "0042345678",
                44, 44444444, new DateTime(), "professor", false, true,41 );

        Master phDean = new Master("َMirza Davvod Moeze", "55555555", "0052345678",
                55, 55555555, new DateTime(), "professor", false, true,51 );

        Master maarefDean = new Master("َSeyeed Jalil Tabaei", "77777777", "0052345678",
                77, 77777777, new DateTime(), "professor", false, true,71);




        // Making chancellors
        Master mathChan = new Master("Shahram Khazaei", "91111111", "0019876543",
                11, 91111111, new DateTime(), "assistant", true, false,11 );

        Master ceChan = new Master("َMehrshad Aba", "92222222", "0029876543",
                22, 92222222, new DateTime(), "assistant", true, false,21 );

        Master meChan = new Master("Maryam Khosravani", "93333333", "0039876543",
                33, 93333333, new DateTime(), "assistant", true, false,31 );

        Master eeChan = new Master("َAli Movakeli", "94444444", "0049876543",
                44, 94444444, new DateTime(), "assistant", true, false,41 );

        Master phChan = new Master("َHessam Miri", "95555555", "0059876543",
                55, 95555555, new DateTime(), "assistant", true, false,51 );

        Master maarefChan = new Master("َRouhoulah Taghian", "97777777", "0059876543",
                77, 97777777, new DateTime(), "assistant", true, false,71 );




        // making master for every college

        Master mathMaster1 = new Master("Kasra Alishahi", "81111111", "0018765432",
                11, 81111111, new DateTime(), "associate", false, false,11 );

        Master mathMaster2 = new Master("Mojtaba Tefagh", "71111112", "0018865433",
                11, 71111112, new DateTime(), "associate", false, false,11 );

        Master ceMaster1 = new Master("Amir Jalili", "82222222", "0028765432",
                22, 82222222, new DateTime(), "associate", true, false,21 );

        Master meMaster1 = new Master("Alireza Mousavi", "83333333", "0038765432",
                33, 83333333, new DateTime(), "associate", true, false,31 );

        Master eeMaster1 = new Master("Arash Amini", "84444444", "0048765432",
                44, 84444444, new DateTime(), "associate", true, false,41 );

        Master phMaster1 = new Master("Ahmad Bahman Abadi", "85555555", "0058765432",
                55, 85555555, new DateTime(), "associate", true, false,51 );

        // add some students in course
        //TODO

        //
        DataAccess.saveAllData();
    }
}
