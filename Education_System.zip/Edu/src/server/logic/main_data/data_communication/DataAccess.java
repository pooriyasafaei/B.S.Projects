package server.logic.main_data.data_communication;

import com.google.gson.Gson;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.courses.Course;
import server.logic.main_data.Edu;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DataAccess {

    public static boolean saveCore(){
        Edu core = Edu.getInstance();
        if(core == null) return false;

        try {
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\core\\core.json");
            gson.toJson(core, fileWriter);
            fileWriter.close();
            Logger.logEvent(new DataAccess(), "saveCore", "core saved",
                    new Object[]{core}, LogType.actionDone);
            return true;

        } catch (Exception e){
            Logger.logException(new DataAccess(), "saveCore", "couldn't save the core");
            return false;
        }
    }

    public static boolean saveAllData()  {
        if(!saveCore()) return false;

        boolean t = true;
        for (User user : Edu.getUsers()) {
            t = t && dumpUser(user);
        }
        for (Course course : Edu.getCourses()) {
            t = t && dumpCourse(course);
        }
        for (College college : Edu.getColleges()) {
            t = t && dumpCollage(college);
        }
        return t;
    }

    public static boolean loadCore(){
        File file = new File("data base\\core\\core.json");
        try {
            Scanner scan = new Scanner(file);
            String json = scan.nextLine();
            Gson gson = new Gson();
            Edu.setMainData(gson.fromJson(json, Edu.class));
            Logger.logEvent(new DataAccess(), "loadCore", "core loaded",
                    new Object[]{}, LogType.actionDone);
            return true;

        } catch (IOException e){
            e.printStackTrace();
            Logger.logException(new DataAccess(), "loadCore", "couldn't load core");
            return false;
        }
    }

    public static boolean loadAllData(){
        if (!loadCore()) return false;

        boolean t = true;
        for(long masterId: Edu.getInstance().getMastersId()){
            Master master = (Master) (loadUser(masterId));
            if(master == null) t = false;
            else Edu.getUsers().add(master);
        }

        for(long studentId: Edu.getInstance().getStudentsId()){
            Student student = (Student) (loadUser(studentId));
            if(student == null) t = false;
            else Edu.getUsers().add(student);
        }

        for (long courseId: Edu.getInstance().getCoursesId()){
            Course course = loadCourse(courseId);
            if(course == null) t = false;
            else Edu.getCourses().add(course);
        }

        for (int collegeNumber: Edu.getInstance().getCollagesNumber()){
            College college = loadCollege(collegeNumber);
            if(college == null) t = false;
            else Edu.getColleges().add(college);
        }

        return t;
    }

    public static User loadUser(long userId) {

        try {
            Gson gson = new Gson();
            File file = new File("data base\\users\\" + userId + ".json");
            Scanner scan = new Scanner(file);
            String json = scan.nextLine();
            Logger.logEvent(new DataAccess(), "loadUser", "user loaded",
                    new Object[]{userId}, LogType.actionDone );

            if(Edu.getInstance().getStudentsId().contains(userId)) return gson.fromJson(json, Student.class);
            else return gson.fromJson(json, Master.class);

        }
        catch (Exception e){
            Logger.logException(new DataAccess(), "loadUser", "couldn't load user");
            return null;
        }
    }

    public static College loadCollege(int collegeNumber){
        try {
            Gson gson = new Gson();
            File file = new File("data base\\colleges\\" + collegeNumber + ".json");
            Scanner scan = new Scanner(file);
            String json = scan.nextLine();
            College c = gson.fromJson(json, College.class);
            Logger.logEvent(new DataAccess(), "loadCollege", "college loaded",
                    new Object[]{collegeNumber}, LogType.actionDone );
            return c;

        } catch (Exception e){
            Logger.logException(new DataAccess(), "loadCollege", "couldn't load college" );
            return null;
        }
    }

    public static Course loadCourse(long courseId){

        try {
            Gson gson = new Gson();
            File file = new File("data base\\courses\\" + courseId + ".json");
            Scanner scan = new Scanner(file);
            String json = scan.nextLine();
            Course c = gson.fromJson(json, Course.class);
            Logger.logEvent(new DataAccess(), "loadCourse", "course loaded",
                    new Object[]{courseId}, LogType.actionDone );
            return c;

        } catch (Exception e){
            Logger.logException(new DataAccess(), "loadCourse", "couldn't load course" );
            return null;
        }
    }

    public static boolean dumpCourse(Course course) {
          if(course == null) return false;
        try {
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\courses\\" + course.getId() + ".json");
            gson.toJson(course, fileWriter);
            fileWriter.close();
            Logger.logEvent(new DataAccess(), "dumpCourse", "course saved",
                    new Object[]{course}, LogType.actionDone );
            return true;

        } catch (Exception e){
            Logger.logException(new DataAccess(), "dumpCourse", "couldn't open file");
            return false;
        }
    }

    public static boolean dumpCollage(College college) {

        try {
            if (college == null) return false;
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\colleges\\" + college.getNumber() + ".json");
            gson.toJson(college, fileWriter);
            fileWriter.close();
            Logger.logEvent(new DataAccess(), "dumpCollege", "college saved",
                    new Object[]{college}, LogType.actionDone );
            return true;

        }catch (Exception e){
            Logger.logException(new DataAccess(), "dumpCollege", "couldn't open file");
            return false;
        }
    }

    public static boolean dumpUser(User user) {

        try {
            if (user == null) return false;
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\users\\" + user.getIdNumber() + ".json");
            gson.toJson(user, fileWriter);
            fileWriter.close();
            Logger.logEvent(new DataAccess(), "dumpUser", "user saved",
                    new Object[]{user}, LogType.actionDone );
            return true;

        } catch (Exception e){
            Logger.logException(new DataAccess(), "dumpUser", "couldn't open file" );
            return false;
        }
    }
}
