package server.logic.main_data;

import communication.PageType;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.controller.ServerRunner;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.courses.Course;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.request.Request;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;
import server.logic.users.security.PasswordHashing;
import server.time.TimeInWeek;

import java.io.File;
import java.util.LinkedList;

public class Edu {

    private static LinkedList<College> colleges = new LinkedList<>();
    private static LinkedList<User> users = new LinkedList<>();
    private static LinkedList<Course> courses = new LinkedList<>();
    private static Edu mainData;

    private LinkedList<Integer> collagesNumber = new LinkedList<>();
    private LinkedList<Long> studentsId = new LinkedList<>();
    private LinkedList<Long> mastersId = new LinkedList<>();
    private LinkedList<Long> coursesId = new LinkedList<>();

    private String message = "";
    private boolean flag;

    public static Edu getInstance(){
        return mainData;
    }

    public static void startSystem(){
        if (!DataAccess.loadAllData()){
            Logger.logEvent(new Edu(), "startSystem",
                    "couldn't load system", new Object[]{}, LogType.actionFailed);
            return;
        }

        Logger.logEvent(new Edu(), "startSystem", "system started", new Object[]{}, LogType.actionDone);
    }

    public static void stopSystem(){
        Logger.logEvent(Edu.getInstance(),"stopSystem", "system stopped",
                new Object[0], LogType.actionDone);
//        MainPanel.getInstance().dispatchEvent(new WindowEvent(MainPanel.getInstance(), WindowEvent.WINDOW_CLOSING));
//        MainPanel.getInstance().dispose();
    }

    public static void setMainData(Edu edu){
        mainData = edu;
    }

    public College getCollegeById(int collegeId) {
        for (College college: colleges)
            if (college.getNumber() == collegeId) {
                flag = true;
                return college;
            }

        flag = false;
        message = "College with this id number doesn't exist.";
        return null;
    }

    public LinkedList<Master> getMastersList(String collegeFilter, String nameFilter, String degreeFilter){
        LinkedList<Master> result = new LinkedList<>();
        for(User user: users){
            if((user instanceof Master) && (user.getIdNumber() > 0)) result.add((Master) user);
        }

        if(collegeFilter != null && !collegeFilter.equals("")){

            result.removeIf(master -> !getCollegeById(master.getCollegeId()).getName()
                    .toLowerCase().contains(collegeFilter.toLowerCase()));

        }

        if(nameFilter != null && !nameFilter.equals("")){
            result.removeIf(master -> !master.getName().toLowerCase().contains(nameFilter.toLowerCase()));
        }

        if(degreeFilter != null && !degreeFilter.equals("")){
            result.removeIf(master -> !master.getMasterDegree().toLowerCase().contains(degreeFilter.toLowerCase()));
        }

        return result;
    }

    public LinkedList<Student> getStudentsList(String studentIdFilter, String nameFilter, String collegeFilter){
        LinkedList<Student> result = new LinkedList<>();
        for(User user: users){
            if((user instanceof Student) && (user.getIdNumber() > 0)) result.add((Student) user);
        }

        if(collegeFilter != null && !collegeFilter.equals("")){

            result.removeIf(student -> !getCollegeById(student.getCollegeId()).getName()
                    .toLowerCase().contains(collegeFilter.toLowerCase()));

        }

        if(nameFilter != null && !nameFilter.equals("")){
            result.removeIf(student -> !student.getName().toLowerCase().contains(nameFilter.toLowerCase()));
        }

        if(studentIdFilter != null && !studentIdFilter.equals("")){
            result.removeIf(student -> !String.valueOf(student.getIdNumber()).
                    toLowerCase().contains(studentIdFilter.toLowerCase()));
        }

        return result;
    }

    public LinkedList<Course> getCoursesList(String collegeFilter, String courseIdFilter, String unitsFilter){
        LinkedList<Course> result = new LinkedList<>();
        boolean t = result.addAll(courses);

        try {
            if (collegeFilter != null && !collegeFilter.equals("")) {
                result.removeIf(course -> !getCollegeById(course.getCollegeId())
                        .getName().toLowerCase().contains(collegeFilter.toLowerCase()));
            }

            if (courseIdFilter != null && !courseIdFilter.equals("")) {
                result.removeIf(course -> !String.valueOf(course.getId()).toLowerCase()
                        .contains(courseIdFilter.toLowerCase()));
            }

            if (unitsFilter != null && !unitsFilter.equals("")) {
                result.removeIf(course -> !String.valueOf(course.getUnits()).toLowerCase()
                        .contains(unitsFilter.toLowerCase()));
            }
        } catch (Exception e){
            result = new LinkedList<>();
        }

        return result;
    }

    public LinkedList<Course> getCourseByAbsoluteId(long absoluteId){
        LinkedList<Course> result = new LinkedList<>();

        for (Course course: courses) {
            if(course.getAbsoluteId() == absoluteId)
                result.add(course);
        }

        return result;
    }

    public Course getCourseById(long courseId){
        for (Course course: courses)
            if (course.getId() == courseId) {
                flag = true;
                return course;
            }

        flag = false;
        message = "Course with this id number doesn't exist.";
        return null;
    }

    public Course studentHasCourse(long studentId, long courseAbsoluteId){
        Student student = (Student) getUserById(studentId);

        if(student == null) return null;

        for (long id: student.getTemporaryEnrolledCourses()){
            Course course = getCourseById(id);
            if(course == null) continue;

            if(course.getAbsoluteId() == courseAbsoluteId) return course;
        }

        return null;
    }

    public boolean canEnrollMaaref(long studentId){
        Student student = (Student) getUserById(studentId);

        if(student == null) return false;

        for (long id: student.getTemporaryEnrolledCourses()){
            Course course = getCourseById(id);
            if(course == null) continue;

            if(course.getCollegeId() == 77) return false;
        }

        return true;
    }

    public boolean canEnrollPrerequisite(long studentId, long courseId){
        Course course = getCourseById(courseId);
        Student student = (Student) getUserById(studentId);

        if(student == null || course == null) return false;

        for (Long id: course.getPrerequisites()) {
            LinkedList<Course> possibleCourses = getCourseByAbsoluteId(id);
            boolean t = false;

            for (Course possiblePassed: possibleCourses) {
                if(possiblePassed.isStudentPassed(studentId)){
                    t = true;
                    break;
                }
            }

            if(!t) return false;
        }

        return true;
    }

    public boolean canEnrollNecessities(long studentId, long courseId){
        Course course = getCourseById(courseId);
        Student student = (Student) getUserById(studentId);

        if(student == null || course == null) return false;

        for (Long id: course.getNecessities()) {
            LinkedList<Course> possibleCourses = getCourseByAbsoluteId(id);
            boolean t = false;

            for (Course possiblePassed: possibleCourses) {
                if(possiblePassed.isStudentPassed(studentId) || student.getTemporaryEnrolledCourses().
                        contains(possiblePassed.getId())){
                    t = true;
                    break;
                }
            }

            if(!t) return false;
        }

        return true;
    }

    public boolean canEnrollTimeInWeek(long studentId, long courseId){
        Course course = getCourseById(courseId);
        Student student = (Student) getUserById(studentId);

        if(student == null || course == null) return false;

        for (Long id: student.getTemporaryEnrolledCourses()) {
            Course studentCourse = getCourseById(id);
            if(studentCourse == null) continue;

            if(TimeInWeek.hasCollision(studentCourse.getTimeInWeek(), course.getTimeInWeek())) return false;

        }

        return true;
    }

    public boolean canEnrollExamTime(long studentId, long courseId){
        Course course = getCourseById(courseId);
        Student student = (Student) getUserById(studentId);

        if(student == null || course == null) return false;

        for (Long id: student.getTemporaryEnrolledCourses()) {
            Course studentCourse = getCourseById(id);
            if(studentCourse == null) continue;

            if(studentCourse.getExamTime().equals(course.getExamTime())) return false;

        }

        return true;
    }

    public void purgeEnroll(){
        for (Long studentId: studentsId) {
            purgeStudentCourses(studentId);
        }
    }

    public void purgeStudentCourses(long studentId){
        Student student = (Student) getUserById(studentId);
        boolean changed = false;

        if(student == null) return;

        for (Long id: student.getTemporaryEnrolledCourses()) {
            if(!canEnrollPrerequisite(studentId, id) || !canEnrollNecessities(studentId, id)){
                changed = true;
                getCourseById(id).removeStudent(studentId);
                DataAccess.dumpCourse(getCourseById(id));
            }
        }
        if(changed) purgeStudentCourses(studentId);

        else {
            student.getCoursesId().addAll(student.getTemporaryEnrolledCourses());
            for (long id: student.getTemporaryEnrolledCourses()) {
                Request.serverMessage(studentId, "you added as Student to course with id " + id);
            }
            student.getTemporaryEnrolledCourses().clear();
            DataAccess.dumpUser(student);
        }
    }

    public User getUserById(long id){
        for (User user: users)
            if (user.getIdNumber() == id) {
                flag = true;
                return user;
            }

        flag = false;
        message = "User with this id number doesn't exist.";
        return null;
    }

    public ServerResponse logIn(long idNumber, String password){

        ServerResponse response = new ServerResponse();
        response.setType(ServerResponseType.Login);

        User user = getUserById(idNumber);
        if(user == null) {
            response.setFlag(false);
            response.setServerMessage("Username doesn't exist.");
            return response;
        }

        if(!user.getPassword().equals(PasswordHashing.generateHash(password))) {
            response.setFlag(false);
            response.setPage(PageType.LoginPage);
            response.setServerMessage("Password is not correct.");
            return response;
        }

        if(!user.isActive()){
            response.setFlag(false);
            response.setPage(PageType.LoginPage);
            response.setServerMessage("User is not active");
            return response;
        }

        response.setFlag(true);
        response.addData("picture_url", ServerRunner.getProperties().getProperty("pictures_folder") + idNumber + ".jpg");

        File file = new File(ServerRunner.getProperties().getProperty("pictures_folder") + idNumber + ".jpg");

        if(file.isFile()) {
            response.addData("picture_url", ServerRunner.getProperties().getProperty("pictures_folder") + idNumber + ".jpg");
            user.setImagePathName(ServerRunner.getProperties().getProperty("pictures_folder") + idNumber + ".jpg");
        }

        else {
            response.addData("picture_url", ServerRunner.getProperties().getProperty("pictures_folder") + "default.jpg");
            user.setImagePathName("image datas\\users\\default.jpg");
        }

        //MainPanel.getInstance().setTheme(user.getTheme());
        response.setServerMessage("login successful");

        Logger.logEvent(mainData, "logIn", message, new Object[]{user}, LogType.actionDone);

        response.addData("user", user.getIdNumber());

        if(user instanceof Student) {
            response.addData("user_type", "student");
        }

        if(user instanceof Master) {
            if(((Master)user).isChancellor()) response.addData("user_type", "chancellor");
            if(((Master)user).isDean()) response.addData("user_type", "dean");
            //TODO
            if(!((Master)user).isChancellor() && ((Master)user).isDean()) response.addData("user_type", "master");
        }

        return response;
    }

    public static LinkedList<College> getColleges() {
        return colleges;
    }

    public static LinkedList<Course> getCourses() {
        return courses;
    }

    public LinkedList<Integer> getCollagesNumber() {
        return collagesNumber;
    }

    public void setCollagesNumber(LinkedList<Integer> collagesNumber) {
        this.collagesNumber = collagesNumber;
    }

    public LinkedList<Long> getStudentsId() {
        return studentsId;
    }

    public void setStudentsId(LinkedList<Long> studentsId) {
        this.studentsId = studentsId;
    }

    public LinkedList<Long> getMastersId() {
        return mastersId;
    }

    public void setMastersId(LinkedList<Long> mastersId) {
        this.mastersId = mastersId;
    }

    public LinkedList<Long> getCoursesId() {
        return coursesId;
    }

    public void setCoursesId(LinkedList<Long> coursesId) {
        this.coursesId = coursesId;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static void setColleges(LinkedList<College> colleges) {
        Edu.colleges = colleges;
    }

    public static LinkedList<User> getUsers() {
        return users;
    }

    public static void setUsers(LinkedList<User> users) {
        Edu.users = users;
    }

    public static void setCourses(LinkedList<Course> courses) {
        Edu.courses = courses;
    }

    public static Edu getMainData() {
        return mainData;
    }
}
