package server.logic.login;

import client.controller.Controller;

import javax.swing.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;

public class CaptchaClass {

    private final HashMap<ImageIcon, Integer> captchaMap;
    private final LinkedList<ImageIcon> captchas;
    private static CaptchaClass instance;

    public CaptchaClass(){
        captchas = new LinkedList<>();

        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha1")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha2")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha3")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha4")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha5")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha6")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha7")));
        captchas.add(new ImageIcon(Controller.getProperties().getProperty("captcha8")));


        captchaMap = new HashMap<>();
        captchaMap.put(captchas.get(0), 3449);
        captchaMap.put(captchas.get(1), 8077);
        captchaMap.put(captchas.get(2), 6745);
        captchaMap.put(captchas.get(3), 4963);
        captchaMap.put(captchas.get(4), 7335);
        captchaMap.put(captchas.get(5), 1950);
        captchaMap.put(captchas.get(6), 5005);
        captchaMap.put(captchas.get(7), 4389);

    }

    public static CaptchaClass getInstance(){
        if (instance == null)
            instance = new CaptchaClass();
        return instance;
    }

    public ImageIcon getRandomCaptcha(){
        Random random = new Random();

        int n = random.nextInt() % 8;
        if(n < 0) n += 8;
        return captchas.get(n);
    }

    public boolean checkCaptchaCode(String captchaInput, ImageIcon captcha){
        return ("" + captchaMap.get(captcha)).equals(captchaInput);
    }

}
