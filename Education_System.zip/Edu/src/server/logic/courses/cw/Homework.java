package server.logic.courses.cw;

import server.time.DateTime;

import java.util.HashSet;
import java.util.LinkedList;

public class Homework extends Content {

    private String info;
    private DateTime deadline;
    private DateTime closeTime;
    private HashSet<Submission> submissions = new HashSet<>();
    private boolean answerText;

    public Homework() {
        super();
    }

    public void markSubmission(int submissionNumber, int mark){
        Submission submission = null;
        for (Submission submission1: submissions) {
            if(submission1.getNumber() == submissionNumber) {
                submission = submission1;
                break;
            }
        }

        submission.setMark(mark);
    }

    public Homework(String name, boolean isText, String text, DateTime lastChange,
                    String info, DateTime deadline, DateTime closeTime, boolean answerText) {
        super(name, isText, text, lastChange);
        this.info = info;
        this.deadline = deadline;
        this.closeTime = closeTime;
        this.answerText = answerText;
    }

    public void addSubmission(long studentId, String submit, boolean isText){
        for (Submission submission: submissions) {
            if(submission.getStudentId() == studentId) {
                submission.setText(submit);
                return;
            }
        }

        submissions.add(new Submission(studentId, submissions.size() + 1, isText, submit, new DateTime()));
    }

    public Submission getSubmission(int submissionNumber){
        for (Submission submission: submissions) {
            if(submission.getNumber() == submissionNumber) return submission;
        }

        return null;
    }

    public int getGrade(long studentId){
        for (Submission submission: submissions) {
            if(submission.getStudentId() == studentId) return submission.getMark();
        }
        return -100;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public DateTime getDeadline() {
        return deadline;
    }

    public void setDeadline(DateTime deadline) {
        this.deadline = deadline;
    }

    public DateTime getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(DateTime closeTime) {
        this.closeTime = closeTime;
    }

    public HashSet<Submission> getSubmissions() {
        return submissions;
    }

    public LinkedList<Submission> getSubmissionsList() {
        return new LinkedList<>(submissions);
    }

    public void setSubmissions(HashSet<Submission> submissions) {
        this.submissions = submissions;
    }

    public boolean isAnswerText() {
        return answerText;
    }

    public void setAnswerText(boolean answerText) {
        this.answerText = answerText;
    }
}
