package server.logic.courses.cw;

import server.time.DateTime;

public class Submission extends Content {

    private long studentId;
    private int number;
    private int mark;

    public Submission(){

    }

    public Submission(long studentId, int number, boolean isText, String text, DateTime lastChange) {
        super(String.valueOf(studentId), isText, text, lastChange);
        this.number = number;
        this.studentId = studentId;
        this.mark = -1;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        if(mark > 100 || mark < 0) return;
        this.mark = mark;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}