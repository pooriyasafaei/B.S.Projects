package server.logic.courses.cw;

import server.time.DateTime;

public class Content {

    private String name;
    private boolean isText;
    private String text;
    private DateTime time;

    public Content(){

    }

    public Content(String name, boolean isText, String text, DateTime time) {
        this.name = name;
        this.isText = isText;
        this.text = text;
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isText() {
        return isText;
    }

    public void setIsText(boolean text) {
        isText = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public DateTime getTime() {
        return time;
    }

    public void setTime(DateTime time) {
        this.time = time;
    }
}
