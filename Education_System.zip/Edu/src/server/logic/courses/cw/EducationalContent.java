package server.logic.courses.cw;

import server.time.DateTime;

import java.util.LinkedList;

public class EducationalContent {

    private String name;
    private DateTime lastChange;
    private LinkedList<Content> contents = new LinkedList<>();

    public EducationalContent() {
    }

    public EducationalContent(String name, DateTime lastChange) {
        this.name = name;
        this.lastChange = lastChange;
    }

    public Content getItem(String itemName){
        for (Content content: contents) {
            if(content.getName().equals(itemName)) return content;
        }

        return null;
    }

    public void addItem(Content item){
        contents.add(item);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DateTime getLastChange() {
        return lastChange;
    }

    public void setLastChange(DateTime lastChange) {
        this.lastChange = lastChange;
    }

    public LinkedList<Content> getContents() {
        return contents;
    }

    public void setContents(LinkedList<Content> contents) {
        this.contents = contents;
    }
}
