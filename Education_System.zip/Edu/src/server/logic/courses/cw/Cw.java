package server.logic.courses.cw;
import java.util.LinkedList;

public class Cw {

    private long courseId;
    private LinkedList<Homework> homeworks;
    private LinkedList<EducationalContent> contents;

    public Cw(long courseId) {
        this.courseId = courseId;
        this.homeworks = new LinkedList<>();
        this.contents = new LinkedList<>();

    }

    public EducationalContent getContent(String contentName){

        for (EducationalContent content: contents) {
            if(content.getName().equals(contentName)) return content;
        }
        return null;
    }

    public Homework getHomework(String homeworkName){

        for (Homework homework: homeworks) {
            if(homework.getName().equals(homeworkName)) return homework;
        }
        return null;
    }

    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public LinkedList<Homework> getHomeworks() {
        return homeworks;
    }

    public void setHomeworks(LinkedList<Homework> homeworks) {
        this.homeworks = homeworks;
    }

    public LinkedList<EducationalContent> getContents() {
        return contents;
    }

    public void setContents(LinkedList<EducationalContent> contents) {
        this.contents = contents;
    }
}
