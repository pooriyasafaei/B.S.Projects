package server.logic.courses;

import server.logic.main_data.Edu;

public class Protest {

    private long studentId;
    private long courseId;

    private String requestText;
    private String responseText = "";


    public Protest(long courseId, long studentId, String requestText){

        this.courseId = courseId;
        this.studentId = studentId;
        this.requestText = requestText;

        Course course = Edu.getInstance().getCourseById(courseId);
        course.getProtests().add(this);
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(long courseId) {
        this.courseId = courseId;
    }

    public String getRequestText() {
        return requestText;
    }

    public void setRequestText(String requestText) {
        this.requestText = requestText;
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }
}
