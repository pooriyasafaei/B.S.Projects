package server.logic.courses;

import client.controller.Controller;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.courses.cw.Cw;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.request.Request;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;
import server.time.TimeInWeek;

import java.util.HashMap;
import java.util.LinkedList;

public class Course {

    private String name;
    private long masterId;
    private HashMap<Long, Double> studentsMark;
    private LinkedList<Protest> protests = new LinkedList<>();

    private boolean markRegistered;
    private boolean finalRegistered;

    private int units;
    private long id;
    private long absoluteId;
    private int collegeId;
    private TimeInWeek timeInWeek;
    private DateTime examTime;

    private LinkedList<Long> assistants = new LinkedList<>();
    private LinkedList<Long> prerequisites = new LinkedList<>();
    private LinkedList<Long> necessities = new LinkedList<>();
    private String section;
    private int semester;
    private int capacity;
    private int group;

    private Cw courseware;

    public Course(String name, long masterId, int units, long id, int collegeId, TimeInWeek timeInWeek, DateTime examTime,
                  LinkedList<Long> assistants, LinkedList<Long> prerequisites, LinkedList<Long> necessities,
                  String section, int semester, int capacity, int group) {

        Edu edu = Edu.getInstance();

        if(edu.getCourseById(id * 100_000 + semester * 100L + group) != null) {
            edu.setMessage("Course already exists.");
            Logger.logException(this, "constructor", edu.getMessage());

            edu.setFlag(false);
            return;
        }

        if(!edu.getMastersId().contains(masterId)){
            edu.setMessage("Master with this id doesn't exist");
            Logger.logException(this, "constructor", edu.getMessage());

            edu.setFlag(false);
            return;
        }

        this.name = name;
        this.masterId = masterId;
        this.units = units;
        this.absoluteId = id;
        this.id = id * 100_000 + semester * 100L + group;
        this.collegeId = collegeId;
        this.timeInWeek = timeInWeek;
        this.examTime = examTime;
        this.studentsMark = new HashMap<>();
        this.assistants = assistants;
        this.prerequisites = prerequisites;
        this.necessities = necessities;
        this.section = section;
        this.semester = semester;
        this.capacity = capacity;
        this.group = group;
        markRegistered = false;
        finalRegistered = false;
        courseware = new Cw(this.id);

        Master master = (Master) edu.getUserById(masterId);
        master.getCoursesId().add(this.id);
        DataAccess.dumpUser(master);

        College college = edu.getCollegeById(collegeId);
        college.getCoursesId().add(this.id);
        DataAccess.dumpCollage(college);

        edu.getCoursesId().add(this.id);
        Edu.getCourses().add(this);

        DataAccess.dumpCourse(this);
        DataAccess.saveCore();

        edu.setMessage("course created");
        edu.setFlag(true);

        Logger.logEvent(this, "constructor", "Course created", new Object[]{this},
                LogType.actionDone);

        for (long studentId: assistants) {
            Student student = ((Student)edu.getUserById(studentId));
            student.getAssistantCourses().add(this.id);
            Request.serverMessage(studentId, " you added as TA to course " + this.getId());
            DataAccess.dumpUser(student);
        }
    }

    public ServerResponse editCourse(String courseName, String timeInWeek, String examTime,
                                     String masterId, String units, User functor){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if (functor == null || functor.getCollegeId() != this.collegeId) {
                response.setServerMessage("You can't change this course");
                response.setFlag(false);
                return response;
        }
        try {
            DateTime examDate = null;
            Long numMasterId = null;
            Integer numUnits = null;

           if(examTime != null && !examTime.equals("")) examDate = DateTime.toDateTime(examTime);
           if(masterId != null && !masterId.equals("")) numMasterId = Long.parseLong(masterId);
           if(units != null && !units.equals("")) numUnits = Integer.parseInt(units);

           if(numMasterId != null && !Edu.getInstance().getMastersId().contains(numMasterId)){
               response.setServerMessage("Master with that id doesn't exist");
               response.setFlag(false);
               return response;
           }

           if(numMasterId != null) {
               User master =  Edu.getInstance().getUserById(numMasterId);
               if(!(master instanceof Master)){
                   response.setServerMessage("Master with this id doesn't exist");
                   response.setFlag(false);
                   return response;
               }
               this.setMasterId(numMasterId);
               ((Master) master).getCoursesId().add(this.id);
               DataAccess.dumpUser(master);
           }
           if(examDate != null) this.examTime = examDate;
           if(numUnits != null) this.units = numUnits;
           if(timeInWeek != null && !timeInWeek.equals("")) this.timeInWeek = TimeInWeek.makeTimeFromString(timeInWeek);
           if(courseName != null && !courseName.equals("")) this.name = courseName;

            DataAccess.dumpCourse(this);
            response.setServerMessage("course was edited");

           Logger.logEvent(this, "editCourse", "course edited",
                   new Object[]{this}, LogType.actionDone );

           return response;

        } catch (Exception e){
            response.setServerMessage("Invalid input");
            Logger.logException(this, "editCourse", "input Exception");
            return response;
        }
    }

    public ServerResponse deleteCourse(User functor) {
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

            Edu edu = Edu.getInstance();
            if (functor == null || functor.getCollegeId() != collegeId) {
                response.setServerMessage("You can't delete this course");
                response.setFlag(false);
                return response;
            }
            for(long studentsId: studentsMark.keySet()){
                Student student = (Student) (edu.getUserById(studentsId));
                student.getCoursesId().remove(this.id);
                DataAccess.dumpUser(student);
            }

            Master master = (Master)(edu.getUserById(masterId));
            master.getCoursesId().remove(id);
            DataAccess.dumpUser(master);

            College college = edu.getCollegeById(collegeId);
            college.getCoursesId().remove(id);
            DataAccess.dumpCollage(college);

            Edu.getCourses().remove(this);
            edu.getCoursesId().remove(id);

            response.setFlag(true);
            response.setServerMessage("Course deleted");

            DataAccess.saveCore();

            DataAccess.dumpCourse(this);

            Logger.logEvent(this, "deleteCourse", "course deleted", new Object[]{this},
                LogType.actionDone);

            return response;
    }

    public boolean isStudentPassed(long studentId){

        if(!studentsMark.containsKey(studentId)) return false;
        return studentsMark.get(studentId) >= 10;
    }

    public boolean hasCapacity(){
        return studentsMark.size() < capacity;
    }

    public ServerResponse registerCourse(){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        for (long id: studentsMark.keySet()){
            if(studentsMark.get(id) < 0){
                response.setServerMessage("you can't register marks until you set a mark for every student");
                response.setFlag(false);
                return response;
            }
        }
        this.markRegistered = true;
        response.setServerMessage("mark for the course registered");
        DataAccess.dumpCourse(this);

        Logger.logEvent(this, "registerCourse", "mark registered",
                new Object[]{this}, LogType.actionDone);

        response.setFlag(true);
        return response;
    }

    public ServerResponse responseProtest(String studentId, String newMark, String response){

        ServerResponse serverResponse = new ServerResponse(ServerResponseType.Action);

        try {
            Long student = null;
            Double mark = null;
            Protest protest = null;
            if(studentId != null && !studentId.equals("")) student = Long.parseLong(studentId);
            if(newMark != null && !newMark.equals("")) mark = roundMark(Double.parseDouble(newMark));

            if(student != null) protest = getStudentProtest(student);
            if(protest != null && (response != null && !response.equals(""))) protest.setResponseText(response);

            if(student != null && mark != null){
                if(!(Edu.getInstance().getUserById(student) instanceof Student)){
                    serverResponse.setServerMessage("Student with that id doesn't exist");
                    serverResponse.setFlag(false);
                    return serverResponse;
                }
                if(!editMark(student, mark).isFlag()){
                    serverResponse.setServerMessage("invalid inputs for changing mark");
                    serverResponse.setFlag(false);
                    return serverResponse;
                }
            }

            DataAccess.dumpCourse(this);

            serverResponse.setServerMessage("response sent");
            serverResponse.setFlag(true);

            Logger.logEvent(this, "responseProtest", "protest response sent",
                    new Object[]{protest, mark}, LogType.actionDone);

            return serverResponse;

        }catch (Exception e){
            serverResponse.setFlag(false);
            serverResponse.setServerMessage("invalid inputs");

            Logger.logException(this, "responseProtest", "input Exception");

            return serverResponse;
        }
    }

    public synchronized ServerResponse addStudent(long studentId, boolean withCondition){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        User user = (Edu.getInstance().getUserById(studentId));

        if(!(user instanceof Student student)){
            response.setFlag(false);
            response.setServerMessage("Student with this id doesn't exist");
            return response;
        }
        if(this.studentsMark.containsKey(studentId)){
            response.setFlag(false);
            response.setServerMessage("Student with this id already have this course");
            return response;
        }


        if(withCondition){

            if (this.isMarkRegistered()) {
                response.setFlag(false);
                response.setServerMessage("Can't add student to course because marks are registered");
                return response;
            }

            if (!Edu.getInstance().canEnrollPrerequisite(student.getIdNumber(), this.getId())) {
                response.setFlag(false);
                response.setServerMessage("Prerequisites and necessities have not been met");
                return response;
            }

            if (!Edu.getInstance().canEnrollExamTime(student.getIdNumber(), this.getId())) {
                response.setFlag(false);
                response.setServerMessage("Interfering final exams time");
                return response;
            }

            if (!Edu.getInstance().canEnrollTimeInWeek(student.getIdNumber(), this.getId())) {
                response.setFlag(false);
                response.setServerMessage("Interfering with the weekly schedule");
                return response;
            }

            if (!hasCapacity()) {
                response.setFlag(false);
                response.setServerMessage("No capacity for this group of course");
                return response;
            }

            if (collegeId == 77 && !Edu.getInstance().canEnrollMaaref(student.getIdNumber())) {
                response.setFlag(false);
                response.setServerMessage("You can only enroll one course from Maaref");
                return response;
            }

            student.getTemporaryEnrolledCourses().add(this.id);
        }

        else student.getCoursesId().add(this.id);

        this.studentsMark.put(studentId, -1.0);
        response.setFlag(true);
        DataAccess.dumpCourse(this);
        DataAccess.dumpUser(student);

        response.setServerMessage("Student added to course");

        Logger.logEvent(this, "addStudent", "Student added",
                new Object[]{"CourseId: " + this.id, student}, LogType.actionDone);


        return response;
    }

    public synchronized ServerResponse removeStudent(long studentId){
        //    Edu edu = Edu.getInstance();
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        User user = (Edu.getInstance().getUserById(studentId));

        if(!(user instanceof Student student)){
            response.setFlag(false);
            response.setServerMessage("Student with this id doesn't exist");
            return response;
        }
        if(!this.studentsMark.containsKey(studentId)){
            response.setFlag(false);
            response.setServerMessage("Student with this id doesn't have this course");
            return response;
        }
        if(this.isMarkRegistered()){
            response.setFlag(false);
            response.setServerMessage("Can't remove student from course because marks are registered");
            return response;
        }


        student.getTemporaryEnrolledCourses().remove(this.id);
        this.studentsMark.remove((Long) studentId);
        response.setFlag(true);

        DataAccess.dumpCourse(this);
        DataAccess.dumpUser(student);

        response.setServerMessage("Student removed from course");

        Logger.logEvent(this, "addStudent", "Student added",
                new Object[]{"CourseId: " + this.id, student}, LogType.actionDone);


        return response;
    }

    public double getGradingAverage(){
        double average = 0;
        int n = 0;
        for (long key: studentsMark.keySet()){
            double mark = studentsMark.get(key);
            if(mark < 10) continue;
            average += mark;
            n++;
        }
        if(n == 0) return 0.0;
        else return average/n;
    }

    public int[] getPassedFailed(){
        int[] result = new int[2];
        for (long key: studentsMark.keySet()){
            double mark = studentsMark.get(key);
            if(mark >= 10) result[0]++;
            if(mark < 10 && mark >= 0) result[1]++;

        }
        return result;
    }

    public Protest getStudentProtest(long studentId){
        for (Protest protest: protests){
            if(protest.getStudentId() == studentId)
                return protest;
        }
        return null;
    }

    private double roundMark(double mark){
        return Math.round(mark / 0.25) * 0.25;
    }

    public LinkedList<Student> getStudentsList(boolean isFromServer){
        LinkedList<Student> result = new LinkedList<>();
        if(isFromServer){
            for (long id: studentsMark.keySet()){
                Student student = (Student) (Edu.getInstance().getUserById(id));
                if (student != null) result.add(student);
            }
        }else {
            for (long id: studentsMark.keySet()){
                Student student = (Student) (Controller.getInstance().getOfflineData().getUserById(id));
                if (student != null) result.add(student);
            }
        }
        return result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        DataAccess.dumpCourse(this);
    }

    public int getCollegeId() {
        return collegeId;
    }

    public void setCollegeId(int collegeId) {
        this.collegeId = collegeId;
        DataAccess.dumpCourse(this);
    }

    public HashMap<Long, Double> getStudentsMark() {
        return studentsMark;
    }

    public void setStudentsMark(HashMap<Long, Double> studentsMark) {
        this.studentsMark = studentsMark;
        DataAccess.dumpCourse(this);
    }

    public void setProtests(LinkedList<Protest> protests) {
        this.protests = protests;
        DataAccess.dumpCourse(this);
    }

    public boolean isMarkRegistered() {
        return markRegistered;
    }

    public void setMarkRegistered(boolean markRegistered) {
        this.markRegistered = markRegistered;
        DataAccess.dumpCourse(this);
    }

    public int getUnits() {
        return units;
    }

    public void setUnits(int units) {
        this.units = units;
        DataAccess.dumpCourse(this);
    }

    public void setId(long id) {
        this.absoluteId = id;
        this.id = id * 100_000 + semester * 100L + group;
        DataAccess.dumpCourse(this);
    }

    public TimeInWeek getTimeInWeek() {
        return timeInWeek;
    }

    public void setTimeInWeek(TimeInWeek timeInWeek) {
        this.timeInWeek = timeInWeek;
        DataAccess.dumpCourse(this);
    }

    public DateTime getExamTime() {
        return examTime;
    }

    public void setExamTime(DateTime examTime) {
        this.examTime = examTime;
        DataAccess.dumpCourse(this);
    }

    public double getMark(long studentId){
        return studentsMark.get(studentId);
    }

    public ServerResponse editMark(long studentId, double mark){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if(!studentsMark.containsKey(studentId)) {
            response.setServerMessage("student with that id doesn't have the course");
            response.setFlag(false);
            return response;
        }

        if(mark > 20 || mark < 0) {
            response.setServerMessage("enter number in range of 0 to 20");
            response.setFlag(false);
            return response;
        }

        studentsMark.put(studentId, roundMark(mark));
        DataAccess.dumpCourse(this);

        response.setFlag(true);
        response.setServerMessage("student mark updated");
        return response;
    }

    public long getId() {
        return id;
    }

    public long getMasterId() {
        return masterId;
    }

    public void setMasterId(long masterId) {
        if(this.masterId > 0){
            Master current = (Master) (Edu.getInstance().getUserById(this.masterId));
            if (current != null) current.getCoursesId().remove(this.id);
            DataAccess.dumpUser(current);
        }

        this.masterId = masterId;
        DataAccess.dumpCourse(this);
    }

    public LinkedList<Protest> getProtests() {
        return protests;
    }

    public boolean isFinalRegistered() {
        return finalRegistered;
    }

    public void setFinalRegistered(boolean finalRegistered) {
        this.finalRegistered = finalRegistered;
        DataAccess.dumpCourse(this);
    }

    public LinkedList<Long> getAssistants() {
        return assistants;
    }

    public void setAssistants(LinkedList<Long> assistants) {
        this.assistants = assistants;
        DataAccess.dumpCourse(this);

    }

    public LinkedList<Long> getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(LinkedList<Long> prerequisites) {
        this.prerequisites = prerequisites;
        DataAccess.dumpCourse(this);

    }

    public LinkedList<Long> getNecessities() {
        return necessities;
    }

    public void setNecessities(LinkedList<Long> necessities) {
        this.necessities = necessities;
        DataAccess.dumpCourse(this);

    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
        DataAccess.dumpCourse(this);

    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
        DataAccess.dumpCourse(this);

    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
        DataAccess.dumpCourse(this);

    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
        DataAccess.dumpCourse(this);

    }

    public long getAbsoluteId() {
        return absoluteId;
    }

    public void setAbsoluteId(long absoluteId) {
        this.absoluteId = absoluteId;
        this.id = absoluteId * 100_000 + semester * 100L + group;
        DataAccess.dumpCourse(this);
    }

    public Cw getCourseware() {
        return courseware;
    }

    public void setCourseware(Cw courseware) {
        this.courseware = courseware;
        DataAccess.dumpCourse(this);
    }
}
