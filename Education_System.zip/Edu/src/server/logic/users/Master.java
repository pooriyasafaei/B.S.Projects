package server.logic.users;

import client.controller.Controller;
import communication.public_info.EduPublicInfo;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.courses.Course;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.time.DateTime;

import java.util.LinkedList;

public class Master extends User{

    private LinkedList<Long> coursesId = new LinkedList<>();
    private LinkedList<Long> studentsSupervisedId = new LinkedList<>();
    private String masterDegree;

    private boolean chancellor;
    private boolean dean;

    private int room;

    public Master(String name, String password, String nationalId, int collegeId, long idNumber,
                  DateTime birthDay, String masterDegree, boolean chancellor, boolean dean, int room) {

        super(name, password, nationalId, collegeId, idNumber, birthDay);
        Edu edu = Edu.getInstance();
        if(!edu.isFlag()) return;

        if(!masterDegree.equalsIgnoreCase("professor") &&
                !masterDegree.equalsIgnoreCase("assistant") &&
                !masterDegree.equalsIgnoreCase("associate")){
            edu.setMessage("Master degree is not valid(professor, assistant or associate only)");
            edu.setFlag(false);
            Logger.logException(this, "constructor", edu.getMessage());
            return;
        }

        this.masterDegree = masterDegree;

        College college = edu.getCollegeById(collegeId);
        if(isDean())
            college.setDeanId(idNumber);

        if (isChancellor())
            college.setChancellorId(idNumber);
        this.chancellor = chancellor;
        this.dean = dean;

        this.room = room;

        studentsSupervisedId = new LinkedList<>();
        coursesId = new LinkedList<>();

        college.getMastersId().add(idNumber);
        DataAccess.dumpCollage(college);

        edu.setMessage("master created");
        edu.setFlag(true);

        edu.getMastersId().add(idNumber);
        Edu.getUsers().add(this);

        DataAccess.saveCore();
        DataAccess.dumpUser(this);
        Logger.logEvent(this, "constructor", edu.getMessage(),
                new Object[]{this}, LogType.actionDone);

    }

    public LinkedList<Course> getTempCourses(boolean isFromServer){
        LinkedList<Course> result = new LinkedList<>();

        if(isFromServer) {
            Edu edu = Edu.getInstance();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                if (course.isMarkRegistered() && !course.isFinalRegistered()) result.add(course);
            }
        } else{
            EduPublicInfo edu = Controller.getInstance().getOfflineData();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                if (course.isMarkRegistered() && !course.isFinalRegistered()) result.add(course);
            }
        }
        return result;
    }

    public ServerResponse editMaster(String phoneNo, String roomNo, String email,
                              String masterDegree, boolean chancellor, boolean active, User functor){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if (functor == null || functor.getCollegeId() != this.getCollegeId()) {
            response.setServerMessage("You can't change this master info");
            response.setFlag(false);
            return response;
        }

        try {
            Integer room = null;
            if(roomNo != null && !roomNo.equals("")) room = Integer.parseInt(roomNo);

            if (masterDegree != null && !masterDegree.equals("")){
                if (!masterDegree.equalsIgnoreCase("associate") &&
                        !masterDegree.equalsIgnoreCase("assistant") &&
                        !masterDegree.equalsIgnoreCase("professor")) {
                    response.setServerMessage("not a valid master grade(associate, assistant or professor)");
                    response.setFlag(false);
                    return response;
                }
                this.setMasterDegree(masterDegree);
            }
            if(phoneNo != null && !phoneNo.equals("")) this.setPhoneNumber(phoneNo);
            if(email != null && !email.equals("")) this.setEmail(email);
            if(room != null) this.setRoom(room);

            if(chancellor) {
                if(isDean()){
                    response.setServerMessage("you can't prompt yourself as chancellor");
                    response.setFlag(false);
                    return response;
                }
                College college = Edu.getInstance().getCollegeById(this.getCollegeId());
                college.setChancellorId(this.getIdNumber());
            }
            this.setChancellor(chancellor);
            this.setActive(active);

            DataAccess.dumpUser(this);
            response.setServerMessage("master was edited");
            response.setFlag(true);

            Logger.logEvent(this, "editMaster", "master edited",
                    new Object[]{this}, LogType.actionDone );

            return response;

        } catch (Exception e){
            response.setServerMessage("Invalid input");
            Logger.logException(this, "editMaster", "input Exception");

            response.setFlag(false);
            return response;
        }
    }

    public ServerResponse deleteMaster(User functor){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if (functor == null || functor.getCollegeId() != this.getCollegeId()
        || dean || chancellor) {
            response.setServerMessage("You can't delete this master");
            response.setFlag(false);
            return response;
        }

        for(long studentId: studentsSupervisedId){
            Student student = (Student) (Edu.getInstance().getUserById(studentId));
            student.setSupervisorId(-1);
        }

        for (long courseId: coursesId){
            Course course = Edu.getInstance().getCourseById(courseId);
            course.setMasterId(-1);
        }

        Edu.getUsers().remove(this);
        Edu.getInstance().getMastersId().remove(this.getIdNumber());

        response.setFlag(true);
        response.setServerMessage("Master deleted");

        Logger.logEvent(this, "deleteMaster", "master deleted", new Object[]{this},
                LogType.actionDone);
        DataAccess.saveAllData();

        return response;
    }

    public LinkedList<Long> getCoursesId() {
        return coursesId;
    }

    public void setCoursesId(LinkedList<Long> coursesId) {
        this.coursesId = coursesId;
        DataAccess.dumpUser(this);
    }

    public boolean isChancellor() {
        return chancellor;
    }

    public void setChancellor(boolean chancellor) {
        this.chancellor = chancellor;
        DataAccess.dumpUser(this);

    }

    public boolean isDean() {
        return dean;
    }

    public void setDean(boolean dean) {
        this.dean = dean;
        DataAccess.dumpUser(this);
    }

    public String getMasterDegree() {
        return masterDegree;
    }

    public void setMasterDegree(String masterDegree) {
        this.masterDegree = masterDegree;
        DataAccess.dumpUser(this);

    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
        DataAccess.dumpUser(this);
    }

    public LinkedList<Long> getStudentsSupervisedId() {
        return studentsSupervisedId;
    }

    public void setStudentsSupervisedId(LinkedList<Long> studentsSupervisedId) {
        this.studentsSupervisedId = studentsSupervisedId;
        DataAccess.dumpUser(this);
    }

}
