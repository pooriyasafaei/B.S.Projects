package server.logic.users;

import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.Logger;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.messenger.TextBox;
import server.logic.request.Request;
import server.time.DateTime;
import server.logic.users.security.PasswordHashing;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

public class User {

    private String name;
    private String password;
    private String nationalId;
    private String email;
    private String phoneNumber;

    private int collegeId;

    private long idNumber;

    private String imagePathName;

    private DateTime lastSignIn;
    private DateTime birthDay;

    private boolean active;

    private int theme = 1;

    private LinkedList<TextBox> chats = new LinkedList<>();
    private LinkedList<Request> requests = new LinkedList<>();
    private LinkedList<Request> messages = new LinkedList<>();

    public User(String name, String password, String nationalId, int collegeId, long idNumber, DateTime birthDay) {
        Edu edu = Edu.getInstance();
        if(edu.getUserById(idNumber) != null){
            edu.setMessage("User with this id already exist");
            edu.setFlag(false);
            Logger.logException(this, "constructor", edu.getMessage());
            return;
        }

        if (!edu.getCollagesNumber().contains(collegeId)){
            edu.setMessage("College with this id doesn't exist");
            edu.setFlag(false);
            Logger.logException(this, "constructor", edu.getMessage());
            return;
        }

        this.messages = new LinkedList<>();
        this.name = name;
        this.password = PasswordHashing.generateHash(password);
        this.nationalId = nationalId;
        this.collegeId = collegeId;
        this.idNumber = idNumber;
        this.birthDay = birthDay;
        lastSignIn = new DateTime();

        File file = new File("image datas\\users\\" + idNumber + ".jpg");
        if(file.isFile()) imagePathName = "image datas\\users\\" + idNumber + ".jpg";

        else imagePathName = "image datas\\users\\default.jpg";

        this.active = true;
        Edu.getInstance().setFlag(true);
        chats.add(new TextBox(idNumber, 1));

    }

    public TextBox getChat(long contactId){
        for (TextBox textBox: chats) {
            if (textBox.getContactId() == contactId) return textBox;
        }
        return null;
    }

    public void addNewChat(TextBox textBox){
        chats.add(textBox);
        DataAccess.dumpUser(this);
    }

    public ServerResponse changeEmailAndPhone(String email, String phoneNumber){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

            if(email != null && !email.equals("")) {
            this.setEmail(email);
            response.setServerMessage("profile changed!") ;
            response.setFlag(true);
        }

        if(phoneNumber != null && !phoneNumber.equals("")) {
            this.setPhoneNumber(phoneNumber);
            response.setServerMessage("profile changed!") ;
            response.setFlag(true);
        }
        return response;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        DataAccess.dumpUser(this);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = PasswordHashing.generateHash(password);
        this.setLastSignIn(new DateTime());
        DataAccess.dumpUser(this);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        DataAccess.dumpUser(this);

    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        DataAccess.dumpUser(this);

    }

    public int getCollegeId() {
        return collegeId;
    }

    public void setCollegeId(int collegeId) throws IOException {
        this.collegeId = collegeId;
        DataAccess.dumpUser(this);

    }

    public long getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(long idNumber) throws IOException {
        this.idNumber = idNumber;
        DataAccess.dumpUser(this);

    }

    public String getImagePathName() {
        File file = new File("image datas\\users\\" + idNumber + ".jpg");
        if(file.isFile()) imagePathName = "image datas\\users\\" + idNumber + ".jpg";

        else imagePathName = "image datas\\users\\default.jpg";
        return imagePathName;
    }

    public void setImagePathName(String imagePathName){
        this.imagePathName = imagePathName;
        DataAccess.dumpUser(this);

    }

    public DateTime getLastSignIn() {
        return lastSignIn;
    }

    public void setLastSignIn(DateTime lastSignIn) {
        this.lastSignIn = lastSignIn;
        DataAccess.dumpUser(this);

    }

    public DateTime getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(DateTime birthDay) throws IOException {
        this.birthDay = birthDay;
        DataAccess.dumpUser(this);

    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
        DataAccess.dumpUser(this);

    }

    public Request getReq(long requestId){
        for(Request req: getRequests()){
            if(req.getRequestId() == requestId)
                return req;
        }
        for(Request req: getMessages()){
            if(req.getRequestId() == requestId)
                return req;
        }
        return null;
    }

    public LinkedList<Request> getRequests() {
        return requests;
    }

    public void setRequests(LinkedList<Request> requests) {
        this.requests = requests;
        DataAccess.dumpUser(this);
    }

 //   public ImageIcon getImage(){return new ImageIcon(imagePathName);}

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public int getTheme() {
        return theme;
    }

    public void setTheme(int theme) {
        this.theme = theme;
        DataAccess.dumpUser(this);
    }

    public LinkedList<TextBox> getChats() {
        return chats;
    }

    public void setChats(LinkedList<TextBox> chats) {
        DataAccess.dumpUser(this);
        this.chats = chats;
    }

    public LinkedList<Request> getMessages() {
        return messages;
    }

    public void setMessages(LinkedList<Request> messages) {
        this.messages = messages;
        DataAccess.dumpUser(this);
    }
}
