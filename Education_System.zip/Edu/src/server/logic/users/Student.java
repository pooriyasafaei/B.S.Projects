package server.logic.users;

import client.controller.Controller;
import communication.public_info.EduPublicInfo;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.colleges.College;
import server.logic.courses.Course;
import server.logic.courses.Protest;
import server.logic.main_data.Edu;
import server.logic.main_data.data_communication.DataAccess;
import server.time.DateTime;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;

public class Student extends User{

    private long supervisorId;
    private LinkedList<Long> coursesId = new LinkedList<>();
    private boolean registerAllowed;

    private String eduStatus;

    private boolean masters;
    private boolean phd;
    private int enteringYear;
    private DateTime registerTime;

    private HashSet<Long> temporaryEnrolledCourses = new HashSet<>();
    private HashSet<Long> markedCourses = new HashSet<>();
    private HashSet<Long> assistantCourses = new HashSet<>();


    public Student(String name, String password, String nationalId, int collegeId, long idNumber,
                   DateTime birthDay, long supervisorId, boolean registerAllowed, String eduStatus,
                   boolean masters, boolean phd, int enteringYear, DateTime registerTime) {

        super(name,  password, nationalId, collegeId, idNumber, birthDay);
        Edu edu = Edu.getInstance();
        if(!edu.isFlag()) return;

        if(!edu.getMastersId().contains(supervisorId)){
            edu.setMessage("Supervisor master with this id doesn't exist");
            Logger.logException(this, "constructor", edu.getMessage());
            edu.setFlag(false);
            return;
        }

        this.supervisorId = supervisorId;
        this.registerAllowed = registerAllowed;
        this.eduStatus = eduStatus;
        this.masters = masters;
        this.phd = phd;
        this.enteringYear = enteringYear;
        this.registerTime = registerTime;

        temporaryEnrolledCourses = new HashSet<>();
        markedCourses = new HashSet<>();
        coursesId = new LinkedList<>();

        College college = edu.getCollegeById(collegeId);
        college.getStudentsId().add(idNumber);
        DataAccess.dumpCollage(college);

        Master master = (Master) (edu.getUserById(supervisorId));
        master.getStudentsSupervisedId().add(idNumber);
        DataAccess.dumpUser(master);

        edu.getStudentsId().add(idNumber);
        Edu.getUsers().add(this);
        DataAccess.dumpUser(this);

        DataAccess.saveCore();

        edu.setMessage("student created");
        edu.setFlag(true);
        Logger.logEvent(this, "constructor", edu.getMessage(),
                new Object[]{this}, LogType.actionDone);


    }

    public ServerResponse editStudent(String phoneNo, String entryYear, String email,
                               String eduLevelDegree, String supervisorId, String registerTime,
                               boolean active, boolean registerAllowed, User functor){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Edu edu = Edu.getInstance();
        if (functor == null || functor.getCollegeId() != this.getCollegeId()) {
            response.setServerMessage("You can't change this student info");
            response.setFlag(false);
            return response;
        }

        try {
            Integer entry = null;
            Long supervisor = null;
            DateTime reg = null;
            if(entryYear != null && !entryYear.equals("")) entry = Integer.parseInt(entryYear);
            if(supervisorId != null && !supervisorId.equals("")) supervisor = Long.parseLong(supervisorId);
            if(registerTime != null && !registerTime.equals("")) reg = DateTime.toDateTime(registerTime);
            if(!edu.getMastersId().contains(supervisor)){

                response.setServerMessage("Master supervisor with this id doesn't exist");
                response.setFlag(false);
                return response;
            }

            if (eduLevelDegree != null && !eduLevelDegree.equals("")){
                if (!eduLevelDegree.equalsIgnoreCase("masters") &&
                        !eduLevelDegree.equalsIgnoreCase("bachelor") &&
                        !eduLevelDegree.equalsIgnoreCase("phd")) {

                    response.setServerMessage("not a valid master grade(associate, assistant or professor)");
                    response.setFlag(false);
                    return response;
                }
                if(eduLevelDegree.equalsIgnoreCase("bachelor")){
                    this.masters = false;
                    this.phd = false;
                }
                if(eduLevelDegree.equalsIgnoreCase("masters")){
                    this.masters = true;
                    this.phd = false;
                }
                if(eduLevelDegree.equalsIgnoreCase("phd")){
                    this.masters = false;
                    this.phd = true;
                }
            }

            if(phoneNo != null && !phoneNo.equals("")) this.setPhoneNumber(phoneNo);
            if(email != null && !email.equals("")) this.setEmail(email);
            if(entry != null) this.setEnteringYear(entry);
            if(supervisor != null) this.setSupervisorId(supervisor);
            if (reg != null) this.registerTime = reg;

            temporaryEnrolledCourses = new HashSet<>();
            markedCourses = new HashSet<>();
            assistantCourses = new HashSet<>();

            this.setActive(active);
            this.registerAllowed = registerAllowed;

            Logger.logEvent(this, "editStudent", "student edited",
                    new Object[]{this}, LogType.actionDone );

            DataAccess.dumpUser(this);

            response.setServerMessage("student was edited");
            response.setFlag(true);
            return response;

        } catch (Exception e){
            response.setServerMessage("Invalid input");
            Logger.logException(this, "actionPerformed", "inputs Exception");
            response.setFlag(false);

            return response;
        }
    }

    public LinkedList<Course> getTempCourses(boolean isFromServer){
        LinkedList<Course> result = new LinkedList<>();

        if(isFromServer) {
            Edu edu = Edu.getInstance();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                if (course.isMarkRegistered() && !course.isFinalRegistered()) result.add(course);
            }
        } else{
            EduPublicInfo edu = Controller.getInstance().getOfflineData();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                if (course.isMarkRegistered() && !course.isFinalRegistered()) result.add(course);
            }
        }
        return result;
    }

    public LinkedList<Protest> getProtests(boolean isFromServer){
        LinkedList<Protest> result = new  LinkedList<>();
        for (Course course: getTempCourses(isFromServer)){
            Protest protest = course.getStudentProtest(this.getIdNumber());
            if (protest == null) continue;
            result.add(protest);
        }
        return result;
    }

    public ServerResponse makeProtest(long courseId, String text){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        Course course = Edu.getInstance().getCourseById(courseId);
        if(course == null){
            response.setServerMessage("course with that id doesn't exist");
            response.setFlag(false);
            return response;
        }

        if(course.isFinalRegistered() || !course.isMarkRegistered() ||
                !course.getStudentsMark().containsKey(this.getIdNumber())){
            response.setServerMessage("you can't protest to this course");
            response.setFlag(false);
            return response;
        }

        Protest protest = course.getStudentProtest(this.getIdNumber());

        if(protest != null) protest.setRequestText(text);
        else {
            protest = new Protest(courseId, this.getIdNumber(), text);
        }

        response.setServerMessage("protest sent for master");

        Logger.logEvent(this, "makeProtest", response.getServerMessage(),
                new Object[]{protest}, LogType.actionDone);

        DataAccess.dumpCourse(course);

        response.setFlag(true);
        return response;
    }

    public double getAverageGrade(boolean isFromServer){
        int i = 0;
        double average = 0.0;


        if(isFromServer){
            Edu edu = Edu.getInstance();

            for (long courseId : coursesId) {
                Course course = edu.getCourseById(courseId);
                if (course == null) {
                    coursesId.remove(courseId);
                    continue;
                }

                if (!course.isMarkRegistered()) continue;

                average += course.getUnits() * course.getMark(getIdNumber());
                i += course.getUnits();
            }
        } else{
            EduPublicInfo edu = Controller.getInstance().getOfflineData();
            for (long courseId : coursesId) {
                Course course = edu.getCourseById(courseId);
                if (course == null) {
                    coursesId.remove(courseId);
                    continue;
                }

                if (!course.isMarkRegistered()) continue;

                average += course.getUnits() * course.getMark(getIdNumber());
                i += course.getUnits();
            }
        }

        if(i == 0) return 0;
        return average / i;
    }

    public int getUnitsPassed(boolean isFromServer){
        int i = 0;

        if(isFromServer){
            Edu edu = Edu.getInstance();

            for (long courseId : coursesId) {
                Course course = edu.getCourseById(courseId);
                if (course == null) {
                    coursesId.remove(courseId);
                    continue;
                }

                if (!course.isMarkRegistered()) continue;

                i += course.getUnits();
            }
        }else {
            EduPublicInfo edu = Controller.getInstance().getOfflineData();

            for (long courseId : coursesId) {
                Course course = edu.getCourseById(courseId);
                if (course == null) {
                    coursesId.remove(courseId);
                    continue;
                }

                if (!course.isMarkRegistered()) continue;

                i += course.getUnits();

            }
        }
        return i;
    }

    public long getSupervisorId() {
        return supervisorId;
    }

    public void setSupervisorId(long supervisorId) {
        if(this.supervisorId > 0){
            Master master = ((Master)Edu.getInstance().getUserById(this.getSupervisorId()));
            master.getStudentsSupervisedId().remove(this.getIdNumber());
            DataAccess.dumpUser(master);
        }
        Master master =  ((Master)Edu.getInstance().getUserById(supervisorId));
        master.getStudentsSupervisedId().add(this.getIdNumber());

        this.supervisorId = supervisorId;
        DataAccess.dumpUser(this);
        DataAccess.dumpUser(master);
    }

    public LinkedList<Long> getCoursesId() {
        return coursesId;
    }

    public void setCoursesId(LinkedList<Long> coursesId) {
        this.coursesId = coursesId;
        DataAccess.dumpUser(this);
    }

    public boolean isRegisterAllowed() {
        return registerAllowed;
    }

    public void setRegisterAllowed(boolean registerAllowed) {
        this.registerAllowed = registerAllowed;
        DataAccess.dumpUser(this);
    }

    public String getEduStatus() {
        return eduStatus;
    }

    public void setEduStatus(String eduStatus) {
        this.eduStatus = eduStatus;
        DataAccess.dumpUser(this);
    }

    public int getEnteringYear() {
        return enteringYear;
    }

    public void setEnteringYear(int enteringYear) {
        this.enteringYear = enteringYear;
    }

    public boolean isMasters() {
        return masters;
    }

    public void setMasters(boolean masters) throws IOException {
        this.masters = masters;
        DataAccess.dumpUser(this);
    }

    public boolean isPhd() {
        return phd;
    }

    public void setPhd(boolean phd) {
        this.phd = phd;
        DataAccess.dumpUser(this);
    }

    public LinkedList<Course> getAllCoursesList(boolean isFromServer){
        LinkedList<Course> result = new LinkedList<>();
        if(isFromServer){
            Edu edu = Edu.getInstance();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                result.add(course);
            }
        }else {
            EduPublicInfo edu = Controller.getInstance().getOfflineData();

            for (long id : coursesId) {
                Course course = edu.getCourseById(id);
                if (course == null) continue;
                result.add(course);
            }
        }

        return result;
    }

    public DateTime getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(DateTime registerTime) {
        this.registerTime = registerTime;
        DataAccess.dumpUser(this);
    }

    public HashSet<Long> getTemporaryEnrolledCourses() {
        return temporaryEnrolledCourses;
    }

    public void setTemporaryEnrolledCourses(HashSet<Long> temporaryEnrolledCourses) {
        this.temporaryEnrolledCourses = temporaryEnrolledCourses;
    }

    public HashSet<Long> getMarkedCourses() {
        return markedCourses;
    }

    public void setMarkedCourses(HashSet<Long> markedCourses) {
        this.markedCourses = markedCourses;
        DataAccess.dumpUser(this);
    }

    public HashSet<Long> getAssistantCourses() {
        return assistantCourses;
    }

    public void setAssistantCourses(HashSet<Long> assistantCourses) {
        this.assistantCourses = assistantCourses;
    }
}
