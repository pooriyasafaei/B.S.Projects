package server.time;

import server.logic.courses.Course;
import server.logic.messenger.TextBox;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Date;
import java.util.LinkedList;

public class DateTime {

    private long millis;

    private final int year;
    private final int month;
    private final int day;

    private final int hour;
    private final int minute;
    private final int second;

    private static final int expireTime = 10800;

    public DateTime() {
        Date millis = new Date();
        this.millis = millis.getTime();
        Clock clock = generateClock();
        String[] s = ((clock.instant()).toString()).split("T");

        String[] date = s[0].split("-");
        this.year = Integer.parseInt(date[0]);
        this.month = Integer.parseInt(date[1]);
        this.day = Integer.parseInt(date[2]);

        String[] time = s[1].split(":");
        this.hour = Integer.parseInt(time[0]);
        this.minute = Integer.parseInt(time[1]);
        this.second = (int) Double.parseDouble(time[2].substring(0,2));



    }

    public DateTime(int year, int month, int day, int hour, int minute, int second) {
        Date date = new Date();
        this.millis = date.getTime();
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
        this.second = second;

    }

    public static DateTime toDateTime(String string) throws Exception{
            String[] date = string.split("/");
            int year = Integer.parseInt(date[0]);
            int month = Integer.parseInt(date[1]);
            int day = Integer.parseInt(date[2].split(" ")[0]);

            String[] time = date[2].split(" ")[1].split(":");
            int hr = Integer.parseInt(time[0]);
            int min = Integer.parseInt(time[1]);

            return new DateTime(year, month, day, hr, min, 0);
    }

    private Clock generateClock(){
        Clock c = Clock.systemUTC();
        Duration d = Duration.ofHours(5);
        return  Clock.offset(c, d);
    }

    public static String getDateTime(){
        return (new DateTime()).toString();
    }

    public static String getDateTimeNoSec(DateTime dateTime){
        String year = dateTime.year + "";
        String month = dateTime.month + "";
        if (dateTime.month < 10) month = "0" + month;
        String day = dateTime.day + "";
        if (dateTime.day < 10) day = "0" + day;

        String hr = dateTime.hour + "";
        if (dateTime.hour < 10) hr = "0" + hr;
        String min = dateTime.minute + "";
        if (dateTime.minute < 10) min = "0" + min;
        String sec = dateTime.second + "";
        if (dateTime.second < 10) sec = "0" + sec;

        return   year + "/" + month + "/" + day + " " + hr + ":" + min  ;
    }

    public static boolean isEnrollTime(DateTime enrollTime){
        try {
            DateTime dateTime = new DateTime();

            return (enrollTime.year == dateTime.year && enrollTime.month == dateTime.month &&
                    enrollTime.day == dateTime.day && enrollTime.hour == dateTime.hour);

        }catch (Exception e){
            return false;
        }
    }

    @Override
    public boolean equals(Object object){
        try {
            DateTime dateTime = (DateTime) object;

            return (this.year == dateTime.year && this.month == dateTime.month && this.day == dateTime.day &&
                    this.hour == dateTime.hour && this.minute == dateTime.minute && this.second == dateTime.second);

        }catch (Exception e){
            return false;
        }
    }

    @Override
    public  String toString(){
        DateTime d = this;
        String year = d.year + "";
        String month = d.month + "";
        if (d.month < 10) month = "0" + month;
        String day = d.day + "";
        if (d.day < 10) day = "0" + day;

        String hr = d.hour + "";
        if (d.hour < 10) hr = "0" + hr;
        String min = d.minute + "";
        if (d.minute < 10) min = "0" + min;
        String sec = d.second + "";
        if (d.second < 10) sec = "0" + sec;

        return   year + "/" + month + "/" + day + " " + hr + ":" + min + ":" + sec  ;
    }

    public static void main(String[] args) {
//        Date date = new Date();
//        System.out.println(date.getTime());
//        Clock c = Clock.systemDefaultZone();
//        System.out.println(c.instant());
//        Time client.time = new Time(date.getTime());
//        System.out.println(client.time);

        DateTime dateTime = new DateTime();
        System.out.println(dateTime.hour +":"+ dateTime.minute + ":" + dateTime.second);
        System.out.println(dateTime.year + "/" + dateTime.month + "/" + dateTime.day);
        System.out.println(dateTime.hasExpired());
    }

    public static boolean isFirstLaterThanSecond(DateTime date1, DateTime date2){
        if (date1.year > date2.year) return true;
        if (date1.year < date2.year) return false;

        if (date1.month > date2.month) return true;
        if (date1.month < date2.month) return false;

        if (date1.day > date2.day) return true;
        if (date1.day < date2.day) return false;

        if (date1.hour > date2.hour) return true;
        if (date1.hour < date2.hour) return false;

        return date1.minute > date2.minute;
    }

    public static LinkedList<Course> sortCoursesByExamTime(LinkedList<Course> courses) {
        LinkedList<Course> result = new LinkedList<>(courses);

        for (int i = 1; i < result.size(); ++i) {

            Course key = result.get(i);
            int j = i - 1;

            while (j >= 0 && isFirstLaterThanSecond(result.get(j).getExamTime() ,key.getExamTime())) {
                result.set(j + 1, result.get(j));
                j = j - 1;
            }
            result.set(j + 1, key);
        }
        return result;
    }

    public static LinkedList<TextBox> sortChatsByTime(LinkedList<TextBox> textBoxes) {
        LinkedList<TextBox> result = new LinkedList<>(textBoxes);

        for (int i = 1; i < result.size(); ++i) {

            TextBox key = result.get(i);
            int j = i - 1;

            while (j >= 0 && isFirstLaterThanSecond(key.getLastMessageTime(), result.get(j).getLastMessageTime())){
                result.set(j + 1, result.get(j));
                j = j - 1;
            }
            result.set(j + 1, key);
        }
        return result;
    }

    public boolean hasExpired(){
        DateTime refreshed = new DateTime();
        if(this.year < refreshed.year || this.month < refreshed.month || this.day < refreshed.day ) return true;
        return (3600 * refreshed.hour + 60 * refreshed.minute + refreshed.second) -
                ((3600 * this.hour + 60 * this.minute + this.second)) > expireTime;
    }

    public long getMillis() {
        return millis;
    }

    public void setMillis(long millis) {
        this.millis = millis;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getSecond() {
        return second;
    }
}
