package server.time;

import java.util.HashSet;
import java.util.Set;

public class TimeInWeek {

    private DateTime startTime;
    private DateTime endTime;
    private final Set<Days> days = new HashSet<>();

    public static boolean hasCollision(TimeInWeek t1, TimeInWeek t2){

        boolean collision = false;
        for (Days day1: t1.days) {
            for (Days day2: t2.days) {
                if(collision) return true;

                if(!day1.equals(day2)) continue;

                if (t1.startTime.getHour() > t2.endTime.getHour() || t2.startTime.getHour() > t1.endTime.getHour())
                    continue;

                if (t2.startTime.getHour() == t1.endTime.getHour()) {
                    collision = !(t2.startTime.getMinute() >= t1.endTime.getMinute());
                    continue;
                }

                if (t1.startTime.getHour() == t2.endTime.getHour()) {
                    collision = !(t1.startTime.getMinute() >= t2.endTime.getMinute());
                    continue;
                }

                return true;
            }
        }
        return false;
    }

    public static TimeInWeek makeTimeFromString(String string){
        TimeInWeek timeInWeek = new TimeInWeek();

        String[] time = string.split("\\|");
        for (String day: time[0].split(",")) {
            timeInWeek.getDays().add(Days.valueOf(day));
        }

        String[] hours = time[1].split("to");
        timeInWeek.setStartTime(new DateTime(0,0,0,
                Integer.parseInt(hours[0].split(":")[0]), Integer.parseInt(hours[0].split(":")[1]),0));

        timeInWeek.setEndTime(new DateTime(0,0,0,
                Integer.parseInt(hours[1].split(":")[0]), Integer.parseInt(hours[1].split(":")[1]),0));

        return timeInWeek;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (Days day: days) {
            sb.append(day.name()).append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append("|");
        sb.append(startTime.getHour()).append(":").append(startTime.getMinute()).append("to").
                append(endTime.getHour()).append(":").append(endTime.getMinute());

        return sb.toString();
    }

    public DateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(DateTime startTime) {
        this.startTime = startTime;
    }

    public DateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(DateTime endTime) {
        this.endTime = endTime;
    }

    public Set<Days> getDays() {
        return days;
    }
}

enum Days{
    saturday, sunday, monday, tuesday, wednesday, thursday, friday
}
