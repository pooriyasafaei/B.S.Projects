package server.controller;

import properties.Props;
import server.logic.main_data.Edu;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ServerRunner {

    private static int port;
    private static int dataPort;

    private static ServerSocket mainSocket;
    private static ServerSocket dataSocket;

    private static ServerStatus status = ServerStatus.Waiting;
    private static List<ClientController> controllers = new ArrayList<>();

    private static final String propPath = Props.SERVER_PROPRERTIES_PATH;
    private static final Properties properties = new Properties();

    public static void start(){
        try {
            InputStream inputStream = new FileInputStream(Paths.get(propPath).toFile());
            properties.load(inputStream);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        port = Integer.parseInt(properties.getProperty("server_port"));
        dataPort = Integer.parseInt(properties.getProperty("server_data_port"));
        try {
            mainSocket = new ServerSocket(port);
            dataSocket = new ServerSocket(dataPort);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(mainSocket == null || dataSocket == null) {
            status = ServerStatus.Failed;
            System.out.println("Running server failed");
            return;
        }

        Edu.startSystem();
        System.out.println("Server is running");

        (new Thread(ServerRunner::listen)).start();

    }

    private static void listen(){
        status = ServerStatus.Listening;
        try {
            while (status == ServerStatus.Listening) {
                final Socket connection = mainSocket.accept();
                Runnable client = () -> controllers.add(new ClientController(connection));
                System.out.println("client " + connection.getRemoteSocketAddress() + " connected");
                client.run();
            }
        }catch (IOException e) {
            e.printStackTrace();
            status = ServerStatus.Failed;
        }
    }

    public static void removeController(ClientController controller){
        controllers.remove(controller);
    }

    public static int getPort() {
        return port;
    }

    public static void setPort(int port) {
        ServerRunner.port = port;
    }

    public static int getDataPort() {
        return dataPort;
    }

    public static void setDataPort(int dataPort) {
        ServerRunner.dataPort = dataPort;
    }

    public static ServerSocket getMainSocket() {
        return mainSocket;
    }

    public static void setMainSocket(ServerSocket mainSocket) {
        ServerRunner.mainSocket = mainSocket;
    }

    public static ServerSocket getDataSocket() {
        return dataSocket;
    }

    public static void setDataSocket(ServerSocket dataSocket) {
        ServerRunner.dataSocket = dataSocket;
    }

    public static ServerStatus getStatus() {
        return status;
    }

    public static void setStatus(ServerStatus status) {
        ServerRunner.status = status;
    }

    public static List<ClientController> getControllers() {
        return controllers;
    }

    public static void setControllers(List<ClientController> controllers) {
        ServerRunner.controllers = controllers;
    }

    public static Properties getProperties(){
        return properties;
    }
}

enum ServerStatus{
    Waiting, Listening, Failed
}
