package server.controller;

import client.controller.support.Message;
import client.gui.edu_services.request.RequestType;
import com.google.gson.Gson;
import communication.client.ClientRequest;
import communication.PageType;
import communication.client.ClientRequestType;
import communication.encoders.FileEncode;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import server.logger.LogType;
import server.logger.Logger;
import server.logic.courses.Course;
import server.logic.courses.cw.*;
import server.logic.main_data.Edu;
import communication.public_info.EduPublicInfo;
import server.logic.main_data.data_communication.DataAccess;
import server.logic.messenger.TextBox;
import server.logic.request.Request;
import server.logic.users.Master;
import server.logic.users.Student;
import server.logic.users.User;
import server.time.DateTime;
import server.time.TimeInWeek;

import java.io.File;
import java.util.HashSet;
import java.util.LinkedList;

public class Library {

    private ClientController controller;
    private User user;

    public void login(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Login);
        try{
            response = Edu.getInstance().
                    logIn((Long) request.readData("id"), (String) request.readData("password"));
        } catch (Exception e){
            e.printStackTrace();
            response = new ServerResponse(ServerResponseType.Failed);
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        if(response.isFlag()){
            User user = Edu.getInstance().getUserById((Long)request.readData("id"));
            this.user = user;
            controller.setUserLoggedIn(user);
            response.addData("offline_data", (new Gson()).toJson(EduPublicInfo.makePublicInfoCopy()));

        }

        controller.sendMessage(response);

    }

    public void logout(){
        Logger.logEvent(this, "logOut", "Logged out"
                , new Object[]{controller.getUserLoggedIn()}, LogType.actionDone);

        if(controller.getUserLoggedIn() != null) DataAccess.dumpUser(controller.getUserLoggedIn());

        controller.setUserLoggedIn(null);
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        response.setFlag(true);

        controller.sendMessage(response);
    }

    public void sendMainMenuPage(){

        ServerResponse mainMenu = new ServerResponse(ServerResponseType.PageData);

        mainMenu.addData("picture", new FileEncode(user.getImagePathName()));

        if(user instanceof Student){
            mainMenu.setPage(PageType.StudentMainMenuPage);
            mainMenu.addData("supervisor", Edu.getInstance().getUserById(((Student)user).getSupervisorId()).getName());
        }

        mainMenu.addData("offline_data", (new Gson()).toJson(EduPublicInfo.makePublicInfoCopy()));
        if(controller.getUserLoggedIn() != null)mainMenu.addData("user", controller.getUserLoggedIn().getIdNumber());
        controller.sendMessage(mainMenu);
    }

    public void changePassword(String password){
        controller.getUserLoggedIn().setPassword(password);
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        response.setFlag(true);
        response.setServerMessage("password changed");

        controller.sendMessage(response);
    }

    public void deleteMaster(Long masterId){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Master master = (Master) Edu.getInstance().getUserById(masterId);

        if(master == null){
            response.setServerMessage("master doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = master.deleteMaster(controller.getUserLoggedIn());
        controller.sendMessage(response);

    }

    public void editMaster(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Master master = (Master) Edu.getInstance().getUserById((Long) request.readData("masterId"));

        if(master == null){
            response.setServerMessage("master doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = master.editMaster((String) request.readData("phoneNo"), (String) request.readData("roomNo"),
                (String) request.readData("email"), (String) request.readData("masterDegree"),
                (Boolean) request.readData("chancellor"),(Boolean) request.readData("active"),
                controller.getUserLoggedIn());


        controller.sendMessage(response);

    }

    public void addMaster(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        new Master((String) request.readData("name"), (String) request.readData("password"),
                (String) request.readData("nationalId"), (Integer) request.readData("collegeId"),
                (Long) request.readData("idNumber"),(DateTime) request.readData("birthDay"),
                (String) request.readData("masterDegree"), (Boolean) request.readData("chancellor"),
                (Boolean) request.readData("dean"), (Integer) request.readData("room")
        );

        response.setServerMessage(Edu.getInstance().getMessage());
        controller.sendMessage(response);

    }

    public void editCourse(ClientRequest request){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        if(course == null){
            response.setServerMessage("course doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = course.editCourse((String) request.readData("courseName"),(String) request.readData("timeInWeek"),
                (String)request.readData("examTime"), (String) request.readData("masterId"),
                (String)request.readData("units"), controller.getUserLoggedIn());

        controller.sendMessage(response);

    }

    public void addCourse(ClientRequest request){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        new Course((String) request.readData("name")
                , (Long) request.readData("masterId"),(Integer) request.readData("units"),
                (Long) request.readData("id"), (Integer) request.readData("collegeId"),
                (TimeInWeek) request.readData("timeInWeek"), (DateTime) request.readData("examTime"),
                (LinkedList<Long>) request.readData("assistants"), (LinkedList<Long>) request.readData("prerequisites"),
                (LinkedList<Long>) request.readData("necessities"), (String) request.readData("section"),
                (Integer) request.readData("semester"), (Integer) request.readData("capacity"),
                (Integer) request.readData("group"));

        response.setServerMessage(Edu.getInstance().getMessage());
        controller.sendMessage(response);

    }

    public void deleteCourse(Long courseId){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Course course = Edu.getInstance().getCourseById(courseId);

        if(course == null){
            response.setServerMessage("course doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = course.deleteCourse(controller.getUserLoggedIn());
        controller.sendMessage(response);
    }

    public void addStudent(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        new Student((String) request.readData("name"), (String) request.readData("password"),
                (String) request.readData("nationalId"), (Integer) request.readData("collegeId"),
                (Long) request.readData("idNumber"),(DateTime) request.readData("birthDay"),
                (Long) request.readData("supervisorId"), (Boolean) request.readData("registerAllowed"),
                (String) request.readData("eduStatus"), (Boolean) request.readData("masters"),
                (Boolean) request.readData("phd"), (Integer) request.readData("enteringYear"),
                (DateTime) request.readData("registerTime")
        );

        response.setServerMessage(Edu.getInstance().getMessage());
        controller.sendMessage(response);
    }

    public void editMark(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        if(course == null){
            response.setServerMessage("course with that id doesn't exist");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        response = course.editMark((Long) request.readData("studentId"), (Double) request.readData("mark"));
        controller.sendMessage(response);
    }

    public void registerCourse(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        if(course == null){
            response.setServerMessage("course with that id doesn't exist");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        response = course.registerCourse();
        controller.sendMessage(response);
    }

    public void responseProtest(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        if(course == null){
            response.setServerMessage("course with that id doesn't exist");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        response = course.responseProtest((String) request.readData("studentId"), (String) request.readData("newMark")
                , (String) request.readData("response"));

        controller.sendMessage(response);
    }

    public void makeProtest(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Student student = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));

        if(student == null){
            response.setServerMessage("student with that id doesn't exist");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        response = student.makeProtest((Long) request.readData("courseId"), (String) request.readData("text"));

        controller.sendMessage(response);
    }

    public void editStudent(ClientRequest request){

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Student student = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));

        if(student == null){
            response.setServerMessage("student doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = student.editStudent((String) request.readData("phoneNo"), (String) request.readData("entryYear"),
                (String) request.readData("email"), (String) request.readData("eduLevelDegree"),
                (String) request.readData("supervisorId"), (String) request.readData("registerTime"),
                (Boolean) request.readData("active"), (Boolean) request.readData("registerAllowed"),
                controller.getUserLoggedIn());

        controller.sendMessage(response);
    }

    public void determineRequestResult(ClientRequest request) {
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Request theRequest = (controller.getUserLoggedIn().getReq((Long) request.readData("requestId")));

        if(theRequest == null){
            response.setServerMessage("request doesn't exist");
            controller.sendMessage(response);
            return;
        }

        theRequest.determineResult((Long) request.readData("acceptorId"), (Boolean) request.readData("isAccepted")
                , (String) request.readData("message"));

        response.setFlag(true);
        response.setServerMessage("registered");

        controller.sendMessage(response);
    }

    public void addNewRequest(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action) ;

        switch ((RequestType) request.readData("requestType")) {

            case Dorm -> Request.makeDorm((Long) request.readData("studentId"), (String) request.readData("text"));

            case Minor -> Request.makeMinor((Long) request.readData("studentId"), (Long) request.readData("chancellorId"),
                    (String) request.readData("text"));

            case QuitStudy -> Request.makeStudyQuit((Long) request.readData("studentId"));

            case Recommendation -> Request.makeRecommendationReq((Long) request.readData("studentId"),
                    (Long) request.readData("masterId"), (String) request.readData("text"));

            case StudyCertificate -> Request.makeStudyCertificate((Long) request.readData("studentId"));

            case ThesisDefenceTime -> Request.makeThesisDefenceTime
                    ((Long) request.readData("studentId"), (String) request.readData("text"));

            case ChatRequest -> Request.chatRequest
                    ((Long) request.readData("senderId"), (Long) request.readData("receiverId"), "");

            case EnrollCourse -> Request.enrollCourseRequest((Long) request.readData("studentId"),
                        (Long) request.readData("chancellorId"), String.valueOf((Long) request.readData("courseId")));

        }

        response.setServerMessage("request registered");
        controller.sendMessage(response);
    }

    public void changeEmailAndPhone(ClientRequest request){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if(controller.getUserLoggedIn() == null){
            response.setServerMessage("no user logged in");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        response = controller.getUserLoggedIn().changeEmailAndPhone
                ((String) request.readData("email"),(String) request.readData("phone"));

        controller.sendMessage(response);
    }

    private void reconnect(ClientRequest request) {
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        controller.setUserLoggedIn(Edu.getInstance().getUserById((Long) request.readData("id")));

        if(controller.getUserLoggedIn() == null){
            response.setFlag(false);
            response.setServerMessage("user doesn't exist");
            controller.sendMessage(response);
            return;
        }

        this.user = controller.getUserLoggedIn();
        response.setFlag(true);

        response.addData("offline_data", (new Gson()).toJson(EduPublicInfo.makePublicInfoCopy()));
        if(controller.getUserLoggedIn() != null)response.addData("user", controller.getUserLoggedIn().getIdNumber());
        controller.sendMessage(response);
    }

    private void sendPicture(Long id){
        ServerResponse picture = new ServerResponse(ServerResponseType.PageData);

        picture.addData("picture", new FileEncode(Edu.getInstance().getUserById(id).getImagePathName()));
        controller.sendMessage(picture);
    }

    private void sendMessage(ClientRequest request) {
        Message message = (Message) request.readData("message");
        TextBox senderBox = Edu.getInstance().getUserById(message.getSenderId()).getChat(message.getReceiverId());
        TextBox receiverBox = Edu.getInstance().getUserById(message.getReceiverId()).getChat(message.getSenderId());

        if(senderBox == null){
            Edu.getInstance().getUserById(message.getSenderId()).addNewChat(
                    new TextBox(message.getSenderId(), message.getReceiverId()));
            senderBox = Edu.getInstance().getUserById(message.getSenderId()).getChat(message.getReceiverId());
        }
        if(receiverBox == null){
            Edu.getInstance().getUserById(message.getReceiverId()).addNewChat
                    (new TextBox(message.getReceiverId(), message.getSenderId()));
            receiverBox = Edu.getInstance().getUserById(message.getReceiverId()).getChat(message.getSenderId());
        }

        DateTime sendTime = new DateTime();
        senderBox.addMessage(true, false, message.getMessage(), sendTime);
        receiverBox.addMessage(false, false, message.getMessage(), sendTime);

        DataAccess.dumpUser(Edu.getInstance().getUserById(message.getSenderId()));
        DataAccess.dumpUser(Edu.getInstance().getUserById(message.getReceiverId()));

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        response.setFlag(true);
        response.setServerMessage("");
        controller.sendMessage(response);
    }

    private void sendMedia(ClientRequest request) {
        long senderId = (Long) request.readData("senderId");
        long receiverId = (Long) request.readData("receiverId");

        TextBox senderBox = Edu.getInstance().getUserById(senderId).getChat(receiverId);
        TextBox receiverBox = Edu.getInstance().getUserById(receiverId).getChat(senderId);

        if(senderBox == null){
            Edu.getInstance().getUserById(senderId).addNewChat(new TextBox(senderId, receiverId));
            senderBox = Edu.getInstance().getUserById(senderId).getChat(receiverId);
        }
        if(receiverBox == null){
            Edu.getInstance().getUserById(receiverId).addNewChat(new TextBox(receiverId, senderId));
            receiverBox = Edu.getInstance().getUserById(receiverId).getChat(senderId);
        }

        FileEncode media = (FileEncode) request.readData("media");

        File f1 = new File(ServerRunner.getProperties().getProperty("media_folder") + senderId
                + "to" + receiverId);

        File f2 = new File(ServerRunner.getProperties().getProperty("media_folder") + receiverId
                + "to" + senderId);

        f1.mkdirs();
        f2.mkdirs();

        FileEncode.decodeStringToFile(media.getEncoded(), ServerRunner.getProperties().getProperty("media_folder")
                + senderId + "to" + receiverId +"\\" + media.getFileName());

        FileEncode.decodeStringToFile(media.getEncoded(), ServerRunner.getProperties().getProperty("media_folder")
                + receiverId + "to" + senderId +"\\" + media.getFileName());

        DateTime sendTime = new DateTime();
        senderBox.addMessage(true, true, media.getFileName(), sendTime);
        receiverBox.addMessage(false, true, media.getFileName(), sendTime);

        DataAccess.dumpUser(Edu.getInstance().getUserById(senderId));
        DataAccess.dumpUser(Edu.getInstance().getUserById(receiverId));

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        response.setFlag(true);
        response.setServerMessage("Media uploaded");
        controller.sendMessage(response);
    }

    private void getMedia(ClientRequest request) {
        Message message = (Message) request.readData("message");

        String path = ServerRunner.getProperties().getProperty("media_folder") + message.getReceiverId()
                + "to" +  message.getSenderId() + "\\" + message.getMessage().split(" ",2)[1];

        File file = new File(path);

        ServerResponse response = new ServerResponse(ServerResponseType.PageData);

        if(!file.isFile()){
            response.setFlag(false);
            response.setServerMessage("file doesn't exist");
            controller.sendMessage(response);
            return;
        }

        FileEncode media = new FileEncode(path);

        response.addData("media", media);
        response.setFlag(true);
        response.setServerMessage("Media downloaded");
        controller.sendMessage(response);
    }

    private void markOrUnmarkCourse(ClientRequest request) {
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        Student user = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));
        Boolean marked = (Boolean) request.readData("mark");
        if(marked) {
            user.getMarkedCourses().add((Long) request.readData("courseId"));
            response.setServerMessage("course marked");
        }
        else {
            user.getMarkedCourses().remove((Long) request.readData("courseId"));
            response.setServerMessage("course unmarked");
        }

        DataAccess.dumpUser(user);
        controller.sendMessage(response);
    }

    private void enrollCourse(ClientRequest request) {
        Student student = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        if(course == null || student == null){
            response.setFlag(false);
            response.setServerMessage("student or course doesn't exist");
            controller.sendMessage(response);
            return;
        }

        response = course.addStudent(student.getIdNumber(), (Boolean) request.readData("withCondition"));
        controller.sendMessage(response);
    }

    private void changeCourseGroup(ClientRequest request) {

        User user = Edu.getInstance().getUserById((Long) request.readData("studentId"));
        Course current = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Course newGroup = Edu.getInstance().getCourseById((Long) request.readData("newGroupId"));

        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if((Long) request.readData("newGroupId") == 0){
            if(current == null) {
                response.setFlag(false);
                response.setServerMessage("invalid course");
                controller.sendMessage(response);
                return;
            }

            controller.sendMessage(current.removeStudent((Long)request.readData("studentId")));
            return;
        }

        if(!(user instanceof Student student) || newGroup == null){
            response.setFlag(false);
            response.setServerMessage("invalid student or course");
            controller.sendMessage(response);
            return;
        }

        response = newGroup.addStudent(student.getIdNumber(), true);
        if(response.isFlag()){
            if(current != null) current.removeStudent(student.getIdNumber());
            response.setServerMessage("group changed");
            controller.sendMessage(response);
            return;
        }

        controller.sendMessage(response);
    }

    private void changeEnrollTime(ClientRequest request) {
        HashSet<Long> studentsIds = (HashSet<Long>) request.readData("studentIds");
        DateTime enrollTime = (DateTime) request.readData("enrollTime");

        for (Long id: studentsIds) {
            if(!(Edu.getInstance().getUserById(id) instanceof Student student)) continue;

            student.setRegisterTime(enrollTime);
        }

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        response.setServerMessage("enrollment time for students set");
        controller.sendMessage(response);
    }

    private void newContent(ClientRequest request) {
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));

        if(course == null){
            response.setServerMessage("course doesnt exist");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        Cw cw = course.getCourseware();
        String name = (String) request.readData("contentName");

        if(cw.getContent(name) != null){
            response.setServerMessage("content already exists");
            response.setFlag(false);
            controller.sendMessage(response);
            return;
        }

        cw.getContents().add(new EducationalContent(name, new DateTime()));
        DataAccess.dumpCourse(course);
        response.setFlag(true);
        controller.sendMessage(response);
    }

    private void addSubmission(ClientRequest request) {
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Student student = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));

        boolean isText = (Boolean) request.readData("isText");
        Homework homework = course.getCourseware().getHomework((String) request.readData("homeworkName"));
        ServerResponse response = new ServerResponse(ServerResponseType.Action);

        if(isText){
            homework.addSubmission(student.getIdNumber(), (String) request.readData("submission"), true);
            response.setServerMessage("answer submitted");

        }else {
            FileEncode fileEncode = (FileEncode) request.readData("submission");

            FileEncode.decodeStringToFile(fileEncode.getEncoded(), ServerRunner.getProperties().getProperty("cw_folder") +
                    course.getId() + "\\" + "homework\\" + homework.getName() + "\\" + student.getIdNumber() + "\\" +
                    fileEncode.getFileName());

            homework.addSubmission(student.getIdNumber(), fileEncode.getFileName(), false);
            response.setServerMessage("answer file uploaded");

        }

        DataAccess.dumpCourse(course);
        response.setFlag(true);
        controller.sendMessage(response);
    }

    private void addHomework(ClientRequest request, boolean isHomework) {
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Cw cw = course.getCourseware();
        String path = ServerRunner.getProperties().getProperty("cw_folder") + course.getId() +  "\\";

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        if(isHomework){
            String name = (String) request.readData("name");
            if (cw.getHomework(name) != null) {
                response.setFlag(false);
                response.setServerMessage("Homework with this name already exist");
                controller.sendMessage(response);
                return;
            }

            FileEncode file = (FileEncode) request.readData("file");
            FileEncode.decodeStringToFile(file.getEncoded(), path +"homework\\"+ name + "\\" + file.getFileName());

            cw.getHomeworks().add(new Homework(name, (Boolean) request.readData("isText"),
                    (String) request.readData("text"), (DateTime) request.readData("lastChange"),
                    (String) request.readData("info"), (DateTime) request.readData("deadline"),
                    (DateTime) request.readData("closeTime"), (Boolean) request.readData("answerText")));

            response.setServerMessage("homework added");

        } else {
            EducationalContent content = cw.getContent((String) request.readData("contentName"));
            String name = (String) request.readData("itemName");
            if(content.getItem(name) != null){
                response.setFlag(false);
                response.setServerMessage("Item with this name already exist");
                controller.sendMessage(response);
                return;
            }
            Content item;

            if((Boolean) request.readData("isText")){
                item = new Content((String) request.readData("itemName"), true,
                        (String) request.readData("text"), new DateTime());
                content.addItem(item);

            } else {
                item = new Content((String) request.readData("itemName"), false,
                        (String) request.readData("text"), new DateTime());
                content.addItem(item);

                FileEncode file = (FileEncode) request.readData("file");
                FileEncode.decodeStringToFile(file.getEncoded(), path +"edu_content\\" + content.getName() + "\\"
                        + ((String) request.readData("itemName")) + "\\" + file.getFileName());
            }

            response.setServerMessage("item added");
        }

        DataAccess.dumpCourse(course);
        response.setFlag(true);
        controller.sendMessage(response);
    }

    private void markSubmission(ClientRequest request) {
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Homework homework = course.getCourseware().getHomework((String) request.readData("homeworkName"));

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        try {
            homework.markSubmission((Integer)request.readData("submissionNumber"), (Integer)request.readData("mark"));
            response.setServerMessage("mark registered");
            response.setFlag(true);
        }catch (Exception exception){
            response.setServerMessage("invalid submission number for course");
            response.setFlag(true);
        }

        controller.sendMessage(response);
    }

    private void getEducationalFile(ClientRequest request, boolean isSubmission, boolean isHomework) {
        Course course = Edu.getInstance().getCourseById((Long)request.readData("courseId"));
        String path = ServerRunner.getProperties().getProperty("cw_folder") + course.getId() + "\\";

        if(isSubmission){
            Homework homework = course.getCourseware().getHomework((String) request.readData("homeworkName"));
            Submission submission = homework.getSubmission((Integer) request.readData("submissionNumber"));

            path += "homework\\" + homework.getName() + "\\"+ submission.getStudentId() + "\\" + submission.getText();

        }

        if(isHomework){
            Homework homework = course.getCourseware().getHomework((String) request.readData("homeworkName"));

            path += "homework\\" + homework.getName() + "\\"+ homework.getText();

        }

        if(!isHomework && !isSubmission){
            EducationalContent content = course.getCourseware().getContent((String) request.readData("contentName"));
            String name = (String) request.readData("itemName");
            Content item = content.getItem(name);
            path += "edu_content\\" + content.getName() + "\\" + item.getName()+ "\\" + item.getText();
            System.out.println(path);
        }

        File file = new File(path);

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        if (!file.isFile()) {
            response.setFlag(false);
            response.setServerMessage("file doesnt exist");
            controller.sendMessage(response);
            return;
        }

        FileEncode fileEncode = new FileEncode(path);
        response.addData("file", fileEncode);
        response.setFlag(true);
        response.setServerMessage("file downloaded");
        controller.sendMessage(response);
    }

    private void EditItem(ClientRequest request) {
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Cw cw = course.getCourseware();
        String path = ServerRunner.getProperties().getProperty("cw_folder") + course.getId() +  "\\";
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        EducationalContent content = cw.getContent((String) request.readData("contentName"));
        int removal = (Integer) request.readData("removal");

        if(removal == -1){
            cw.getContents().remove(content);
            response.setFlag(true);
            response.setServerMessage("Educational content removed");
            controller.sendMessage(response);
            return;
        }


        String name = (String) request.readData("itemName");

        if(content.getItem(name) == null){
            response.setFlag(false);
            response.setServerMessage("Item doesnt exist");
            controller.sendMessage(response);
            return;
        }

        Content item = content.getItem(name);
        content.getContents().remove(item);

        if(removal == 0){
            if ((Boolean) request.readData("isText")) {
                item = new Content((String) request.readData("itemName"), true,
                        (String) request.readData("text"), new DateTime());
                content.addItem(item);

            } else {
                item = new Content((String) request.readData("itemName"), false,
                        (String) request.readData("text"), new DateTime());
                content.addItem(item);

                FileEncode file = (FileEncode) request.readData("file");
                FileEncode.decodeStringToFile(file.getEncoded(), path + "edu_content\\" + content.getName() + "\\" +
                        (String) request.readData("itemName") + "\\" + file.getFileName());
            }
            response.setServerMessage("item edited");

        } else response.setServerMessage("item deleted");



        DataAccess.dumpCourse(course);
        response.setFlag(true);
        controller.sendMessage(response);
    }

    private void addStudentToCourseware(ClientRequest request) {
        Course course = Edu.getInstance().getCourseById((Long) request.readData("courseId"));
        Student student = (Student) Edu.getInstance().getUserById((Long) request.readData("studentId"));

        if((Boolean) request.readData("isAssistant")) {
            course.getAssistants().add(student.getIdNumber());
            student.getAssistantCourses().add(course.getId());
            Request.serverMessage(student.getIdNumber(), "you added as TA to course with id "+ course.getId());
        }
        else {
            course.addStudent(student.getIdNumber(), false);
            Request.serverMessage(student.getIdNumber(), "you added as Student to course with id "+ course.getId());

        }

        DataAccess.dumpCourse(course);
        DataAccess.dumpUser(student);

        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        response.setFlag(true);
        response.setServerMessage("student added to courseware");

        controller.sendMessage(response);
    }

    private void purge(){
        ServerResponse response = new ServerResponse(ServerResponseType.Action);
        Edu.getInstance().purgeEnroll();

        response.setServerMessage("all students purged successfully");
        response.setFlag(true);
        controller.sendMessage(response);
    }



    //TODO
    public void processRequest(ClientRequest request){

        if(request.getType().equals(ClientRequestType.LOGIN)){
            login(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.LOGOUT)){
            logout();
            return;
        }

        if(request.getType().equals(ClientRequestType.Reconnect)){
            reconnect(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.ChangePassword)){
            changePassword((String) request.readData("password"));
            return;
        }

        if(request.getType().equals(ClientRequestType.MainMenu)){
            sendMainMenuPage();
            return;
        }

        if(request.getType().equals(ClientRequestType.DeleteMaster)){
            deleteMaster((Long) request.readData("masterId"));
            return;
        }

        if(request.getType().equals(ClientRequestType.EditMaster)){
            editMaster(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.AddMaster)){
            addMaster(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.EditCourse)){
            editCourse(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.AddCourse)){
            addCourse(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.DeleteCourse)){
            deleteCourse((Long) request.readData("courseId"));
            return;
        }

        if(request.getType().equals(ClientRequestType.AddStudent)){
            addStudent(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.EditMark)){
            editMark(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.RegisterCourse)){
            registerCourse(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.ResponseProtest)){
            responseProtest(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.MakeProtest)){
            makeProtest(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.EditStudent)){
            editStudent(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.DetermineRequestResult)){
            determineRequestResult(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.RegisterNewRequest)){
            addNewRequest(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.ChangeEmailAndPhone)){
            changeEmailAndPhone(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.GetPicture)){
            sendPicture((Long)request.readData("id"));
            return;
        }

        if(request.getType().equals(ClientRequestType.SendMessage)){
            sendMessage(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.SendMedia)){
            sendMedia(request);
            return;
        }

        if(request.getType().equals(ClientRequestType.GetMedia)){
            getMedia(request);
            return;
        }

        switch (request.getType()){
            case MarkOrUnmarkCourse:
                markOrUnmarkCourse(request);
                break;

            case EnrollCourse:
                enrollCourse(request);
                break;

            case ChangeCourseGroup:
                changeCourseGroup(request);
                break;

            case ChangeEnrollTime:
                changeEnrollTime(request);
                break;

            case NewContent:
                newContent(request);
                break;

            case AddSubmission:
                addSubmission(request);
                break;

            case AddHomework:
                addHomework(request, true);
                break;

            case MarkSubmission:
                markSubmission(request);
                break;

            case GetSubmissionFile:
                getEducationalFile(request,true, false);
                break;

            case DownloadHomework:
                getEducationalFile(request,false, true);
                break;

            case DownloadItem:
                getEducationalFile(request, false, false);
                break;

            case AddItem:
                addHomework(request, false);
                break;

            case EditItem:
                EditItem(request);
                break;

            case AddStudentToCourseware:
                addStudentToCourseware(request);
                break;

            case Purge:
                purge();
                break;
        }
    }






    public ClientController getController() {
        return controller;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setController(ClientController controller) {
        this.controller = controller;
    }
}