package server.controller;

import com.google.gson.Gson;
import communication.client.ClientRequest;
import communication.encoders.Jackson;
import communication.server.ServerResponse;
import communication.server.ServerResponseType;
import org.codehaus.jackson.map.ObjectMapper;
import server.logic.main_data.Edu;
import communication.public_info.EduPublicInfo;
import server.logic.users.User;
import server.logic.users.security.PasswordHashing;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.*;

public class ClientController {

    private static int lastId = 0;
    private final int id;
    private final Socket socket;
    private final String auth;

    private OutputStream out;
    private InputStream in;

    private PrintWriter sender;

    private final List<Thread> threads = new ArrayList<>();

    private User userLoggedIn;

    private ClientRequest lastRequest;

    private final Library library = new Library();
    private final ObjectMapper objectMapper;

    public ClientController(Socket socket) {
        this.socket = socket;
        this.id = ++lastId;
        this.auth = PasswordHashing.generateHash(String.valueOf((new SecureRandom()).nextInt() + id));
        this.library.setController(this);
        this.objectMapper = Jackson.getNetworkObjectMapper();

        String test = (new Gson()).toJson(EduPublicInfo.makePublicInfoCopy());
        System.out.println(test);

        EduPublicInfo inf = (new Gson()).fromJson(test, EduPublicInfo.class);
        System.out.println((new Gson()).toJson(inf));

        System.out.println(new Gson().toJson(Edu.getInstance()));

        try {
            out = socket.getOutputStream();
            sender = new PrintWriter(out);

            System.out.println();

        } catch (IOException e) {
            e.printStackTrace();
            shutdown();

        } finally {
        if(socket != null){
            Thread listener = new Thread(this::receiver);
            threads.add(listener);
            listener.start();
        }
        }
    }

    private void receiver(){
        Scanner scanner;
        try {
            in = socket.getInputStream();
            scanner = new Scanner(in);
            final ServerResponse authCode = new ServerResponse(ServerResponseType.AUTH);
            authCode.setServerMessage(auth);
            Runnable starter = () -> sendMessage(authCode);
            starter.run();
        } catch (IOException e) {
            e.printStackTrace();
            shutdown();
            return;
        }
        try {
            while (true) {
                String string = scanner.nextLine();
                lastRequest = objectMapper.readValue(string, ClientRequest.class);
                if(!Objects.equals(lastRequest.getAuth(), auth))
                    shutdown();

                library.processRequest(lastRequest);
            }
        } catch (NoSuchElementException e){
            shutdown();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(ServerResponse message){
        try {

            System.out.println((new Gson()).toJson(message));
            sender.println(objectMapper.writeValueAsString(message));
            sender.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void shutdown(){
        System.out.println("client " + socket.getRemoteSocketAddress() + " disconnected.");

        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Thread thread: threads) {
            thread.stop();
        }
        ServerRunner.removeController(this);
    }

    public User getUserLoggedIn() {
        return userLoggedIn;
    }

    public void setUserLoggedIn(User userLoggedIn) {
        this.userLoggedIn = userLoggedIn;
    }
}
