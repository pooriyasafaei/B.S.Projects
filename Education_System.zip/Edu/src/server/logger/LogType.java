package server.logger;

public enum LogType {
    actionDone, actionFailed, logicException
}
