package server.logger;

import com.google.gson.Gson;
import server.time.DateTime;

import java.io.FileWriter;
import java.io.IOException;

public class Logger {

    public static Logger mainLogger;

    public static Logger getInstance(){
        return mainLogger;
    }

    public static void logEvent(Object objectCalled, String methodCalled, String message,
                                Object[] data, LogType logType) {

        try {
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\logs\\methodsLog.txt", true);

            fileWriter.write("Log type: '" + logType.name() + "' at '" + DateTime.getDateTime()
                    + "' an event logged from class: '" + objectCalled.getClass() +
                    "' from method: '" + methodCalled + "' with log message: '" + message + "' was recorded.\r\n" +
                    "event data: ");
            for (Object object : data) {
                fileWriter.write(gson.toJson(object));
            }

            fileWriter.write("\n\n");
            fileWriter.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public static void logException(Object objectCalled, String methodCalled, String message) {

        try {
            Gson gson = new Gson();
            FileWriter fileWriter = new FileWriter("data base\\logs\\logicErrors.txt", true);

            fileWriter.write("Log type: '" + "Exception caught" + "' at '" + DateTime.getDateTime()
                    + "' an event logged from class: '" + objectCalled.getClass() +
                    "' from method: '" + methodCalled + "' with log message: '" + message + "' was recorded.\r\n" +
                    "event data: ");

            fileWriter.write("\n\n");
            fileWriter.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
