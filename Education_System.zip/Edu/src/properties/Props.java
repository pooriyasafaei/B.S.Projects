package properties;

public abstract class Props {
    public static final String SERVER_PROPRERTIES_PATH = "src\\properties\\server_info.properties";
    public static final String CLIENT_PROPRERTIES_PATH = "src\\properties\\client_info.properties";
}
